$(document).ready(function(){


$('#home_slider').owlCarousel({
	loop:true,
	dots:false,
	autoplay:true,
	margin:0,
	nav:true,
	responsive:{
		0:{
            items:1
        },
		600:{
            items:1
        },
		1000:{
            items:1
        },
		}
	
	
	
	
	
	})
	
	$('#peopel_slider').owlCarousel({
	loop:true,
	dots:false,
	autoplay:true,
	margin:0,
	nav:true,
	responsive:{
		0:{
            items:2
        },
		600:{
            items:2
        },
		1000:{
            items:4
        },
		}
	
	
	
	
	
	})


$(".collapse_nav").click(function(){
   $(this).parent().parent('.dash_left_section').toggleClass('hide_menu');
   $('.dash_right_section').toggleClass('srink_area');
}); 

$('.drop_menu .plus').click(function () {
        $(this).parent(".drop_menu").toggleClass('open');
    });
$('.dash_left_section .collapse_nav').click(function () {
        $(this).parent(".dash_left_section").toggleClass('hide');
    });
	
});
$(document).ready(function(){
    $("a").tooltip();
});

$(document).ready(function() {
    $('#sort-tbl').DataTable();
	
} );
$(document).ready(function () {
    var counter = 2;

    $("#addrow").on("click", function () {
        var newRow = $("<tr>");
        var cols = "";

        cols += '<td><div class="form-group"><input type="text" class="form-control" name="name' + counter + '" placeholder="Enter Nominee ' + counter + '"/></div></td>';
        cols += '<td><div class="form-group"><input type="text" class="form-control" name="mail' + counter + '" placeholder="Enter Relation"/></div></td>';
        cols += '<td><div class="form-group"><input type="text" class="form-control" name="phone' + counter + '" placeholder="Enter Percentage "/></div></td>';

        cols += '<td><div class="form-group"><input type="button" class="ibtnDel btn btn-xs btn-danger "  value="-" style="width:100%; font-size:20px; font-weight:600;"/></div></td>';
        newRow.append(cols);
        $("table.order-list").append(newRow);
        counter++;
    });



    $("table.order-list").on("click", ".ibtnDel", function (event) {
        $(this).closest("tr").remove();       
        counter -= 1
    });


});



function calculateRow(row) {
    var price = +row.find('input[name^="price"]').val();

}

function calculateGrandTotal() {
    var grandTotal = 0;
    $("table.order-list").find('input[name^="price"]').each(function () {
        grandTotal += +$(this).val();
    });
    $("#grandtotal").text(grandTotal.toFixed(2));
}
$(function () {
  $('[data-toggle="tooltip"]').tooltip()
})
$(function() {

  // We can attach the `fileselect` event to all file inputs on the page
  $(document).on('change', ':file', function() {
    var input = $(this),
        numFiles = input.get(0).files ? input.get(0).files.length : 1,
        label = input.val().replace(/\\/g, '/').replace(/.*\//, '');
    input.trigger('fileselect', [numFiles, label]);
  });

  // We can watch for our custom `fileselect` event like this
  $(document).ready( function() {
      $(':file').on('fileselect', function(event, numFiles, label) {

          var input = $(this).parents('.input-group').find(':text'),
              log = numFiles > 1 ? numFiles + ' files selected' : label;

          if( input.length ) {
              input.val(log);
          } else {
              if( log ) alert(log);
          }

      });
  });
  
});



const visibilityToggle = document.querySelector('.visibility');
const input = document.querySelector('.password input');

var password = true;

visibilityToggle.addEventListener('click', function(){
	if (password){
	input.setAttribute('type','text');
	visibilityToggle.getElementsByClassName('.fa fa-eye');
	} else{
	input.setAttribute('type','password');	
	visibilityToggle.getElementsByClassName('.fa fa-eye-slash');
	}
	password = !password;
});

function myFunction() {
  var x = document.getElementById("FDdetail");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
} 

function myFunctions() {
  var x = document.getElementById("RDdetail");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}

