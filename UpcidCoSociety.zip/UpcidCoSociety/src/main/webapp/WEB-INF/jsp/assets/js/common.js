/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function isvalidName(sname) {
    var regex = new RegExp("^[a-zA-Z_\\s]{1,20}$");
    return regex.test(sname);
}
function isvalidNamewithspace(sname) {
    var regex = new RegExp("[a-zA-Z ]*$");
    return regex.test(sname);
}


function ContactNo(number) {
    var regex = new RegExp("^[0-9]{1,12}$");
    return regex.test(number);
}

function isvalidAadharNumber(number) {
    var regex = new RegExp("^[0-9]{12,12}$");
    return regex.test(number);
}
function OnlyNumber(number) {
    var regex = new RegExp("^[0-9]{1,3}$");
    return regex.test(number);
}

function OnlyNumberforPincode(number) {
    var regex = new RegExp("^[0-9]{1,6}$");
    return regex.test(number);
}
function OnlyNumber2(number) {
    //allowed 0 to 20 digits
    var regex = new RegExp("^[0-9]{1,20}$");
    return regex.test(number);
}
function memberaccountnumber(number) {
    //allowed 0 to 20 digits
    var regex = new RegExp("^[0-9]{1,20}$");
    return regex.test(number);
}

function isEmail(email) {
    var pattern = new RegExp(/^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/);
    return pattern.test(email);
}
function isValidPNO(PNOnumber) {
    var regex = new RegExp("^[a-zA-Z0-9]{1,12}$");
    return regex.test(PNOnumber);
}
function isValidAlfaNumeric(str) {
    var regex = new RegExp("^[a-zA-Z0-9]+$");
    return regex.test(str);
}

function isDouble(code) {
    if (jQuery.isNumeric(code)) {
        var i = code.lastIndexOf('.');
        if (i == -1 || code.substring(i).length <= 3) {

            if (code.length >= 0 && code.length <= 13) {
                return "OK";
            } else {
                return "value should not more then 10 digits"
            }
        } else {
            return"Precision digits should not more then 2"
        }
    } else
    {
        return "value should be in integer or double"
    }
}


function isValidUrl(url) {

    var regex = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;
    return regex.test(url);
}
function isValidPassword(password) {

    var regex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,20}$/;
    return regex.test(password);
}
function isValidPanNumber(panmuber) {
    var regex = /^[A-Z]{5}\d{4}[A-Z]{1}$/;
    return regex.test(panmuber);
}






function namevalidator(membername) {

    if (membername == null || membername == "") {
        $("#name_error").text("Member Name is required!");
        return false;
    } else if (!isvalidName(membername)) {
        $("#name_error").text("Invalid Name,Size should not more then 20 charecters");
        return false;
    } else {
        $("#name_error").text("");
        return true;
    }
}
function fathernamevalidator(fatherName) {
    if (fatherName == null || fatherName == "") {
        $("#fname_error").text("Father Name is required!");
        return false;
    } else if (!isvalidName(fatherName)) {
        $("#fname_error").text("Invalid Name,Size should not more than 20 charecters");
        return false;
    } else {
        $("#fname_error").text("");
        return true;
    }
}
function pnoNumbervalidator(pnoNum) {
    if (pnoNum == null || pnoNum == "") {
        $("#pno_error").text("PNO Number is required!");
        return false;
    } else if (!isValidPNO(pnoNum)) {
        $("#pno_error").text("Invalid PNO number,Size is exceed");
        return false;
    } else {
        $("#pno_error").text("");
        return true;
    }
}

function datevalidator(dob) {
    if (dob == null || dob == "") {
        $("#dob_error").text("Please select date of birth!");
        return false;
    } else if (dob != null) {
        var parts = dob.split('-');
        var d = new Date(parts[2], parts[1] - 1, parts[0]);
        var month = d.getMonth() + 1;
        var day = d.getDate();
        if (day < 10) {
            day = 0 + "" + day;
        }
        if (month < 10) {
            month = 0 + "" + month;
        }
        var y = Number(d.getFullYear()) + Number(60);

        var rtmentdate = day + "-" + month + "-" + y;
        $("#dateOfRetirement").val(rtmentdate);
        $("#dor_error").text("");
        $("#dob_error").text("");
        return true;
    }
}
function dorvalidator(dor) {

    var dob = $("#dateOfBirth").val();
    if (dor == null || dor == "") {
        $("#dor_error").text("Please select date!");
        return false;
    } else if (dor != null && dob != null) {

        var parts = dob.split('-');
        var d = new Date(parts[2], parts[1] - 1, parts[0]);
        var month = d.getMonth() + 1;
        var day = d.getDate();
        if (day < 10) {
            day = 0 + "" + day;
        }
        if (month < 10) {
            month = 0 + "" + month;
        }
        var y = Number(d.getFullYear()) + Number(60);

        var rtmentdate = new Date(y + "-" + month + "-" + day);

        var part = dor.split('-');
        var dd = new Date(part[2], part[1] - 1, part[0]);
        var month2 = dd.getMonth() + 1;
        var day2 = dd.getDate();
        if (day2 < 10) {
            day2 = 0 + "" + day2;
        }
        if (month2 < 10) {
            month2 = 0 + "" + month2;
        }
        var y2 = Number(dd.getFullYear());
        var rtmentdate2 = new Date(y2 + "-" + month2 + "-" + day2);
        if (rtmentdate2.getTime() >= rtmentdate.getTime()) {
            // $("#dateOfRetirement").se(rtmentdate2);
            $("#dateOfRetirement").datepicker({
                defaultDate: rtmentdate2,
                autoclose: true
            });


            $("#dor_error").text("");
            return true;
        } else {
            $("#dateOfRetirement").val("");
            $("#dor_error").text("Retirement date should be greater then or equeal to 60 years from Date of birth");
            return false;
        }

    }
}
function doappointmentvalidator(dop) {

    if (dop == null || dop == "") {
        $("#mobile_error").text("Please enter your date of appointment!");
        return false;
    } else {
        $("#mobile_error").text("");
        return true;
    }
}




function numberValidator(mnumber) {
    if (mnumber == null || mnumber == "") {
        $("#mobile_error").text("Please enter your mobile number!");
        return false;
    } else if (!ContactNo(mnumber)) {
        $("#mobile_error").text("Invalid mobile number!");
        return false;
    } else {
        $("#mobile_error").text("");
        return true;
    }
}

function emailValidator(email) {
    if (email == null || email == "") {
        $("#email_error").text("Please enter email address!");
        return false;
    } else if (!isEmail(email)) {
        $("#email_error").text("Invalid email!");
        return false;
    } else {
        $("#email_error").text("");
        return true;
    }
}
function addressValidator(pAddress) {

    if (pAddress == null || pAddress == "") {
        $("#padd_error").text("Please enter local address!");
        return false;
    } else if (pAddress != null && pAddress.length > 100) {
        $("#padd_error").text("Address size should be less than 100 charectars!");
        return false;
    } else {
        $("#padd_error").text("");
        return  true;
    }

}
function parmaddressValidator(pAddress) {

    if (pAddress == null || pAddress == "") {
        $("#paradd_error").text("Please enter permanent address!");
        return false;
    } else if (pAddress != null && pAddress.length > 100) {
        $("#paradd_error").text("Address size should be less than 100 charectars!");
        return false;
    } else {
        $("#paradd_error").text("");
        return  true;
    }

}
function basicPayValidator(basicPay) {

    if (basicPay ==null || basicPay =="") {
        $("#basicpay-error").text("Please enter basic pay!");
        return false;
    } else {
        if (isDouble(basicPay) != "OK") {
            $("#basicpay-error").text(isDouble(basicPay));
            return  false;
        } else {
            $("#basicpay-error").text("");
            return  true;
        }
    }
}

//# no formate is assigned to me show i validate just null and size only.
//        please make changes whenever you get.
function gpfnumberValidator(gpfnumber) {
    alert(gpfnumber);
    if (gpfnumber ==null || gpfnumber =="") {
        $("#gpf_error").text("Please enter your G.P.F. / N.P.A. number!");
        return  false;
    } else if (gpfnumber != null && gpfnumber.length > 25) {
        
        $("#gpf_error").text("G.P.F number length should be less then 25 charecters!");
        return  false;
    } else {
        $("#gpf_error").text("");
        return  true;
    }

}
function panNumberValidator(pannumber) {

    if (pannumber == null || pannumber == "") {
        $("#pannumber_error").text("Please enter your pan number!");
        return  false;
    } else if (!isValidPanNumber(pannumber)) {
        alert("asfasd");
        $("#pannumber_error").text("Invalid pan number!");
        return  false;
    } else {
        $("#pannumber_error").text("");
        return  true;
    }

}

function  aadharnumberValidator(aadharNumber) {
   if (aadharNumber == null || aadharNumber == "") {
        $("#aadharnumber_error").text("Please enter aadhar number!");
        return  false;
    } else if (!isvalidAadharNumber(aadharNumber)) {
        $("#aadharnumber_error").text("Invalid aadhar number!");
        return  false;
    } else {
        $("#aadharnumber_error").text("");
        return  true;
    }

}

function checkboxValidator(checkbox){
    
  if(checkbox==null || checkbox==""){
     $("#termandcon").text("Please Select Term and Conditions.!");
      return false;
  }else if(checkbox!=null && !checkbox.equels(true)) {
       $("#termandcon").text("Please Select Term and Conditions!");
        return false;
  }else{
    $("#termandcon").text("!") ;
     return true;
  }
}

function accOpenValidator(accOpenDate) {
   
    if (accOpenDate == null || accOpenDate == "") {
        $("#accopendate-error").text("Please enter account openning date!");
        return false;
    } else {
        $("#accopendate-error").text("");
        return true;
    }
}

function bankNameValidator(bankName) {
    if (bankName == null || bankName == "") {
        $("#bankName-error").text("Please enter bank name!");
        return false;
    } else if (!isvalidName(bankName)) {
        $("#bankName-error").text("Invalid Bank name");
        return false;
    } else {
        $("#bankName-error").text("");
        return true;

    }
}
function bankaccNoValidator(bankAccontNumber) {

    if (bankAccontNumber == null || bankAccontNumber == "") {
        $("#bankacNumber-error").text("Please enter bank account number!");
        return false;
    } else if (!isValidPNO(bankAccontNumber)) {
        $("#bankacNumber-error").text("Invalid Bank account number!");
        return false;
    } else {
        $("#bankacNumber-error").text("");
        return true;
    }
}
function srdamountValidator(srdAmount) {

    if (srdAmount == null || srdAmount == "") {
        $("#srd-error").text("Please enter srd amount!");
        return false;
    } else {
        if (isDouble(srdAmount) != "OK") {
            $("#srd-error").text(isDouble(srdAmount));
            return false;
        } else {
            $("#srd-error").text("");
            return true;
        }
    }
}
function shareopenBalValidator(shareOpenBal) {
    if (shareOpenBal == null || shareOpenBal == "") {
        $("#soBalance-error").text("Please enter share Opening balance!");
        return false;
    } else {
        if (isDouble(shareOpenBal) != "OK") {
            $("#soBalance-error").text(isDouble(shareOpenBal));
            return false;
        } else {
            $("#soBalance-error").text("");
            return true;

        }
    }
}
function societyaccountNumberValidator(societyAccountNumber) {

    if (societyAccountNumber == null || societyAccountNumber == "") {
        $("#soacNumber-error").text("Please enter society account number!");
        return false;
    } else if (!isValidPNO(societyAccountNumber)) {
        $("#soacNumber-error").text("Invalid Society account number!");
        return false;
    } else {
        $("#soacNumber-error").text("");
        return true;

    }
}
function ledgerfileNumberValidator(ledgerFilenumber) {

    if (ledgerFilenumber == null || ledgerFilenumber == "") {
        $("#lfnumber-error").text("Please enter ledger file number!");
        return false;
    } else if (!isValidPNO(ledgerFilenumber)) {
        $("#lfnumber-error").text("Invalid ledger file number!");
        return false;
    } else {
        $("#lfnumber-error").text("");
        return true;

    }
}

function providentfundNumberValidator(providentFundNumber) {

    if (providentFundNumber == null || providentFundNumber == "") {
        $("#pfnumber-error").text("Please enter provident fund number!");
        return  false;
    } else if (!isValidPNO(providentFundNumber)) {
        $("#pfnumber-error").text("Invalid provident fund number!");
        return  false;
    } else {
        $("#pfnumber-error").text("");
        return true;
    }
}
function rankValidator(rankId) {

    if (rankId == 0 || rankId == "") {
        $("#rank_error").text("Select Rank!");
        return false;
    } else {
        $("#rank_error").text("");
        return true;
    }

}

function sectorValidator(sectorId) {

    if (sectorId == 0 || sectorId == "") {
        $("#sector_error").text("Select Sector!");
        return false;
    } else {
        $("#sector_error").text("");
        return true;
    }
}
function postingValidator(postingId) {

    if (postingId == 0 || postingId == "") {
        $("#posting_error").text("Select Posting!");
        return  false;
    } else {
        $("#posting_error").text("");
        return true;

    }
}

function categoryValidator(categoryId) {

    if (categoryId == 0 || categoryId == "") {
        $("#category_error").text("Select Category!");
        return  false;
    } else {
        $("#category_error").text("");
        return true;
    }
}
function paymentModeValidator(paymentmode) {

    if (paymentmode == 0 || paymentmode == "") {
        $("#patmentmode_error").text("Select Payment Mode!");
        return false;
    } else {
        $("#patmentmode_error").text("");
        return true;
    }
}
function nomineeNameValidator(obj) {
    var rowid = $(obj).attr('id');
    var nomineename = $("#" + rowid).val();
    if (nomineename == null || nomineename == "") {
        $("#" + rowid + "_error").text("Please enter nominee name!");
        return false;
    } else if (!isvalidName(nomineename)) {
        $("#" + rowid + "_error").text("Invalid nominee name!");
        return false;
    } else {
        $("#" + rowid + "_error").text("");
        return true;
    }
}
function relationValidator(obj) {
    var rowid = $(obj).attr('id');
    var relation = $("#" + rowid).val();
    if (relation == null || relation == "") {
        $("#" + rowid + "_error").text("Please enter relation!");
        return false;
    } else if (!isvalidName(relation)) {
        $("#" + rowid + "_error").text("Invalid relation!");
        return false;
    } else {
        $("#" + rowid + "_error").text("");
        return true;
    }
}

function  nomineeaddressValidator(obj) {
    var rowid = $(obj).attr('id');
    var nomineeAddress = $("#" + rowid).val();
    if (nomineeAddress == null || nomineeAddress == "") {
        $("#" + rowid + "_error").text("Please enter address!");
        return false;
    } else if (!isvalidName(nomineeAddress)) {
        $("#" + rowid + "_error").text("Invalid address!");
        return false;
    } else {
        $("#" + rowid + "_error").text("");
        return true;
    }

}
function nomineeadobValidator(obj) {
    var rowid = $(obj).attr('id');
    var nomineedob = $("#" + rowid).val();
    if (nomineedob == null || nomineedob == "") {
        $("#" + rowid + "_error").text("Enter date of birth!");
        return false;
    } else {
        $("#" + rowid + "_error").text("");
        return true;
    }
}

//   function dobValidator(obj){
//    var rowid = $(obj).attr('id'); 
//    var relation = $("#" + rowid).val();
//  
//}

//function addressValidator(obj){
// var rowid = $(obj).attr('id'); 
// var relation = $("#" + rowid).val();   
//       
//}
function parcentageValidator(obj) {

    var rowid = $(obj).attr('id');
    var lastrow = Number(rowid.substring(10));
    var parcentage = 0;
    var index;
    for (index = 1; index <= lastrow; index++) {
        parcentage = parcentage + Number($("#" + rowid.substring(0, 10) + index).val());
    }
    if (parcentage == null || parcentage <= 0) {
        $("#" + rowid + "_error").text("Please enter percentage!");
        return false;
    } else if (isNaN(parcentage)) {
        $("#" + rowid + "_error").text("Only Integers are allowed!");
        return false;
    } else if (!OnlyNumber(parcentage) || parcentage < 100) {
        $("#addrow").prop('disabled', false);
        $("#" + rowid + "_error").text("");
        return true;
    } else if (parcentage == 100) {
        $("#addrow").prop('disabled', true);
        $("#" + rowid + "_error").text("");
        return true;
    } else {
        $("#" + rowid + "_error").text("Total parcentage should not  be more than 100");
        return false;
    }
}
//function clickValidator(obj) {
//    var rowid = $(obj).attr('id');
//}


// member vitnesess validators

function witnessNameValidator(obj) {
//    var wname = $(obj).val();
    if ($(obj).val() == null || $(obj).val() == "") {
        $(obj).next(".error").text("Witness Name is required!");
        return false;
    } else if (!isvalidName($(obj).val())) {
        $(obj).next(".error").text("Either name is invalid or lenth is greater then 20 charecters!");
        return false;
    } else {
        $(obj).next(".error").text("");
        return true;
    }
}

  function witnessRankValidator(obj){
//    var wRanlk = $(obj).val();
    if ($(obj).val() == null || $(obj).val() == "") {
        $(obj).next(".error").text("Witness Rank is required!");
        return false;
    } else if (!isvalidName($(obj).val())) {
        $(obj).next(".error").text("Either Rank is invalid or lenth is greater then 20 charecters!");
        return false;
    } else {
        $(obj).next(".error").text("");
        return true;
    }
  }

function witnessPnoValidator(obj) {
//    var pnoNumber = $(obj).val();
//    alert(pnoNumber);
    if ($(obj).val() == null || $(obj).val() == "") {
        $(obj).next(".error").text("PNO Number is required!");
        return false;
    } else if (!isValidPNO($(obj).val())) {
        $(obj).next(".error").text("Invalid PNO number,Size is exceed more then 20 charectors!");
        return false;
    } else {
        $(obj).next(".error").text("");
        return true;
    }
}

function witnessAddress(obj) {
//    var witnessAddress = $(obj).val();

    if ($(obj).val() == null || $(obj).val() == "") {
        $(obj).next(".error").text("Please enter address!");
//        $("#witnessaddress_error").text("Please enter address!");
        return false;
    } else if ($(obj).val() != null && $(obj).val().length > 100) {
        $(obj).next(".error").text("Address size should be less than 100 charecters!");
//        $("#witnessaddress_error").text("address size should be less than 100 charecters!");
        return false;
    } else {
        $(obj).next(".error").text("");
        return  true;
    }
}



function  witnessmNumberValidator(obj) {
    
    if ($(obj).val() == null || $(obj).val() == "") {
        $(obj).next(".error").text("Please enter your mobile number!");
        return false;
    } else if (!ContactNo($(obj).val())) {
        $(obj).next(".error").text("Invalid mobile number!");
        return false;
    } else {
        $(obj).next(".error").text("");
        return true;
    }

}
 function isvalidaccountstartdate(accountstartdate){
     
    if(accountstartdate==null || accountstartdate==""){
       $("#accountstartdate_error").text("Please select start account date");
        return false;
    }else{
       $("#accountstartdate_error").text("");
        return true;  
    }  
 }
 
  function dateofappointmentvalidater(dop){
     if(dop==null || dop==""){
       $("#dop_error").text("Please select your appointment date!");
        return false;
    }else{
       $("#dop_error").text("");
        return true;  
    }    
      
  }

 function isvalidmemberaccopuntNumber(memberaccountNumber){
     
   if(memberaccountNumber==null || memberaccountNumber==""){
       $("#memberaccountnumber_error").text("please enter account number!");
        return false;
    }else if(!memberaccountnumber(memberaccountNumber)){
       $("#memberaccountnumber_error").text("Invalid account number!");
        return false;  
    }else{
       $("#memberaccountnumber_error").text("");
        return false;  
        
    }   
 }
 

$(document).ready(function () {
    $("#dateOfBirth").on("change", function () {
        datevalidator(this.value);
    });
    $("#dateOfRetirement").on("change", function () {
        dorvalidator(this.value);
    });
    
    $("#dateofappoint").on("change", function () {
        dateofappointmentvalidater(this.value);
    });
    
    $("#memberAccountmodel_accountOpeningDate").on("change", function () {
        accOpenValidator(this.value);
    });
    
    
    $("#accountstartDate").on("change", function () {
        isvalidaccountstartdate(this.value);
    });
});



