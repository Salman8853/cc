/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.controller;

import java.security.Principal;
import javax.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 *
 * @author m.salman
 */
@Controller
@RequestMapping("/member")
public class MemberDashBoardController {

    @RequestMapping(value = "/loandtls",method = RequestMethod.GET)
    public String loanDetail(ModelMap map,HttpServletRequest request, Principal principal) {
        return "loandetail";
    }
    
    @RequestMapping(value = "/fd",method = RequestMethod.GET)
    public String fdDetails(ModelMap map,HttpServletRequest request, Principal principal) {
        return "fd";
    }
    
    @RequestMapping(value = "/fdcertificate",method = RequestMethod.GET)
    public String fdcertificate(ModelMap map,HttpServletRequest request, Principal principal) {
        return "fdcertificate";
    }
    
    @RequestMapping(value = "/rd",method = RequestMethod.GET)
    public String rdDetails(ModelMap map,HttpServletRequest request, Principal principal) {
        return "rd";
    }
    
    @RequestMapping(value = "/complaints",method = RequestMethod.GET)
    public String complaints(ModelMap map,HttpServletRequest request, Principal principal) {
        return "complaints";
    }
    
    @RequestMapping(value = "/feedback",method = RequestMethod.GET)
    public String feedback(ModelMap map,HttpServletRequest request, Principal principal) {
        return "feedback";
    }
    
    @RequestMapping(value = "/dv",method = RequestMethod.GET)
    public String dividendFinal(ModelMap map,HttpServletRequest request, Principal principal) {
        return "dvfinal";
    }

}
