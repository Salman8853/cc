/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.controller;

import com.upcidcosociety.dtob.FdDetails;
import com.upcidcosociety.dtob.MemberDetail;
import com.upcidcosociety.model.FdCertificateModel;
import com.upcidcosociety.model.FdNomineeModel;
import com.upcidcosociety.model.FdRenueModel;
import com.upcidcosociety.model.FdRequestModel;
import com.upcidcosociety.model.MemberDetailModelforRd;
import com.upcidcosociety.service.FdDetailsService;
import com.upcidcosociety.service.MemberDetailService;
import com.upcidcosociety.util.GenerateCertificateforFd;
import com.upcidcosociety.util.UpcidResponse;
import java.security.Principal;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 *
 * @author m.salman
 */
@Controller
@RequestMapping("/upcid")
public class ManageFdController {

    @Autowired
    private MemberDetailService memberDetailService;

    @Autowired
    private FdDetailsService fddetailsservice;

    @Value("${site.url}")
    String siteurl;

    @RequestMapping(value = "/managefd", method = RequestMethod.GET)
    public String managefd(ModelMap map, HttpServletRequest request, Principal principal) {
        UpcidResponse<MemberDetailModelforRd> response = new UpcidResponse();
        response.setStatus(HttpStatus.NOT_FOUND);
        response.setData(null);
        FdRequestModel obj = new FdRequestModel();
        obj.setFdcreateandorUpdateStatus("Create");
        List<FdNomineeModel> nominee = new ArrayList<>();
        FdNomineeModel modee = new FdNomineeModel();
        modee.setId(-1);
        nominee.add(modee);
        obj.setNominee(nominee);
        map.addAttribute("memberdetailResponse", response);
        map.addAttribute("memberNamesListWithPnoNumbers", memberDetailService.getAllMemberDetailforRd(principal.getName()));
        map.addAttribute("openfd_form", obj);
        return "managefd";
    }

    @RequestMapping(value = "/managefd/{pnoNumber}", method = RequestMethod.GET)
    public String managememberfd(@PathVariable String pnoNumber, ModelMap map, HttpServletRequest request, Principal principal) {
        UpcidResponse<MemberDetailModelforRd> upcidResponse = new UpcidResponse();
        upcidResponse = memberDetailService.getmemberDetailBypnoNumberforFD(pnoNumber, principal.getName());
        if (upcidResponse.getStatus() == HttpStatus.OK) {
            map.addAttribute("memberdetailResponse", upcidResponse);
            map.addAttribute("memberNamesListWithPnoNumbers", memberDetailService.getAllMemberDetailforRd(principal.getName()));
            FdRequestModel obj = (FdRequestModel) fddetailsservice.generateNewaccountNumberforNewFd(pnoNumber,principal.getName()).getData();
            obj.setPnoNumber(pnoNumber);
            map.addAttribute("openfd_form", obj);
            return "managefd";
        } else {
            request.getSession().setAttribute("msg", upcidResponse.getMessage());

            if (upcidResponse.getStatus() == HttpStatus.OK) {
                request.getSession().setAttribute("msgType", "success");
            } else if (upcidResponse.getStatus() == HttpStatus.EXPECTATION_FAILED) {
                request.getSession().setAttribute("msgType", "error");
            } else {
                request.getSession().setAttribute("msgType", "warning");
            }
            return "redirect:/upcid/managefd";

        }

    }

    @RequestMapping(value = "/fddetail/{pnoNumber}", method = RequestMethod.GET)
    public @ResponseBody String getfdDetailsforAjax(@PathVariable String pnoNumber, @RequestParam int fdvalue, @RequestParam int fdperiod, @RequestParam String oppeningdate, ModelMap map, HttpServletRequest request, Principal principal) {
        UpcidResponse<String> upcidResponse = new UpcidResponse();
        upcidResponse = fddetailsservice.getfdmaturityvalueforajax(pnoNumber,oppeningdate, fdperiod, fdvalue, principal.getName());
        if (upcidResponse.getStatus() == HttpStatus.OK) {

            return "{\"result\":" + upcidResponse.getData() + "}";

        } else {
            return "{\"result\":\"failed\"}";
        }
    }

    @RequestMapping(value = "/fd/save", method = RequestMethod.POST)
    public String createNewFd(@ModelAttribute("openfd_form") FdRequestModel fdrequestmodel, ModelMap map, BindingResult result, HttpServletRequest request, Principal principal) {
        UpcidResponse<FdDetails> upcidResponse = new UpcidResponse();
        if (result.hasErrors()) {
            return "redirect:/upcid/managefd/" + fdrequestmodel.getPnoNumber();
        } else {
            upcidResponse = fddetailsservice.createnewfd(fdrequestmodel, principal.getName());

        }
        request.getSession().setAttribute("msg", upcidResponse.getMessage());
        if (upcidResponse.getStatus() == HttpStatus.OK) {
            request.getSession().setAttribute("msgType", "success");
        } else if (upcidResponse.getStatus() == HttpStatus.EXPECTATION_FAILED) {
            request.getSession().setAttribute("msgType", "error");
        } else {
            request.getSession().setAttribute("msgType", "warning");
        }
        return "redirect:/upcid/showfd/" + fdrequestmodel.getPnoNumber();

    }

    @RequestMapping(value = "/edit/{pnonumber}", method = RequestMethod.GET)
    public String editfd(@PathVariable String pnonumber, @RequestParam String fdaccno, ModelMap map, HttpServletRequest request, Principal principal) {
        UpcidResponse<MemberDetailModelforRd> upcidResponse = new UpcidResponse();
        upcidResponse = memberDetailService.getmemberDetailBypnoNumberforFD(pnonumber, principal.getName());
        map.addAttribute("memberdetailResponse", upcidResponse);
        map.addAttribute("memberNamesListWithPnoNumbers", memberDetailService.getAllMemberDetailforRd(principal.getName()));
        UpcidResponse<FdRequestModel> response = fddetailsservice.getfddetailsByfdaccountNumber(pnonumber, fdaccno, principal.getName());
        map.addAttribute("openfd_form", response.getData());
        return "managefd";
    }

    @RequestMapping(value = "/showfd", method = RequestMethod.GET)
    public String showrfd(ModelMap map, HttpServletRequest request, Principal principal) {
        UpcidResponse<MemberDetail> response = new UpcidResponse();
        response.setStatus(HttpStatus.NOT_FOUND);
        response.setData(null);
        map.addAttribute("memberdetailResponse", response);
        map.addAttribute("memberFdlist", response);
        map.addAttribute("memberNamesListWithPnoNumbers", memberDetailService.getAllMemberDetailforRd(principal.getName()));
        return "showfd";
    }

    @RequestMapping(value = "/showfd/{pnonumber}", method = RequestMethod.GET)
    public String showrallfdofmember(@PathVariable String pnonumber, ModelMap map, HttpServletRequest request, Principal principal) {
        UpcidResponse<MemberDetailModelforRd> upcidResponse = new UpcidResponse();
        upcidResponse = memberDetailService.getmemberDetailBypnoNumberforFD(pnonumber, principal.getName());
        map.addAttribute("memberdetailResponse", upcidResponse);
        map.addAttribute("memberFdlist", fddetailsservice.getfddetailsByfpnoNumber(pnonumber, principal.getName()));
        map.addAttribute("memberNamesListWithPnoNumbers", memberDetailService.getAllMemberDetailforRd(principal.getName()));
        map.addAttribute("pnoNumber", pnonumber);
        return "showfd";
    }

    @RequestMapping(value = "/pcertificate/{pnonumber}")
    public ResponseEntity generatecertificate(@PathVariable String pnonumber, @RequestParam String fdaccno, ModelMap map, HttpServletRequest request, Principal principal) {
        UpcidResponse<FdCertificateModel> response = null;
        String watermark = siteurl + "/assets/assets_admin/images/watermark.jpg";
        String logo = siteurl + "/assets/assets_admin/images/favicon.png";
        String favicon = siteurl + "/assets/assets_admin/images/favicon_img.ico";
        response = fddetailsservice.generatecertificate(pnonumber, fdaccno, principal.getName());
        byte[] bis = GenerateCertificateforFd.generateCertificateforfd(response.getData(), logo, watermark);
        HttpHeaders respHeaders = new HttpHeaders();
        respHeaders.add("Content-Disposition", "inline; filename=checklist.pdf");
        respHeaders.add("Link", favicon + "; rel=\"shortcut icon\"");
        MediaType mediaType = MediaType.parseMediaType("application/pdf");
        respHeaders.setContentType(mediaType);
        respHeaders.setCacheControl("must-revalidate, post-check=0, pre-check=0");
        return new ResponseEntity(new ByteArrayResource(bis), respHeaders, HttpStatus.OK);
    }

    @RequestMapping(value = "/getfddetailforrenual/{pnonumber}", method = RequestMethod.GET)
    public @ResponseBody String renuefd(@PathVariable String pnonumber, @RequestParam String fdaccno, @RequestParam Integer period, @RequestParam Double amount, @RequestParam String renuedate, HttpServletRequest request, Principal principal) {
        UpcidResponse<String> upcidResponse = new UpcidResponse();
        upcidResponse = fddetailsservice.getresponseforfdRenueal(pnonumber, fdaccno, period, amount, renuedate, principal.getName());
        if (upcidResponse.getStatus() == HttpStatus.OK) {

            return "{\"result\":" + upcidResponse.getData() + "}";

        } else {
            return "{\"result\":\"failed\"}";
        }
    }

    @RequestMapping(value = "/fd/renue", method = RequestMethod.POST)
    public String renuefdaccount(HttpServletRequest request, Principal principal) {
          UpcidResponse<FdDetails> upcidresponse = new UpcidResponse();
        FdRenueModel fdrenuemodel= new FdRenueModel();
        String pnonumber = request.getParameter("pnonumber"); 
        String fdaccno = request.getParameter("fdaccno");
        String depositeAmount = request.getParameter("amount");
        String agegroup = request.getParameter("agegroup");
        String renueDate = request.getParameter("startdate");
        String period = request.getParameter("period");
        String fdfullrate = request.getParameter("fdfullrate");
        String fdpartRate = request.getParameter("fdpartrate");
        String maturityDate = request.getParameter("maturitydate");
        String maturityamount = request.getParameter("maturityamount");
        fdrenuemodel.setPnonumber(pnonumber);
        fdrenuemodel.setFdaccno(fdaccno);
        fdrenuemodel.setAgegroup(agegroup);
        fdrenuemodel.setStartdate(renueDate);
        fdrenuemodel.setPeriod(Integer.parseInt(period));
        fdrenuemodel.setRenueableAmount(Double.parseDouble(depositeAmount));
        fdrenuemodel.setFdfullrate(Double.parseDouble(fdfullrate));
        fdrenuemodel.setFdpartrate(Double.parseDouble(fdpartRate));
        fdrenuemodel.setMaturitydate(maturityDate);
        fdrenuemodel.setMaturityamountr(Double.parseDouble(maturityamount));
        upcidresponse=fddetailsservice.updateFDforRenueal(fdrenuemodel,principal.getName());
        if(upcidresponse.getStatus() == HttpStatus.OK){
          request.getSession().setAttribute("msg", upcidresponse.getMessage());
          request.getSession().setAttribute("msgType", "success");
          return "redirect:/upcid/showfd/"+pnonumber;
         }else{
            request.getSession().setAttribute("msgType", "error");
            request.getSession().setAttribute("msgType", "warning");
          return "redirect:/upcid/showfd/"+pnonumber;
           }
        
    }
}
