/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.controller;

import com.upcidcosociety.dtob.FeedBack;
import com.upcidcosociety.model.ComplaintsModel;
import com.upcidcosociety.model.MemberDetailModel;
import com.upcidcosociety.model.MemberWitnessModel;
import com.upcidcosociety.model.NomineeModel;
import com.upcidcosociety.service.CategoryService;
import com.upcidcosociety.service.ComplaintsCategoryMasterService;
import com.upcidcosociety.service.ComplaintsRequestMasterService;
import com.upcidcosociety.service.ComplaintsService;
import com.upcidcosociety.service.FeedBackService;
import com.upcidcosociety.service.FileUploadService;
import com.upcidcosociety.service.MemberDetailService;
import com.upcidcosociety.service.MemberShareDetailService;
import com.upcidcosociety.service.NewsService;
import com.upcidcosociety.service.PageMasterService;
import com.upcidcosociety.service.PagesService;
import com.upcidcosociety.service.PaymentModeService;
import com.upcidcosociety.service.PhotoGalaryService;
import com.upcidcosociety.service.PostingService;
import com.upcidcosociety.service.RankService;
import com.upcidcosociety.service.SectorService;
import com.upcidcosociety.util.UpcidResponse;
import com.upcidcosociety.util.UtilDate;
import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.Principal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;

/**
 *
 * @author m.salman
 */
@Controller
@RequestMapping("/page")
public class CmsViewController {

    @Autowired
    private PagesService pagesService;

    @Autowired
    private PageMasterService pageMasterService;

    @Autowired
    private ComplaintsService complaintsService;

    @Autowired
    private ComplaintsCategoryMasterService complaintsCategoryMasterService;

    @Autowired
    private ComplaintsRequestMasterService complaintsRequestMasterService;

    @Autowired
    private FeedBackService feedBackService;

    @Autowired
    private NewsService newsService;

    @Autowired
    private PhotoGalaryService PhotoGalaryService;
    
//    dependency for member registration from index page
    @Autowired
    private MemberDetailService memberDetailService;
    @Autowired
    private RankService rankService;
    @Autowired
    private CategoryService categoryService;
    @Autowired
    private PostingService postingService;
    @Autowired
    private SectorService sectorService;
    
    @Autowired
    private FileUploadService fileUploadService; 
    @Autowired
    private PaymentModeService paymentModeService;
 
    @Value("${file.upload-dir}")
    private String uploadDir;
    private Path fileStorageLocation;
    

    @RequestMapping(value = "/cmsView/{pagename}", method = RequestMethod.GET)
    public String getPageDataBypageId(@PathVariable String pagename, ModelMap map, HttpServletRequest request, Principal principal) {
        UpcidResponse response = null;
        response = pageMasterService.getPageByPageName(pagename);
        if (response.getStatus() == HttpStatus.OK) {
            map.addAttribute("cmsviewpage", response);
            map.addAttribute("newsListResp", newsService.getAllNews());

            return pagename;
        }
        return pagename;

    }

    @RequestMapping(value = "/Photo_Gallery", method = RequestMethod.GET)
    public String getalbumListforHome(ModelMap map, HttpServletRequest request) {
        map.addAttribute("albumlist", PhotoGalaryService.getallAlbumList(null));
        map.addAttribute("newsListResp", newsService.getAllNews());
        return "Photo_Gallery";
    }
//     
//     @RequestMapping(value = "/inside_galary/{albumTitle}", method = RequestMethod.GET)
//     public String getPhoto_GalleryforHome(ModelMap map, HttpServletRequest request){
//      map.addAttribute("albumlist", PhotoGalaryService.getallAlbumList(null));
//      return "inside_galary";
//    }

    @RequestMapping(value = "/Complaints", method = RequestMethod.GET)
    public String complaints(ModelMap map, HttpServletRequest request, Principal principal) {
        map.addAttribute("complaints_form", new ComplaintsModel());
        map.addAttribute("complaintsCategoryMasterListRes", complaintsCategoryMasterService.getAllComplaintsCategoryMaster());
        map.addAttribute("complaintsRequestMasterListRes", complaintsRequestMasterService.getAllComplaintsRequestMaster());
        map.addAttribute("newsListResp", newsService.getAllNews());
        return "Complaints";
    }

    @RequestMapping(value = "/saveComplaints", method = RequestMethod.POST)
    public String complaints(@ModelAttribute("complaints_form") ComplaintsModel ComplaintsModel, BindingResult result, ModelMap map, HttpServletRequest request, Principal principal) {
        UpcidResponse upcidResponse = null;
        if (result.hasErrors()) {
            return "Complaints";
        }
        upcidResponse = complaintsService.saveNewComplaints(ComplaintsModel);
        request.getSession().setAttribute("msg", upcidResponse.getMessage());
        if (upcidResponse.getStatus() == HttpStatus.OK) {
            request.getSession().setAttribute("msgType", "success");
        } else if (upcidResponse.getStatus() == HttpStatus.EXPECTATION_FAILED) {
            request.getSession().setAttribute("msgType", "error");
        } else {
            request.getSession().setAttribute("msgType", "warning");
        }
        return "redirect:/page/Complaints";
    }

    @RequestMapping(value = "/Feedback", method = RequestMethod.GET)
    public String feedback(ModelMap map, HttpServletRequest request, Principal principal) {
        map.addAttribute("feedback_form", new FeedBack());
        map.addAttribute("newsListResp", newsService.getAllNews());
        return "Feedback";
    }

    @RequestMapping(value = "/saveFeedback", method = RequestMethod.POST)
    public String feedback(@ModelAttribute("feedback_form") FeedBack feedBack, BindingResult result, ModelMap map, HttpServletRequest request, Principal principal) {
        UpcidResponse upcidResponse = null;
        if (result.hasErrors()) {
            return "Feedback";
        } else {
            upcidResponse = feedBackService.addFeedBack(feedBack);
            request.getSession().setAttribute("msg", upcidResponse.getMessage());
            if (upcidResponse.getStatus() == HttpStatus.OK) {
                request.getSession().setAttribute("msgType", "success");
            } else if (upcidResponse.getStatus() == HttpStatus.EXPECTATION_FAILED) {
                request.getSession().setAttribute("msgType", "error");
            } else {
                request.getSession().setAttribute("msgType", "warning");
            }
            return "redirect:/page/Feedback";

        }
    }

//    view news at news page for member
    @RequestMapping(value = "/news", method = RequestMethod.GET)
    public String getNewslst(ModelMap map, HttpServletRequest request, Principal principal) {
        map.addAttribute("newsListResp", newsService.getAllNews());
        return "News";
    }

    @RequestMapping(value = "/news/{id}", method = RequestMethod.GET)
    public String getNewslst(@PathVariable Integer id, ModelMap map, HttpServletRequest request, Principal principal) {
        map.addAttribute("newsListResp", newsService.getAllNews());
        map.addAttribute("newsDetailResponse", newsService.getNewsById(id));
        return "newsdetail";
    }

    @RequestMapping(value = "/memberregister")
    public String memberRegistrationfromindexpage(ModelMap map, HttpServletRequest request, Principal principal) {
        MemberDetailModel obj = new MemberDetailModel();
        List<NomineeModel> lst = new ArrayList();
        NomineeModel modee = new NomineeModel();
        modee.setId(-1);
        lst.add(modee);
        obj.setNomineemodel(lst);
        List<MemberWitnessModel> witnesslst = new ArrayList<>();
        MemberWitnessModel memberwitnessmodel1= new MemberWitnessModel();
        memberwitnessmodel1.setwId(-1);
        MemberWitnessModel memberwitnessmodel2= new MemberWitnessModel();
        memberwitnessmodel2.setwId(-1);
        witnesslst.add(memberwitnessmodel1);
        witnesslst.add(memberwitnessmodel2);
        obj.setMemberwitnessmodel(witnesslst);
        
        map.addAttribute("member_form", obj);
        map.addAttribute("rankList", rankService.getAllrankformember(null));
        map.addAttribute("categoryList", categoryService.getAllCategoryforMember(null));
        map.addAttribute("sectorlist", sectorService.getAllSectorforMember(null));
        map.addAttribute("postingList", postingService.getAllPostingforMember(null));
        map.addAttribute("paymentList", paymentModeService.getAllPaymentMode(null));
        return "memberregister";
  
    }
    
    
   @RequestMapping(value = "/register", method = RequestMethod.POST)
    public String addnewMember(@ModelAttribute("member_form") MemberDetailModel memberDetailModel, ModelMap map, BindingResult result, HttpServletRequest request, Principal principal) throws IOException {
        UpcidResponse upcidResponse = null;
        if (result.hasErrors()) {
            map.addAttribute("member_form", memberDetailModel);
            map.addAttribute("rankList", rankService.getAllrankformember(null));
            map.addAttribute("categoryList", categoryService.getAllCategoryforMember(null));
            map.addAttribute("sectorlist", sectorService.getAllSectorforMember(null));
            map.addAttribute("postingList", postingService.getAllPostingforMember(null));
            map.addAttribute("paymentList", paymentModeService.getAllPaymentMode(null));
            return "memberregister";
        } else {
            String filename = null;
            String firstName = null;
            String flocation = null;
            String filelocationfordb = null;
            MultipartFile fl = null;
            flocation = uploadDir + "/fileUpload/" + memberDetailModel.getPnoNumber();
            fileStorageLocation = Paths.get(flocation).toAbsolutePath().normalize();
            File location = fileStorageLocation.toFile();
            if (!location.exists()) {
                location.mkdirs();
            }

            if (memberDetailModel!= null && memberDetailModel.getMemberId()!= null && memberDetailModel.getMemberId()> 0) {
                fl = memberDetailModel.getMemberphoto();
                if (fl != null && (int) fl.getSize() > 0) {
                    filename = fl.getOriginalFilename();
                    int i = filename.indexOf(".");
                    firstName = filename.substring(0, i);
                    firstName = "profile_" + memberDetailModel.getPnoNumber() + "_" + UtilDate.formateDateToStringddMMyyyyhhmmss(new Date());
//                filelocationfordb =location.getPath()+"/"+firstName+filename.substring(i);
                    filelocationfordb = "/fileUpload/" + memberDetailModel.getPnoNumber() + "/" + firstName + filename.substring(i);
                    memberDetailModel.setProfileulr(filelocationfordb);
                    upcidResponse = fileUploadService.UploadFile(memberDetailModel.getMemberphoto(), location, firstName + filename.substring(i));
                }
                fl = memberDetailModel.getMembersignature();
                if (fl != null && (int) fl.getSize() > 0) {
                    filename = fl.getOriginalFilename();
                    int i = filename.indexOf(".");
                    firstName = filename.substring(0, i);
                    firstName = "sign_" + memberDetailModel.getPnoNumber() + "_" + UtilDate.formateDateToStringddMMyyyyhhmmss(new Date());
//                filelocationfordb =location.getPath()+"\\"+firstName+filename.substring(i);
                    filelocationfordb = "/fileUpload/" + memberDetailModel.getPnoNumber() + "/" + firstName + filename.substring(i);
                    memberDetailModel.setSignurl(filelocationfordb);
                    upcidResponse = fileUploadService.UploadFile(memberDetailModel.getMembersignature(), location, firstName + filename.substring(i));
                }
                fl = memberDetailModel.getMemberAccountOpenningform();
                if (fl != null && (int) fl.getSize() > 0) {
                    filename = fl.getOriginalFilename();
                    int i = filename.indexOf(".");
                    firstName = filename.substring(0, i);
                    firstName = "reg_" + memberDetailModel.getPnoNumber() + "_" + UtilDate.formateDateToStringddMMyyyyhhmmss(new Date());
//                 filelocationfordb =location.getPath()+"\\"+firstName+filename.substring(i);
                    filelocationfordb = "/fileUpload/" + memberDetailModel.getPnoNumber() + "/" + firstName + filename.substring(i);
                    memberDetailModel.setAccountOpenFormurl(filelocationfordb);
                    upcidResponse = fileUploadService.UploadFile(memberDetailModel.getMemberAccountOpenningform(), location, firstName + filename.substring(i));
                }
                
                List<NomineeModel>Nomineemodellst= memberDetailModel.getNomineemodel();
                if(Nomineemodellst!=null && !Nomineemodellst.isEmpty()){
                    int index=0;
                 for(NomineeModel nomineemodel:Nomineemodellst){
                  fl = nomineemodel.getNomineesign();
                    if(fl!=null && (int) fl.getSize() > 0){
                    filename = fl.getOriginalFilename();
                    int i = filename.indexOf(".");
                    firstName = filename.substring(0, i);
                    firstName = "nomineesign_" + memberDetailModel.getPnoNumber() + "_" + UtilDate.formateDateToStringddMMyyyyhhmmss(new Date());
                    filelocationfordb = "/fileUpload/" + memberDetailModel.getPnoNumber() + "/" + firstName + filename.substring(i);
                    memberDetailModel.getNomineemodel().get(index++).setSign(filelocationfordb);
                    upcidResponse = fileUploadService.UploadFile(nomineemodel.getNomineesign(), location, firstName + filename.substring(i));
                   }
                 }
               }
                 List<MemberWitnessModel>memberWitnesmodel=memberDetailModel.getMemberwitnessmodel();
                 if(memberWitnesmodel!=null && !memberWitnesmodel.isEmpty()){
                       int index=0;
                    for(MemberWitnessModel memberwitnessmodel:memberWitnesmodel){
                    fl = memberwitnessmodel.getwSign();
                    if(fl!=null && (int) fl.getSize() > 0){
                    filename = fl.getOriginalFilename();
                    int i = filename.indexOf(".");
                    firstName = filename.substring(0, i);
                    firstName = "witnesssign_" + memberDetailModel.getPnoNumber() + "_" + UtilDate.formateDateToStringddMMyyyyhhmmss(new Date());
                    filelocationfordb = "/fileUpload/" + memberDetailModel.getPnoNumber() + "/" + firstName + filename.substring(i);
                     memberDetailModel.getMemberwitnessmodel().get(index++).setwSignUrl(filelocationfordb);
                    upcidResponse = fileUploadService.UploadFile(memberwitnessmodel.getwSign(), location, firstName + filename.substring(i));
                   }
                 }
              }
                 //member detail will be updated after login that's why principal is not set to null here.
               upcidResponse = memberDetailService.updatenewMemberDetail(memberDetailModel, request.getRemoteAddr(), principal.getName());

            } else {
                
                fl = memberDetailModel.getMemberphoto();
                if (fl != null) {
                    filename = fl.getOriginalFilename();
                    int i = filename.indexOf(".");
                    firstName = filename.substring(0, i);
                    firstName = "profile_" + memberDetailModel.getPnoNumber() + "_" + UtilDate.formateDateToStringddMMyyyyhhmmss(new Date());
//                filelocationfordb =location.getPath()+"\\"+firstName+filename.substring(i);
                    filelocationfordb = "/fileUpload/" + memberDetailModel.getPnoNumber() + "/" + firstName + filename.substring(i);
                    memberDetailModel.setProfileulr(filelocationfordb);
                    upcidResponse = fileUploadService.UploadFile(memberDetailModel.getMemberphoto(), location, firstName + filename.substring(i));
                }
                fl = memberDetailModel.getMembersignature();
                if (fl != null) {
                    filename = fl.getOriginalFilename();
                    int i = filename.indexOf(".");
                    firstName = filename.substring(0, i);
                    firstName = "sign_" + memberDetailModel.getPnoNumber() + "_" + UtilDate.formateDateToStringddMMyyyyhhmmss(new Date());
                    filelocationfordb = "/fileUpload/" + memberDetailModel.getPnoNumber() + "/" + firstName + filename.substring(i);
                    memberDetailModel.setSignurl(filelocationfordb);
                    upcidResponse = fileUploadService.UploadFile(memberDetailModel.getMembersignature(), location, firstName + filename.substring(i));
                }
                fl = memberDetailModel.getMemberAccountOpenningform();
                if (fl != null) {
                    filename = fl.getOriginalFilename();
                    int i = filename.indexOf(".");
                    firstName = filename.substring(0, i);
                    firstName = "reg_" + memberDetailModel.getPnoNumber() + "_" + UtilDate.formateDateToStringddMMyyyyhhmmss(new Date());
//                 filelocationfordb =location.getPath()+"\\"+firstName+filename.substring(i);
                    filelocationfordb = "/fileUpload/" + memberDetailModel.getPnoNumber() + "/" + firstName + filename.substring(i);
                    memberDetailModel.setAccountOpenFormurl(filelocationfordb);
                    upcidResponse = fileUploadService.UploadFile(memberDetailModel.getMemberAccountOpenningform(), location, firstName + filename.substring(i));
                }
                
                List<NomineeModel>Nomineemodellst= memberDetailModel.getNomineemodel();
                if(Nomineemodellst!=null && !Nomineemodellst.isEmpty()){
                    int index=0;
                 for(NomineeModel nomineemodel:Nomineemodellst){
                  fl = nomineemodel.getNomineesign();
                    if(fl!=null && (int) fl.getSize() > 0){
                    filename = fl.getOriginalFilename();
                    int i = filename.indexOf(".");
                    firstName = filename.substring(0, i);
                    firstName = "nomineesign_" + memberDetailModel.getPnoNumber() + "_" + UtilDate.formateDateToStringddMMyyyyhhmmss(new Date());
                    filelocationfordb = "/fileUpload/" + memberDetailModel.getPnoNumber() + "/" + firstName + filename.substring(i);
                    memberDetailModel.getNomineemodel().get(index++).setSign(filelocationfordb);
                    upcidResponse = fileUploadService.UploadFile(nomineemodel.getNomineesign(), location, firstName + filename.substring(i));
                   }
                 }
                
                 }
                 List<MemberWitnessModel>memberWitnesmodel=memberDetailModel.getMemberwitnessmodel();
                 if(memberWitnesmodel!=null && !memberWitnesmodel.isEmpty()){
                       int index=0;
                    for(MemberWitnessModel memberwitnessmodel:memberWitnesmodel){
                    fl = memberwitnessmodel.getwSign();
                    if(fl!=null && (int) fl.getSize() > 0){
                    filename = fl.getOriginalFilename();
                    int i = filename.indexOf(".");
                    firstName = filename.substring(0, i);
                    firstName = "witnesssign_" + memberDetailModel.getPnoNumber() + "_" + UtilDate.formateDateToStringddMMyyyyhhmmss(new Date());
                    filelocationfordb = "/fileUpload/" + memberDetailModel.getPnoNumber() + "/" + firstName + filename.substring(i);
                     memberDetailModel.getMemberwitnessmodel().get(index++).setwSignUrl(filelocationfordb);
                    upcidResponse = fileUploadService.UploadFile(memberwitnessmodel.getwSign(), location, firstName + filename.substring(i));
                   }
                 }
              }
 
                upcidResponse = memberDetailService.addnewMemberDetail(memberDetailModel, request.getRemoteAddr(),null);
            }
            request.getSession().setAttribute("msg", upcidResponse.getMessage());

            if (upcidResponse.getStatus() == HttpStatus.OK) {
                request.getSession().setAttribute("msgType", "success");
            } else if (upcidResponse.getStatus() == HttpStatus.EXPECTATION_FAILED) {
                request.getSession().setAttribute("msgType", "error");
            } else {
                request.getSession().setAttribute("msgType", "warning");
            }
            return "redirect:/page/memberregister";
        }

    }
  
    
    

}
