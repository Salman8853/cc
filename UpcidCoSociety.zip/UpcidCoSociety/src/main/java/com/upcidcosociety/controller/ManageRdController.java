/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.controller;

import com.upcidcosociety.dtob.MemberDetail;
import com.upcidcosociety.dtob.RdentryDetail;
import com.upcidcosociety.model.MemberDetailModelforRd;
import com.upcidcosociety.model.MemberRdCuttingModel;
import com.upcidcosociety.model.RDGeneraterPassBookModel;
import com.upcidcosociety.model.RdDetailsRequestModel;
import com.upcidcosociety.service.MemberDetailService;
import com.upcidcosociety.service.RdService;
import com.upcidcosociety.util.GeneratePassBookForRd;
import com.upcidcosociety.util.UpcidResponse;
import java.security.Principal;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

/**
 *
 * @author m.salman
 */
@Controller
@RequestMapping("/upcid")
public class ManageRdController {

    @Autowired
    private MemberDetailService memberDetailService;

    @Autowired
    private RdService rdService;
    
    @Value("${site.url}")
    String siteurl;
//    @Autowired
//    private RdJobSchedularService2 rdjobschedularservice;

    @RequestMapping(value = "/rd", method = RequestMethod.GET)
    public String openRd(ModelMap map, HttpServletRequest request, Principal principal) {
        UpcidResponse<MemberDetailModelforRd> response = new UpcidResponse();
        response.setStatus(HttpStatus.NOT_FOUND);
        response.setData(null);
        map.addAttribute("memberdetailResponse", response);
        map.addAttribute("memberNamesListWithPnoNumbers", memberDetailService.getAllMemberDetailforRd(principal.getName()));
        map.addAttribute("openrd_form", new RdDetailsRequestModel());
        return "openrd";
    }

    @RequestMapping(value = "/rd/{pnoNumber}", method = RequestMethod.GET)
    public String openRd(@PathVariable String pnoNumber, ModelMap map, HttpServletRequest request, Principal principal) {
        UpcidResponse<MemberDetailModelforRd> upcidResponse = null;
        upcidResponse = memberDetailService.getmemberDetailBypnoNumber(pnoNumber, principal.getName());
        if (upcidResponse.getStatus() == HttpStatus.OK) {
            map.addAttribute("memberNamesListWithPnoNumbers", memberDetailService.getAllMemberDetailforRd(principal.getName()));
            map.addAttribute("memberdetailResponse", upcidResponse);
            RdDetailsRequestModel rddetailsrequestmodel=new RdDetailsRequestModel();
                   rddetailsrequestmodel.setPnoNumber(pnoNumber);              
            map.addAttribute("openrd_form", rddetailsrequestmodel);
            return "openrd";
        } else {
            request.getSession().setAttribute("msg", upcidResponse.getMessage());

            if (upcidResponse.getStatus() == HttpStatus.OK) {
                request.getSession().setAttribute("msgType", "success");
            } else if (upcidResponse.getStatus() == HttpStatus.EXPECTATION_FAILED) {
                request.getSession().setAttribute("msgType", "error");
            } else {
                request.getSession().setAttribute("msgType", "warning");
            }
            return "redirect:/upcid/rd";
        }
    }

    @RequestMapping(value = "/rd/save", method = RequestMethod.POST)
    public String saveNewRd(@ModelAttribute("openrd_form") RdDetailsRequestModel rdDetailsRequestModel,BindingResult result, ModelMap map, HttpServletRequest request, Principal principal) {
       UpcidResponse<RdentryDetail> upcidResponse = null;   
        if(result.hasErrors()){
           map.addAttribute("memberNamesListWithPnoNumbers", memberDetailService.getAllMemberDetailforRd(principal.getName()));
           return "openrd";
           }else{
              if(rdDetailsRequestModel!=null && rdDetailsRequestModel.getRdSerialNo()!=null && rdDetailsRequestModel.getRdSerialNo()>0){
               upcidResponse=rdService.updateRd(rdDetailsRequestModel, principal.getName());   
               }else{
               upcidResponse=rdService.saveNewRd(rdDetailsRequestModel, principal.getName());   
               }
        
            }
        
            request.getSession().setAttribute("msg", upcidResponse.getMessage());
            if (upcidResponse.getStatus() == HttpStatus.OK) {
                request.getSession().setAttribute("msgType", "success");
            } else if (upcidResponse.getStatus() == HttpStatus.EXPECTATION_FAILED) {
                request.getSession().setAttribute("msgType", "error");
            } else {
                request.getSession().setAttribute("msgType", "warning");
            }
            return "redirect:/upcid/showrd/"+rdDetailsRequestModel.getPnoNumber();
        }
    
 

    @RequestMapping(value = "/edit/{pnoNumber}/{serialno}", method = RequestMethod.GET)
    public String editmemberRd(@PathVariable String pnoNumber,@PathVariable Integer serialno,ModelMap map, HttpServletRequest request, Principal principal) {
       UpcidResponse<RdDetailsRequestModel> response = null; 
        map.addAttribute("memberdetailResponse", memberDetailService.getmemberDetailBypnoNumber(pnoNumber, principal.getName()));
        response=rdService.getmemberRdByrdSerialNo(pnoNumber,serialno,principal.getName());
        map.addAttribute("openrd_form",response.getData());
        map.addAttribute("memberNamesListWithPnoNumbers", memberDetailService.getAllMemberDetailforRd(principal.getName()));
//        map.addAttribute("pnoNumber",pnoNumber);
        return "openrd";
    }
    
    @RequestMapping(value = "/showrd", method = RequestMethod.GET)
    public String memberRdList(ModelMap map, HttpServletRequest request, Principal principal) {
        UpcidResponse<MemberDetail> response = new UpcidResponse();
        response.setStatus(HttpStatus.NOT_FOUND);
        response.setData(null);
        map.addAttribute("memberdetailResponse", response);
        map.addAttribute("memberdetailResponseList", response);
        map.addAttribute("memberNamesListWithPnoNumbers", memberDetailService.getAllMemberDetailforRd(principal.getName()));
        map.addAttribute("rdcutting_form",new MemberRdCuttingModel());
        return "showall";
    }
    
    @RequestMapping(value = "/showrd/{pnoNumber}", method = RequestMethod.GET)
    public String showMemberRdList(@PathVariable String pnoNumber,ModelMap map, HttpServletRequest request, Principal principal) {
        map.addAttribute("memberdetailResponse", memberDetailService.getmemberDetailBypnoNumber(pnoNumber, principal.getName()));
        map.addAttribute("memberdetailResponseList", rdService.getAllmemberRdListById(pnoNumber,principal.getName()));
        map.addAttribute("memberNamesListWithPnoNumbers", memberDetailService.getAllMemberDetailforRd(principal.getName()));
        map.addAttribute("rdcutting_form",new MemberRdCuttingModel());
        map.addAttribute("pnoNumber",pnoNumber);
        return "showall";
    }
    @RequestMapping(value = "rd/cutting", method = RequestMethod.POST)
    public String showmemberrdlist(@ModelAttribute("rdcutting_form")MemberRdCuttingModel memberrdcuttingmodel, ModelMap map,BindingResult result, HttpServletRequest request, Principal principal) {
       UpcidResponse<Object> upcidResponse = null;
        if(result.hasErrors()){

        }else{
          upcidResponse= rdService.updatememberRdmonthwiseListByrdaccountNo(memberrdcuttingmodel, principal.getName());
        }
           request.getSession().setAttribute("msg", upcidResponse.getMessage());
            if (upcidResponse.getStatus() == HttpStatus.OK) {
                request.getSession().setAttribute("msgType", "success");
            } else if (upcidResponse.getStatus() == HttpStatus.EXPECTATION_FAILED) {
                request.getSession().setAttribute("msgType", "error");
            } else {
                request.getSession().setAttribute("msgType", "warning");
            }
            if(memberrdcuttingmodel.getPnoNumber()!=null){
            return "redirect:/upcid/showrd/"+memberrdcuttingmodel.getPnoNumber();
             }else{
            return "redirect:/upcid/showrd";
              }
    }
      
    @RequestMapping(value = "rd/generatepassbook", method = RequestMethod.GET)
    public ResponseEntity generaterdpassbook(@RequestParam String pnonumber ,@RequestParam Integer rdaccountno,@RequestParam Integer rdserialnumber,ModelMap map, HttpServletRequest request, Principal principal) {
       String logo = siteurl + "/assets/assets_admin/images/favicon.png";
        UpcidResponse<RDGeneraterPassBookModel> response= rdService.getrddetailforPassbook(pnonumber, rdaccountno, rdserialnumber, principal.getName());
        if(response.getStatus()==HttpStatus.OK){
        byte[] bis = GeneratePassBookForRd.generatePassbookforrd(response.getData(),logo);
//        fdcertificatemodel, logo, watermarkimage
        HttpHeaders respHeaders = new HttpHeaders();
        respHeaders.add("Content-Disposition", "inline; filename=checklist.pdf");
//        respHeaders.add("Link", favicon + "; rel=\"shortcut icon\"");
        MediaType mediaType = MediaType.parseMediaType("application/pdf");
        respHeaders.setContentType(mediaType);
        respHeaders.setCacheControl("must-revalidate, post-check=0, pre-check=0");
        return new ResponseEntity(new ByteArrayResource(bis), respHeaders, HttpStatus.OK);
         }else{
        
            //return to error page
            return null; 
            
           }
       
    }
    

}
