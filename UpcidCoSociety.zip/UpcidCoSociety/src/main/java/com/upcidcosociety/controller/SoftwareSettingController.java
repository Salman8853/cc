/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.controller;

import com.upcidcosociety.dtob.SoftwareSetings;
import com.upcidcosociety.dtob.SwRateSetting;
import com.upcidcosociety.service.SoftwareSetingsService;
import com.upcidcosociety.util.UpcidResponse;
import java.security.Principal;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 *
 * @author m.salman
 */
@Controller
@RequestMapping("/upcid")
public class SoftwareSettingController {
    
  @Autowired 
  private SoftwareSetingsService softwareSetingsService;
    
    
    @RequestMapping(value = "/newsetting", method = RequestMethod.GET)
     public String newsetting(ModelMap map, HttpServletRequest request, Principal principal){
         SoftwareSetings softwareSetings = new SoftwareSetings();
          List<SwRateSetting>swRtsettingList=new ArrayList<>();
          SwRateSetting SwRateSetting=null;
          int j=1;
           for(int i=0;i<3;i++){
             
              SwRateSetting=new SwRateSetting();
              //we do this bcoz list size is 0 so cant render table in jsp page so set these values
               SwRateSetting.setId(-1);
               SwRateSetting.setYear(i);
               swRtsettingList.add(SwRateSetting);
             j=j+2;
           }
           softwareSetings.setSwRtsettingList(swRtsettingList);
         
          map.addAttribute("setting_form",softwareSetings);
          return "softwaresetting";
    }
    
     @RequestMapping(value = "/addsetting", method = RequestMethod.POST)
     public String addsetting(@ModelAttribute("setting_form")SoftwareSetings softwareSetings ,ModelMap map, BindingResult result, HttpServletRequest request, Principal principal){
         UpcidResponse upcidResponse = null; 
         if(result.hasErrors()){
         
         
          }
         
          upcidResponse=softwareSetingsService.saveSoftwareSetings(softwareSetings,principal.getName());      
          request.getSession().setAttribute("msg", upcidResponse.getMessage());
         if(upcidResponse.getStatus()== HttpStatus.OK){
           request.getSession().setAttribute("msgType", "success");
          }else if (upcidResponse.getStatus() == HttpStatus.EXPECTATION_FAILED) {
            request.getSession().setAttribute("msgType", "error");
         } else {
            request.getSession().setAttribute("msgType", "warning");
        }
         return "redirect:/upcid/newsetting";        
    }
     
    
    
}
