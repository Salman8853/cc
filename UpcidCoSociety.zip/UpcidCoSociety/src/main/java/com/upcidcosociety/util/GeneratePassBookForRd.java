/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.util;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.upcidcosociety.model.PassBookModel;
import com.upcidcosociety.model.RDGeneraterPassBookModel;
import java.io.ByteArrayOutputStream;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author m.salman
 */
public class GeneratePassBookForRd {

    private static final Logger logger = LoggerFactory.getLogger(GeneratePassBookForRd.class);

    public static byte[] generatePassbookforrd(RDGeneraterPassBookModel rdgeneraterpassbookmodel,String logo) {
//        FdCertificateModel fdcertificatemodel,String logo,String watermarkimage
        Document document = new Document(PageSize.A4, 36, 36, 36, 36);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try {
            PdfWriter writer = PdfWriter.getInstance(document, out);
            document.open();

            Rectangle rect = new Rectangle(580, 800, 15, 15);
            rect.enableBorderSide(1);
            rect.enableBorderSide(2);
            rect.enableBorderSide(4);
            rect.enableBorderSide(8);
            rect.setBorderColor(BaseColor.BLACK);
            document.add(rect);
            Paragraph para1 = new Paragraph("Reccuring Deposit Passbook");
            para1.setAlignment(Paragraph.ALIGN_CENTER);
            para1.setSpacingBefore(50);
            para1.setSpacingAfter(02);
            document.add(para1);
            document.addTitle("RD Passbook");

            Image image = Image.getInstance(logo);
            image.setAbsolutePosition(260, 760);
            document.add(image);

            Font paraFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD);
            PdfPTable compdetail = new PdfPTable(2);
            compdetail.setSpacingBefore(10);
            compdetail.setWidthPercentage(100);
//            compdetail.setSpacingAfter(10);
            paraFont.setSize(8);
            PdfPCell c1 = new PdfPCell(new Phrase("Member Name :"+rdgeneraterpassbookmodel.getMemberName(), paraFont));
            c1.setHorizontalAlignment(Element.ALIGN_LEFT);
            c1.setBorder(Rectangle.NO_BORDER);
            compdetail.addCell(c1);
//            String cerinomber = fdcertificatemodel.getFdCertificateNo() != null ? fdcertificatemodel.getFdCertificateNo() : "N/A";

            c1 = new PdfPCell(new Phrase("RD Account No :"+rdgeneraterpassbookmodel.getRdaccNo(), paraFont));
            c1.setHorizontalAlignment(Element.ALIGN_RIGHT);
            c1.setBorder(Rectangle.NO_BORDER);
            compdetail.addCell(c1);
            
            c1 = new PdfPCell(new Phrase("Father Name :"+rdgeneraterpassbookmodel.getFatherName(), paraFont));
            c1.setHorizontalAlignment(Element.ALIGN_LEFT);
            c1.setBorder(Rectangle.NO_BORDER);
            compdetail.addCell(c1);
            
            c1 = new PdfPCell(new Phrase("RD Serial No :"+rdgeneraterpassbookmodel.getRdSerialNo(), paraFont));
            c1.setHorizontalAlignment(Element.ALIGN_RIGHT);
            c1.setBorder(Rectangle.NO_BORDER);
            compdetail.addCell(c1);
            
            c1 = new PdfPCell(new Phrase("Payment Mode :"+rdgeneraterpassbookmodel.getPaymentMode(), paraFont));
            c1.setHorizontalAlignment(Element.ALIGN_LEFT);
            c1.setBorder(Rectangle.NO_BORDER);
            compdetail.addCell(c1);
            
            c1 = new PdfPCell(new Phrase("RD Duration :"+rdgeneraterpassbookmodel.getPod(), paraFont));
            c1.setHorizontalAlignment(Element.ALIGN_RIGHT);
            c1.setBorder(Rectangle.NO_BORDER);
            compdetail.addCell(c1);
            
            document.add(compdetail);
            
            PdfPTable passbookcell  = new PdfPTable(5);
            passbookcell.setSpacingBefore(10);
            passbookcell.setWidthPercentage(100);
            
            Font tableFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD);
            tableFont.setSize(10);
            
            PdfPCell c2 = new PdfPCell(new Phrase("SrNo", tableFont));
            c2.setHorizontalAlignment(Element.ALIGN_LEFT);
            c2.setBorder(Rectangle.NO_BORDER);
            passbookcell.addCell(c2);
            c2 = new PdfPCell(new Phrase("Date", tableFont));
            c2.setHorizontalAlignment(Element.ALIGN_LEFT);
            c2.setBorder(Rectangle.NO_BORDER);
            passbookcell.addCell(c2);
            c2 = new PdfPCell(new Phrase("Deposite", tableFont));
            c2.setHorizontalAlignment(Element.ALIGN_LEFT);
            c2.setBorder(Rectangle.NO_BORDER);
            passbookcell.addCell(c2);
            c2 = new PdfPCell(new Phrase("Total", tableFont));
            c2.setHorizontalAlignment(Element.ALIGN_LEFT);
            c2.setBorder(Rectangle.NO_BORDER);
            passbookcell.addCell(c2);
            c2 = new PdfPCell(new Phrase("Signature", tableFont));
            c2.setHorizontalAlignment(Element.ALIGN_LEFT);
            c2.setBorder(Rectangle.NO_BORDER);
            passbookcell.addCell(c2);
            List<PassBookModel>pbmodellst=rdgeneraterpassbookmodel.getPbmodelList();
            if(pbmodellst!=null && pbmodellst.size()>0){
            int srno=1;
            for(PassBookModel passbookmodel:pbmodellst){
            tableFont = FontFactory.getFont(FontFactory.COURIER);
            tableFont.setSize(10);  
            c2 = new PdfPCell(new Phrase(srno+"", tableFont));
            c2.setHorizontalAlignment(Element.ALIGN_LEFT);
            c2.setBorder(Rectangle.NO_BORDER);
            passbookcell.addCell(c2);
            c2 = new PdfPCell(new Phrase(passbookmodel.getPremiumedepositeDate()!=null?UtilDate.formatetdateToString_dd_MM_yyyy(passbookmodel.getPremiumedepositeDate()):" ", tableFont));
            c2.setHorizontalAlignment(Element.ALIGN_LEFT);
            c2.setBorder(Rectangle.NO_BORDER);
            passbookcell.addCell(c2);
            c2 = new PdfPCell(new Phrase(passbookmodel.getAmount()!=null?passbookmodel.getAmount()+"":"0.0", tableFont));
            c2.setHorizontalAlignment(Element.ALIGN_LEFT);
            c2.setBorder(Rectangle.NO_BORDER);
            passbookcell.addCell(c2);
            c2 = new PdfPCell(new Phrase(passbookmodel.getTotal()!=null?passbookmodel.getTotal()+"":"0.0", tableFont));
            c2.setHorizontalAlignment(Element.ALIGN_LEFT);
            c2.setBorder(Rectangle.NO_BORDER);
            passbookcell.addCell(c2);
            c2 = new PdfPCell(new Phrase(" ", tableFont));
            c2.setHorizontalAlignment(Element.ALIGN_LEFT);
            c2.setBorder(Rectangle.NO_BORDER);
            passbookcell.addCell(c2); 
            srno++;
          }
        }        
          document.add(passbookcell);

            
            document.close();
        } catch (DocumentException ex) {
            logger.error(" Documentation  error occurred:" + ex, ex);
        } catch (Exception e) {
            logger.error("Error occurred in Generate PassBook for Rd:", e);
        }
        return out.toByteArray();

    }
}
