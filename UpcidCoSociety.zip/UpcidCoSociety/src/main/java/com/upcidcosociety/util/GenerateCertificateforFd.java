/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.util;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.upcidcosociety.model.FdCertificateModel;
import java.io.ByteArrayOutputStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author m.salman
 */
public class GenerateCertificateforFd {

    private static final Logger logger = LoggerFactory.getLogger(GenerateCertificateforFd.class);

//    PDFResponseModel pdfresponsemodel, String categoryType, String imageurl
    public static byte[] generateCertificateforfd(FdCertificateModel fdcertificatemodel,String logo,String watermarkimage) {
        
        Document document = new Document(PageSize.A5.rotate(), 36, 36, 36, 36);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try {
            
            PdfWriter writer = PdfWriter.getInstance(document, out);
            WatermarkPageEvent event = new WatermarkPageEvent();
            event.setImageurl(watermarkimage);
            writer.setPageEvent(event);
            document.open();            
            Paragraph para1 = new Paragraph("Fixed Deposit Receipt");
            para1.setAlignment(Paragraph.ALIGN_CENTER);
            para1.setSpacingAfter(02);
            document.add(para1);
            document.addTitle("FD Certificate");
            
            
            
            Rectangle rect = new Rectangle(580, 800, 15, 15);
            rect.enableBorderSide(1);
            rect.enableBorderSide(2);
            rect.enableBorderSide(4);
            rect.enableBorderSide(8);
            rect.setBorderColor(BaseColor.BLACK);
//            rect.setBorderWidth(2);
            document.add(rect);
            
            Image image = Image.getInstance(logo);
            image.setAbsolutePosition(260, 300);
            document.add(image);
            Font paraFont = FontFactory.getFont(FontFactory.HELVETICA);
            
            String Declaration=" FORENSIC SCIENCE LABORATORIES UTTAR PRADESH SALARIED EMPLOYEE SAHEKARI";
            Paragraph para = new Paragraph(Declaration, paraFont);
            para.setAlignment(para.ALIGN_LEFT);
            
            String Declaration2=" CREDIT SOCIETY LTD.";
            Paragraph para2 = new Paragraph(Declaration2, paraFont);
            para2.setAlignment(para2.ALIGN_CENTER);
            
            String Declaration3="Shadab Colony, Mahanagar,Luckonw";
            Paragraph para3 = new Paragraph(Declaration3, paraFont);
            para3.setAlignment(para3.ALIGN_CENTER);
            
            para.setSpacingBefore(70);
            para3.setSpacingAfter(10);
            document.add(para);
            document.add(para2);
            document.add(para3);
            
            PdfPTable compdetail = new PdfPTable(2);
            compdetail.setSpacingBefore(10);
            compdetail.setWidthPercentage(100); 
//            compdetail.setSpacingAfter(10);
            paraFont.setSize(12);
            

            PdfPCell c1 = new PdfPCell(new Phrase("Book No :", paraFont));
            c1.setHorizontalAlignment(Element.ALIGN_LEFT);
            c1.setBorder(Rectangle.NO_BORDER);
            compdetail.addCell(c1);
          String cerinomber=fdcertificatemodel.getFdCertificateNo()!=null?fdcertificatemodel.getFdCertificateNo():"N/A";
   
            c1 = new PdfPCell(new Phrase("FD Certificate Number :"+cerinomber, paraFont));
            c1.setHorizontalAlignment(Element.ALIGN_RIGHT);
            c1.setBorder(Rectangle.NO_BORDER);
            compdetail.addCell(c1);
          String fdledgerno=fdcertificatemodel.getFdLedgerNo()!=null?fdcertificatemodel.getFdLedgerNo():"";
            c1 = new PdfPCell(new Phrase("FD Ledger No :"+fdledgerno, paraFont));
            c1.setHorizontalAlignment(Element.ALIGN_LEFT);
            c1.setBorder(Rectangle.NO_BORDER);
            compdetail.addCell(c1);

          String recieptnumber=fdcertificatemodel.getRecieptNo()!=null?fdcertificatemodel.getRecieptNo():"N/A";
   
            c1 = new PdfPCell(new Phrase("Receipt No :"+recieptnumber, paraFont));
            c1.setHorizontalAlignment(Element.ALIGN_RIGHT);
            c1.setBorder(Rectangle.NO_BORDER);
            compdetail.addCell(c1);
          String openningDate=fdcertificatemodel.getDateOfOpenning()!=null?fdcertificatemodel.getDateOfOpenning():"";
            
            c1 = new PdfPCell(new Phrase("Date of Issue :"+openningDate, paraFont));
            c1.setHorizontalAlignment(Element.ALIGN_LEFT);
            c1.setBorder(Rectangle.NO_BORDER);
            compdetail.addCell(c1);

          String maturityDate=fdcertificatemodel.getDateOfMaturity()!=null?fdcertificatemodel.getDateOfMaturity():"";
   
            c1 = new PdfPCell(new Phrase("Date of Maturity :"+maturityDate, paraFont));
            c1.setHorizontalAlignment(Element.ALIGN_RIGHT);
            c1.setBorder(Rectangle.NO_BORDER);
            compdetail.addCell(c1);
           Double depositeamount=fdcertificatemodel.getDepositeAmount()!=null?fdcertificatemodel.getDepositeAmount():0.0;
            c1 = new PdfPCell(new Phrase("Deposit Amount Rs. :"+depositeamount, paraFont));
            c1.setHorizontalAlignment(Element.ALIGN_LEFT);
            c1.setBorder(Rectangle.NO_BORDER);
            compdetail.addCell(c1);
           Double maturityamount=fdcertificatemodel.getMaturityAmount()!=null?fdcertificatemodel.getMaturityAmount():0.0;
            c1 = new PdfPCell(new Phrase("Maturity Amount Rs. :"+maturityamount, paraFont));
            c1.setHorizontalAlignment(Element.ALIGN_RIGHT);
            c1.setBorder(Rectangle.NO_BORDER);
            compdetail.addCell(c1);
            
            
            document.add(compdetail);

            String instruction = "We have received amount of Rs.";
            String instruction1 = fdcertificatemodel.getDepositeAmount()+"("+fdcertificatemodel.getDepositeAmountinWord()+")";
            String rankname=fdcertificatemodel.getRankName()!=null?fdcertificatemodel.getRankName():"N/A";
            String instruction2=  fdcertificatemodel.getMemberName()+" "+rankname;
            String instruction3 = fdcertificatemodel.getPeriod()+"";
            String instruction4 = fdcertificatemodel.getFdrate()+"";
//            String instruction3=" percent per annum subjected to conditions overleaf. (N/A).For questions requiring a written";
            Font boldFont = new Font(Font.FontFamily.TIMES_ROMAN, 14, Font.BOLD);

            Paragraph paragraph1 = new Paragraph(instruction1, boldFont);
            Paragraph paragraph2 = new Paragraph(instruction2, boldFont);
            Paragraph paragraph3 = new Paragraph(instruction3, boldFont);
            Paragraph paragraph4 = new Paragraph(instruction4, boldFont);
            Paragraph paragraph = new Paragraph(instruction+paragraph1.getContent()+" from "+paragraph2.getContent()+" which is repayable "+ paragraph3.getContent() +" year after date with interest at the rate of "+paragraph4.getContent()+" percent per annum subjected to conditions overleaf.", paraFont);
            paragraph.setAlignment(Paragraph.ALIGN_LEFT);
            paragraph.setSpacingBefore(10);
            document.add(paragraph);

            PdfPTable compdetail2 = new PdfPTable(2);
            compdetail2.setSpacingBefore(10);
            compdetail2.setWidthPercentage(100); 
            
            PdfPCell c2 = new PdfPCell(new Phrase("Nomination Token :N/A", paraFont));
            c2.setHorizontalAlignment(Element.ALIGN_LEFT);
            c2.setBorder(Rectangle.NO_BORDER);
            compdetail2.addCell(c2);

   
            c2 = new PdfPCell(new Phrase("Authorized Officer :", paraFont));
            c2.setHorizontalAlignment(Element.ALIGN_RIGHT);
            c2.setBorder(Rectangle.NO_BORDER);
            compdetail2.addCell(c2);
            document.add(compdetail2);
            
            document.close();
            
        } catch (DocumentException ex) {
            
            logger.error(" Documentation  occurred: {0}", ex);
        } catch (Exception ex) {
            logger.error("Error occurred: {0}", ex);
        }
        
        return out.toByteArray();
    }
}
