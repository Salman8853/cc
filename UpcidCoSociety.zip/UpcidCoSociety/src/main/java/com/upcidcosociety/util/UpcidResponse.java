/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.util;

import java.util.Date;
import org.springframework.http.HttpStatus;

/**
 *
 * @author m.salman
 */
public class UpcidResponse<T> {
    private HttpStatus status;
    private String message;
    private T data ;
  

    public UpcidResponse() {
    }

    public UpcidResponse(HttpStatus status, String message) {
        this.status = status;
        this.message = message;
    }

    public HttpStatus getStatus() {
        return status;
    }

    public void setStatus(HttpStatus status) {
        this.status = status;
    }
    

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
    

//    public Object getData() {
//        return data;
//    }
//
//    public void setData(Object data) {
//        this.data = data;
//    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

   
    
}
