/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.util;

/**
 *
 * @author m.salman
 */
public class PageUtil {
    
    public enum PageName 
    { 
      ABOUT_SOCIETY,VISION,MISSION,VALUE,ACHIEVEMENT,ORGANISATION_STRUCTURE,ESTABLISHMENT,FIXED_DEPOSIT_SCHEME,RECURRING_DEPOSIT_SCHEME,LOAN,MEMBER_SHARE_ACCOUNT,DOWNLOAD_FORMS,MEMBERSHIP,NEWS,COMPLAINTS,PHOTO_GALLERY,FEEDBACK,CONTACT_US
    }
    
    public static String getAdminPageName(PageName pageName) {
        String PageName=null;
        switch (pageName) {
            case ABOUT_SOCIETY:
                PageName = "About_Society";
                break;
            case VISION:
                PageName = "Vision";
                break;
            case MISSION:
                PageName = "Mission";
                break;
            case VALUE:
                PageName = "Value";
                break;
           case ACHIEVEMENT:
                PageName = "Achievement";
                break;
            case ORGANISATION_STRUCTURE:
                PageName = "Organisation_Structure";
                break;
           case ESTABLISHMENT:
                PageName = "Establishment";
                break;
            case FIXED_DEPOSIT_SCHEME:
                PageName = "Fixed_Deposit_Scheme";
                break;
           case RECURRING_DEPOSIT_SCHEME:
                PageName = "Recurring_Deposit_Scheme";
                break;
            case LOAN:
                PageName = "Loan";
                break;
            case MEMBER_SHARE_ACCOUNT:
                PageName = "Member_Share_Account";
                break;
           case DOWNLOAD_FORMS: 
                PageName = "Download_Forms";
                break;
           case MEMBERSHIP:
                PageName = "Membership";
                break;      
            case NEWS:
                PageName = "News";
                break;   
             case COMPLAINTS:
                PageName = "Complaints";
                break;
            case PHOTO_GALLERY:
                PageName = "Photo_Gallery";
                break;   
           case FEEDBACK:
                PageName = "Feedback";
                break;
            case CONTACT_US:
                PageName = "Contact_Us";
                break;   
            default:
                PageName = "Feedback";
                break;
        }
        return PageName;
      
    }
}
