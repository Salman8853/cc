/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.model;

/**
 *
 * @author m.salman
 */
public class ComplaintsModel {
    

 private Integer compId;
     
  private String pnotNumber; 

 private String mobileNumber; 


 private String customerName; 


 private String emailId; 


 private String pinCode; 


 private String remark;


private Integer compRequest;


private Integer compCategory;

    public ComplaintsModel() {
        
    }



    public Integer getCompId() {
        return compId;
    }

    public void setCompId(Integer compId) {
        this.compId = compId;
    }

    public String getPnotNumber() {
        return pnotNumber;
    }

    public void setPnotNumber(String pnotNumber) {
        this.pnotNumber = pnotNumber;
    }

  
    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getPinCode() {
        return pinCode;
    }

    public void setPinCode(String pinCode) {
        this.pinCode = pinCode;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Integer getCompRequest() {
        return compRequest;
    }

    public void setCompRequest(Integer compRequest) {
        this.compRequest = compRequest;
    }

    public Integer getCompCategory() {
        return compCategory;
    }

    public void setCompCategory(Integer compCategory) {
        this.compCategory = compCategory;
    }

    @Override
    public String toString() {
        return "ComplaintsModel{" + "compId=" + compId + ", pnotNumber=" + pnotNumber + ", mobileNumber=" + mobileNumber + ", customerName=" + customerName + ", emailId=" + emailId + ", pinCode=" + pinCode + ", remark=" + remark + ", compRequest=" + compRequest + ", compCategory=" + compCategory + '}';
    }

   

    
}
