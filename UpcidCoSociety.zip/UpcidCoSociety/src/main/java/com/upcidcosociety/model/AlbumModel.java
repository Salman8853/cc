/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.model;

import java.util.List;

/**
 *
 * @author m.salman
 */
public class AlbumModel {

    private Integer id;

    private String albumTitle;

    List<AlbumDetailModel> albumDetailList;
    
    List<String>urlList;

    public AlbumModel() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getAlbumTitle() {
        return albumTitle;
    }

    public void setAlbumTitle(String albumTitle) {
        this.albumTitle = albumTitle;
    }

    public List<AlbumDetailModel> getAlbumDetailList() {
        return albumDetailList;
    }

    public void setAlbumDetailList(List<AlbumDetailModel> albumDetailList) {
        this.albumDetailList = albumDetailList;
    }

    public List<String> getUrlList() {
        return urlList;
    }

    public void setUrlList(List<String> urlList) {
        this.urlList = urlList;
    }
    

}
