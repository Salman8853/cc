/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.model;

/**
 *
 * @author m.salman
 */
public class RdDetailResponseModel {

    private String pnoNumber;
    
    private Integer rdSerialNo;
    
    private String rdOpenningDate;

    private String rdBreakingDate;

    private Double pmd;

    private Integer pod;

    public String getPnoNumber() {
        return pnoNumber;
    }

    public void setPnoNumber(String pnoNumber) {
        this.pnoNumber = pnoNumber;
    }

    public Integer getRdSerialNo() {
        return rdSerialNo;
    }

    public void setRdSerialNo(Integer rdSerialNo) {
        this.rdSerialNo = rdSerialNo;
    }

    

    public String getRdOpenningDate() {
        return rdOpenningDate;
    }

    public void setRdOpenningDate(String rdOpenningDate) {
        this.rdOpenningDate = rdOpenningDate;
    }

    public String getRdBreakingDate() {
        return rdBreakingDate;
    }

    public void setRdBreakingDate(String rdBreakingDate) {
        this.rdBreakingDate = rdBreakingDate;
    }

    public Double getPmd() {
        return pmd;
    }

    public void setPmd(Double pmd) {
        this.pmd = pmd;
    }

    public Integer getPod() {
        return pod;
    }

    public void setPod(Integer pod) {
        this.pod = pod;
    }

    
   
    
}
