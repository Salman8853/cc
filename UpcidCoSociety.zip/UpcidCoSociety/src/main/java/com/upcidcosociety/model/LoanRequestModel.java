/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.model;

/**
 *
 * @author m.salman
 */
public class LoanRequestModel {

    private String pnoNumber;
    
    private Integer loanId;

    private String loanstartDate;

    private String loancloseDate;
    
    private String retirementDate;
    
    private Double principal;
    
    private Double openningBalace;
    
    private Double loanBalaceafterCurrentMonthDeduction;

    private Double balaceOn31March;

    private Double loanLimit;
    
    private LoanGivenRequestModel loangivenrequestmodel;
    
    private LoanRecoveredRequestModel loanrecoveredrequestmodel;
    
    private LoanIntrestDueRequestModel loanintrestduerequestmodel;
    
    private LoanInterestRecoveredRequestModel loaninterestrecoveredrequestmodel;

    private LoanAdjRequestModel loanadjrequestmodel;
    
    public String getPnoNumber() {
        return pnoNumber;
    }

    public void setPnoNumber(String pnoNumber) {
        this.pnoNumber = pnoNumber;
    }
    
    public Integer getLoanId() {
        return loanId;
    }

    public void setLoanId(Integer loanId) {
        this.loanId = loanId;
    }

    public String getLoanstartDate() {
        return loanstartDate;
    }

    public void setLoanstartDate(String loanstartDate) {
        this.loanstartDate = loanstartDate;
    }

    public String getLoancloseDate() {
        return loancloseDate;
    }

    public void setLoancloseDate(String loancloseDate) {
        this.loancloseDate = loancloseDate;
    }

    public Double getPrincipal() {
        return principal;
    }

    public void setPrincipal(Double principal) {
        this.principal = principal;
    }

    public Double getOpenningBalace() {
        return openningBalace;
    }

    public void setOpenningBalace(Double openningBalace) {
        this.openningBalace = openningBalace;
    }

    public Double getBalaceOn31March() {
        return balaceOn31March;
    }

    public void setBalaceOn31March(Double balaceOn31March) {
        this.balaceOn31March = balaceOn31March;
    }

    public Double getLoanLimit() {
        return loanLimit;
    }

    public void setLoanLimit(Double loanLimit) {
        this.loanLimit = loanLimit;
    }

    public String getRetirementDate() {
        return retirementDate;
    }

    public void setRetirementDate(String retirementDate) {
        this.retirementDate = retirementDate;
    }

    public Double getLoanBalaceafterCurrentMonthDeduction() {
        return loanBalaceafterCurrentMonthDeduction;
    }

    public void setLoanBalaceafterCurrentMonthDeduction(Double loanBalaceafterCurrentMonthDeduction) {
        this.loanBalaceafterCurrentMonthDeduction = loanBalaceafterCurrentMonthDeduction;
    }

    
    
    public LoanGivenRequestModel getLoangivenrequestmodel() {
        return loangivenrequestmodel;
    }

    
    public void setLoangivenrequestmodel(LoanGivenRequestModel loangivenrequestmodel) {
        this.loangivenrequestmodel = loangivenrequestmodel;
    }

    public LoanRecoveredRequestModel getLoanrecoveredrequestmodel() {
        return loanrecoveredrequestmodel;
    }

    public void setLoanrecoveredrequestmodel(LoanRecoveredRequestModel loanrecoveredrequestmodel) {
        this.loanrecoveredrequestmodel = loanrecoveredrequestmodel;
    }

    public LoanIntrestDueRequestModel getLoanintrestduerequestmodel() {
        return loanintrestduerequestmodel;
    }

    public void setLoanintrestduerequestmodel(LoanIntrestDueRequestModel loanintrestduerequestmodel) {
        this.loanintrestduerequestmodel = loanintrestduerequestmodel;
    }

    public LoanInterestRecoveredRequestModel getLoaninterestrecoveredrequestmodel() {
        return loaninterestrecoveredrequestmodel;
    }

    public void setLoaninterestrecoveredrequestmodel(LoanInterestRecoveredRequestModel loaninterestrecoveredrequestmodel) {
        this.loaninterestrecoveredrequestmodel = loaninterestrecoveredrequestmodel;
    }

    public LoanAdjRequestModel getLoanadjrequestmodel() {
        return loanadjrequestmodel;
    }

    public void setLoanadjrequestmodel(LoanAdjRequestModel loanadjrequestmodel) {
        this.loanadjrequestmodel = loanadjrequestmodel;
    }


    
    
    
}
