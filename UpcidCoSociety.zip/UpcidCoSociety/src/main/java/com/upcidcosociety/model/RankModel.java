/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.model;

/**
 *
 * @author m.salman
 */
public class RankModel {

 private Integer id;
 
 private String rank;   
 
 private String InUse;

    public RankModel() {
        
    }

 
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    public String getInUse() {
        return InUse;
    }

    public void setInUse(String InUse) {
        this.InUse = InUse;
    }

    @Override
    public String toString() {
        return "RankModel{" + "id=" + id + ", rank=" + rank + ", InUse=" + InUse + '}';
    }
 
 
}
