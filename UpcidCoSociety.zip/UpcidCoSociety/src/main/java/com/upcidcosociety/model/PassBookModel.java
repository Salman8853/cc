/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.model;

import java.util.Date;

/**
 *
 * @author m.salman
 */
public class PassBookModel {
 private Date premiumedepositeDate;
 
 private Double amount;
 
 private Double total;

    public PassBookModel() {
        
    }

    public Date getPremiumedepositeDate() {
        return premiumedepositeDate;
    }

    public void setPremiumedepositeDate(Date premiumedepositeDate) {
        this.premiumedepositeDate = premiumedepositeDate;
    }

  
 

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }

    
}
