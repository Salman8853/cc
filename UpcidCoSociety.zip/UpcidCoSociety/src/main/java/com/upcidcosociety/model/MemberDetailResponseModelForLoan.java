/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.model;

/**
 *
 * @author m.salman
 */
public class MemberDetailResponseModelForLoan {
    private String membermane;
    
    private String memberaccountNumber;
    
    private String pnonumber;
    
    private String memberRetirementDate;
    
    private Double basicPay;
    
    private Double totalShare;
    
    private Double LoanLimit;
    
    private Double available;
    
    private Double loanTaken;
    

    public String getMembermane() {
        return membermane;
    }

    public void setMembermane(String membermane) {
        this.membermane = membermane;
    }

    public String getMemberaccountNumber() {
        return memberaccountNumber;
    }

    public void setMemberaccountNumber(String memberaccountNumber) {
        this.memberaccountNumber = memberaccountNumber;
    }

    public String getPnonumber() {
        return pnonumber;
    }

    public String getMemberRetirementDate() {
        return memberRetirementDate;
    }

    public void setMemberRetirementDate(String memberRetirementDate) {
        this.memberRetirementDate = memberRetirementDate;
    }

    public void setPnonumber(String pnonumber) {
        this.pnonumber = pnonumber;
    }

    public Double getBasicPay() {
        return basicPay;
    }

    public void setBasicPay(Double basicPay) {
        this.basicPay = basicPay;
    }

    public Double getTotalShare() {
        return totalShare;
    }

    public void setTotalShare(Double totalShare) {
        this.totalShare = totalShare;
    }

    public Double getLoanLimit() {
        return LoanLimit;
    }

    public void setLoanLimit(Double LoanLimit) {
        this.LoanLimit = LoanLimit;
    }

    public Double getAvailable() {
        return available;
    }

    public void setAvailable(Double available) {
        this.available = available;
    }

    public Double getLoanTaken() {
        return loanTaken;
    }

    public void setLoanTaken(Double loanTaken) {
        this.loanTaken = loanTaken;
    }


}
