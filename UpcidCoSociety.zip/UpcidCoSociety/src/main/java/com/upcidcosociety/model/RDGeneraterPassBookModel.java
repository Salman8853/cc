/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.model;

import java.util.List;

/**
 *
 * @author m.salman
 */
public class RDGeneraterPassBookModel {
    private String memberName;
    private String fatherName;
    private String paymentMode;
    private Integer rdaccNo;
    private Integer rdSerialNo;
    private Integer pod;
    private List<PassBookModel>pbmodelList;

    public RDGeneraterPassBookModel() {
        
    }

    public String getMemberName() {
        return memberName;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    public String getFatherName() {
        return fatherName;
    }

    public void setFatherName(String fatherName) {
        this.fatherName = fatherName;
    }

    public String getPaymentMode() {
        return paymentMode;
    }

    public void setPaymentMode(String paymentMode) {
        this.paymentMode = paymentMode;
    }

    public Integer getRdaccNo() {
        return rdaccNo;
    }

    public void setRdaccNo(Integer rdaccNo) {
        this.rdaccNo = rdaccNo;
    }

    public Integer getRdSerialNo() {
        return rdSerialNo;
    }

    public void setRdSerialNo(Integer rdSerialNo) {
        this.rdSerialNo = rdSerialNo;
    }

    public Integer getPod() {
        return pod;
    }

    public void setPod(Integer pod) {
        this.pod = pod;
    }

    public List<PassBookModel> getPbmodelList() {
        return pbmodelList;
    }

    public void setPbmodelList(List<PassBookModel> pbmodelList) {
        this.pbmodelList = pbmodelList;
    }
    
    
    
}
