/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.model;

/**
 *
 * @author m.salman
 */
public class MemberAccountModel {

 private Integer accId;   

 private String bankAccountNumber;

 private Double basicPay; 

 private String bankName; 
  
 

 private Double srdAmount;
 
 private String soceityAccountNumber; 

 private Double shareOpeningBal; 

 private String ledgerFileNumber;
 
 private String providentFundNumber;
 
 private Integer category;
 
 private String categoryName;
   
 private Integer rank;

 private String rankName;
 
 private Integer sector;
 
 private String sectorName;
 
private Integer posting;

 private String postingName;
 
 private Integer paymentId;
   
private String paymentType;
 
    public Integer getAccId() {
        return accId;
    }

    public void setAccId(Integer accId) {
        this.accId = accId;
    }

    public String getBankAccountNumber() {
        return bankAccountNumber;
    }

    public void setBankAccountNumber(String bankAccountNumber) {
        this.bankAccountNumber = bankAccountNumber;
    }

    public Double getBasicPay() {
        return basicPay;
    }

    public void setBasicPay(Double basicPay) {
        this.basicPay = basicPay;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }



    public Double getSrdAmount() {
        return srdAmount;
    }

    public void setSrdAmount(Double srdAmount) {
        this.srdAmount = srdAmount;
    }

    public String getSoceityAccountNumber() {
        return soceityAccountNumber;
    }

    public void setSoceityAccountNumber(String soceityAccountNumber) {
        this.soceityAccountNumber = soceityAccountNumber;
    }

    public Double getShareOpeningBal() {
        return shareOpeningBal;
    }

    public void setShareOpeningBal(Double shareOpeningBal) {
        this.shareOpeningBal = shareOpeningBal;
    }

    public String getLedgerFileNumber() {
        return ledgerFileNumber;
    }

    public void setLedgerFileNumber(String ledgerFileNumber) {
        this.ledgerFileNumber = ledgerFileNumber;
    }

    public String getProvidentFundNumber() {
        return providentFundNumber;
    }

    public void setProvidentFundNumber(String providentFundNumber) {
        this.providentFundNumber = providentFundNumber;
    }

    public Integer getCategory() {
        return category;
    }

    public void setCategory(Integer category) {
        this.category = category;
    }

    public Integer getRank() {
        return rank;
    }

    public void setRank(Integer rank) {
        this.rank = rank;
    }

    public Integer getSector() {
        return sector;
    }

    public void setSector(Integer sector) {
        this.sector = sector;
    }

    public Integer getPosting() {
        return posting;
    }

    public void setPosting(Integer posting) {
        this.posting = posting;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getRankName() {
        return rankName;
    }

    public void setRankName(String rankName) {
        this.rankName = rankName;
    }

    public String getSectorName() {
        return sectorName;
    }

    public void setSectorName(String sectorName) {
        this.sectorName = sectorName;
    }

    public String getPostingName() {
        return postingName;
    }

    public void setPostingName(String postingName) {
        this.postingName = postingName;
    }

    public Integer getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(Integer paymentId) {
        this.paymentId = paymentId;
    }

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }
    

}
