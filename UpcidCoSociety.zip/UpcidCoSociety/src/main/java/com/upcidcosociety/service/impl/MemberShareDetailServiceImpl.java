/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service.impl;

import com.upcidcosociety.dao.MemberDetailDao;
import com.upcidcosociety.dao.MemberShareDetailDao;
import com.upcidcosociety.dao.MemberShareDetailMonthWiseDao;
import com.upcidcosociety.dao.MemberShareRequestDao;
import com.upcidcosociety.dtob.MemberDetail;
import com.upcidcosociety.dtob.MemberShareDetail;
import com.upcidcosociety.dtob.MemberShareDetailMonthWise;
import com.upcidcosociety.dtob.MemberShareRequest;
import com.upcidcosociety.model.MemberShareDetailModel;
import com.upcidcosociety.service.MemberShareDetailService;
import com.upcidcosociety.util.UpcidResponse;
import com.upcidcosociety.util.UtilDate;
import java.util.Date;
import java.util.List;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author m.salman
 */
@Service
@Transactional
public class MemberShareDetailServiceImpl implements MemberShareDetailService {

    private static final Logger logger = LoggerFactory.getLogger(MemberShareDetailServiceImpl.class);
    @Autowired
    private MemberShareDetailDao memberShareDetailDao;

    @Autowired
    private MemberDetailDao memberDetailDao;

    @Autowired
    private MemberShareDetailMonthWiseDao memberShareDetailMonthWiseDao;

    @Autowired
    private MemberShareRequestDao membersharerequestdao;

//    @Override
//    public UpcidResponse saveMemberShareDetail(MemberShareDetailModel memberShareDetailModel) {
//        UpcidResponse<MemberShareDetail> response = new UpcidResponse();
//        try {
//            MemberShareDetail memberShareDetail = null;
//            MemberShareDetailMonthWise memberShareDetailMonthWise = null;
//            List<MemberShareDetailMonthWise> MemberShareDetailMonthWiseList = new ArrayList<>();
//            if (memberShareDetailModel != null && memberShareDetailModel.getSharePaid() != null && memberShareDetailModel.getTotalShare() != null && memberShareDetailModel.getMemberId() != null && memberShareDetailModel.getSharePaidDate() != null) {
//                memberShareDetail = new MemberShareDetail();
//                memberShareDetail.setShareOpeningBalance(memberShareDetailModel.getShareOpeningBalance());
//                memberShareDetail.setSharePaid(memberShareDetailModel.getSharePaid());
//                memberShareDetail.setTotalShare(memberShareDetailModel.getTotalShare());
//                memberShareDetail.setSharePaidDate(UtilDate.convertStringToDate(memberShareDetailModel.getSharePaidDate()));
//                memberShareDetail.setMemberDetail(memberDetailDao.getmemberDetailBymemeberId(memberShareDetailModel.getMemberId()));
//
//                MemberShareDetail msd = memberShareDetailDao.savemeberShareDetail(memberShareDetail);
//
//                memberShareDetailMonthWise = new MemberShareDetailMonthWise();
//                memberShareDetailMonthWise.setMonth("Jan");
//                memberShareDetailMonthWise.setAmount(memberShareDetailModel.getJanValue());
//                memberShareDetailMonthWise.setMemberShareDetail(msd);
//                MemberShareDetailMonthWiseList.add(memberShareDetailMonthWise);
//
//                memberShareDetailMonthWise = new MemberShareDetailMonthWise();
//                memberShareDetailMonthWise.setMonth("Feb");
//                memberShareDetailMonthWise.setAmount(memberShareDetailModel.getFebValue());
//                memberShareDetailMonthWise.setMemberShareDetail(msd);
//                MemberShareDetailMonthWiseList.add(memberShareDetailMonthWise);
//
//                memberShareDetailMonthWise = new MemberShareDetailMonthWise();
//                memberShareDetailMonthWise.setMonth("March");
//                memberShareDetailMonthWise.setAmount(memberShareDetailModel.getMarchValue());
//                memberShareDetailMonthWise.setMemberShareDetail(msd);
//                MemberShareDetailMonthWiseList.add(memberShareDetailMonthWise);
//
//                memberShareDetailMonthWise = new MemberShareDetailMonthWise();
//                memberShareDetailMonthWise.setMonth("April");
//                memberShareDetailMonthWise.setAmount(memberShareDetailModel.getAprilValue());
//                memberShareDetailMonthWise.setMemberShareDetail(msd);
//                MemberShareDetailMonthWiseList.add(memberShareDetailMonthWise);
//
//                memberShareDetailMonthWise = new MemberShareDetailMonthWise();
//                memberShareDetailMonthWise.setMonth("May");
//                memberShareDetailMonthWise.setAmount(memberShareDetailModel.getMayValue());
//                memberShareDetailMonthWise.setMemberShareDetail(msd);
//                MemberShareDetailMonthWiseList.add(memberShareDetailMonthWise);
//
//                memberShareDetailMonthWise = new MemberShareDetailMonthWise();
//                memberShareDetailMonthWise.setMonth("June");
//                memberShareDetailMonthWise.setAmount(memberShareDetailModel.getJuneValue());
//                memberShareDetailMonthWise.setMemberShareDetail(msd);
//                MemberShareDetailMonthWiseList.add(memberShareDetailMonthWise);
//
//                memberShareDetailMonthWise = new MemberShareDetailMonthWise();
//                memberShareDetailMonthWise.setMonth("July");
//                memberShareDetailMonthWise.setAmount(memberShareDetailModel.getJulyValue());
//                memberShareDetailMonthWise.setMemberShareDetail(msd);
//                MemberShareDetailMonthWiseList.add(memberShareDetailMonthWise);
//
//                memberShareDetailMonthWise = new MemberShareDetailMonthWise();
//                memberShareDetailMonthWise.setMonth("August");
//                memberShareDetailMonthWise.setAmount(memberShareDetailModel.getAugustValue());
//                memberShareDetailMonthWise.setMemberShareDetail(msd);
//                MemberShareDetailMonthWiseList.add(memberShareDetailMonthWise);
//
//                memberShareDetailMonthWise = new MemberShareDetailMonthWise();
//                memberShareDetailMonthWise.setMonth("Sept");
//                memberShareDetailMonthWise.setAmount(memberShareDetailModel.getSeptValue());
//                memberShareDetailMonthWise.setMemberShareDetail(msd);
//                MemberShareDetailMonthWiseList.add(memberShareDetailMonthWise);
//
//                memberShareDetailMonthWise = new MemberShareDetailMonthWise();
//                memberShareDetailMonthWise.setMonth("Oct");
//                memberShareDetailMonthWise.setAmount(memberShareDetailModel.getOctValue());
//                memberShareDetailMonthWise.setMemberShareDetail(msd);
//                MemberShareDetailMonthWiseList.add(memberShareDetailMonthWise);
//
//                memberShareDetailMonthWise = new MemberShareDetailMonthWise();
//                memberShareDetailMonthWise.setMonth("Nov");
//                memberShareDetailMonthWise.setAmount(memberShareDetailModel.getNovValue());
//                memberShareDetailMonthWise.setMemberShareDetail(msd);
//                MemberShareDetailMonthWiseList.add(memberShareDetailMonthWise);
//
//                memberShareDetailMonthWise = new MemberShareDetailMonthWise();
//                memberShareDetailMonthWise.setMonth("Dec");
//                memberShareDetailMonthWise.setAmount(memberShareDetailModel.getDecValue());
//                memberShareDetailMonthWise.setMemberShareDetail(msd);
//                MemberShareDetailMonthWiseList.add(memberShareDetailMonthWise);
//                for (MemberShareDetailMonthWise msdMonthWise : MemberShareDetailMonthWiseList) {
//                    memberShareDetailMonthWiseDao.saveNewMemberShareDetailMonthWise(msdMonthWise);
//                }
//
////                memberShareDetail.setMemberShareDetailMonthWiseList(MemberShareDetailMonthWiseList);
//                if (msd != null && msd.getMsdId() != null && msd.getMsdId() > 0) {
//                    response.setStatus(HttpStatus.OK);
//                    response.setMessage("Record saved!");
//                    response.setData(msd);
//                } else {
//                    response.setStatus(HttpStatus.NOT_FOUND);
//                    response.setMessage("Sorry! Record not saved");
//                    response.setData(msd);
//
//                }
//            } else {
//
//                response.setStatus(HttpStatus.NOT_FOUND);
//                response.setMessage("Please fill all mendatory fields!");
//                response.setData(memberShareDetail);
//            }
//
//        } catch (Exception e) {
//            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured while saving category");
//            logger.info("Exception while saving category:" + e);
//        }
//        return response;
//    }
//
    @Override
    public UpcidResponse updateMemberShareDetail(MemberShareDetailModel memberShareDetailModel) {
        UpcidResponse<MemberShareDetail> response = new UpcidResponse();
        try {
            MemberShareDetail memberShareDetail = null;
            memberShareDetail = memberShareDetailDao.getmeberShareDetailBymsdId(memberShareDetailModel.getMsdId());
            if (memberShareDetail != null && memberShareDetail.getMsdId() != null && memberShareDetail.getMsdId() > 0) {
                 memberShareDetail.setSharePaid(memberShareDetailModel.getSharePaid());
                 Double srpaid=memberShareDetailModel.getSharePaid()!=null?memberShareDetailModel.getSharePaid():0.0;
                Double remainingBalane=memberShareDetail.getTotalShare()-srpaid;
                 memberShareDetail.setTotalShare(remainingBalane);
                memberShareDetail.setSharePaidDate(UtilDate.convertStringToDate(memberShareDetailModel.getSharePaidDate()));
                MemberShareDetail membersrddtls = memberShareDetailDao.updatemeberShareDetail(memberShareDetail);
                if (membersrddtls != null && membersrddtls.getMsdId() != null && membersrddtls.getMsdId() > 0) {
                    response.setStatus(HttpStatus.OK);
                    response.setMessage("Record updated succefully!");
                    response.setData(membersrddtls);

                } else {
                    response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("Record updation failed!");
                    response.setData(null);
                }
            }
        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured while updating memberShare detrail");
            logger.info("Exception while updating memberShare detrail:" + e);
        }
        return response;
    }

    @Override
    public UpcidResponse getMemberShareDetailBymemberId(String pnonumber) {
        UpcidResponse<MemberShareDetailModel> response = new UpcidResponse();
        try {
            MemberShareDetail membersharedetail = null;
            MemberShareDetailModel memberShareDetailModel = null;
            MemberDetail memberdetail = memberDetailDao.getmemberDetailByPnoNumber(pnonumber);
            if (memberdetail != null && memberdetail.getMemberId() != null && memberdetail.getMemberId() > 0) {
                membersharedetail = memberShareDetailDao.getmeberShareDetailBymemberId(memberdetail.getMemberId());
                if (membersharedetail != null && membersharedetail.getMsdId() > 0) {
                    memberShareDetailModel = new MemberShareDetailModel();
                    memberShareDetailModel.setPnonumber(pnonumber);
                    memberShareDetailModel.setMsdId(membersharedetail.getMsdId());
                    memberShareDetailModel.setMemberId(memberdetail.getMemberId());
                    memberShareDetailModel.setSrdamount(memberdetail.getMemberAccount().getSrdAmount());
                    memberShareDetailModel.setShareOpeningBalance(membersharedetail.getShareOpeningBalance());
                    memberShareDetailModel.setSharePaid(membersharedetail.getSharePaid());
                    memberShareDetailModel.setTotalShare(membersharedetail.getTotalShare());

                    if (membersharedetail.getSharePaidDate() != null) {
                        memberShareDetailModel.setSharePaidDate(UtilDate.formatetdateToString_dd_MM_yyyy(membersharedetail.getSharePaidDate()));
                    } else {
                        memberShareDetailModel.setSharePaidDate(null);
                    }
                    DateTime date = new DateTime();
                    String monthname = date.monthOfYear().getAsText();
                    Integer year = null;
                    if (monthname.equalsIgnoreCase("January") || monthname.equalsIgnoreCase("February") || monthname.equalsIgnoreCase("March")) {
                        year = date.getYear() - 1;
                    } else {
                        year = date.getYear();
                    }
                    List<MemberShareDetailMonthWise> membersharemonthwiselst = memberShareDetailMonthWiseDao.getAllMemberShareDetailMonthWiseBymsdIdAndfinyear(membersharedetail.getMsdId(), year);
                    if (membersharemonthwiselst != null && !membersharemonthwiselst.isEmpty()) {
                        for (MemberShareDetailMonthWise msdmonthWise : membersharemonthwiselst) {

                            String monthName = msdmonthWise.getMonth();
                            switch (monthName) {
                                case "January":
                                    memberShareDetailModel.setJanValue(msdmonthWise.getAmount());
                                    break;
                                case "February":
                                    memberShareDetailModel.setFebValue(msdmonthWise.getAmount());
                                    break;
                                case "March":
                                    memberShareDetailModel.setMarchValue(msdmonthWise.getAmount());
                                    break;
                                case "April":
                                    memberShareDetailModel.setAprilValue(msdmonthWise.getAmount());
                                    break;
                                case "May":
                                    memberShareDetailModel.setMayValue(msdmonthWise.getAmount());
                                    break;
                                case "June":
                                    memberShareDetailModel.setJuneValue(msdmonthWise.getAmount());
                                    break;
                                case "July":
                                    memberShareDetailModel.setJulyValue(msdmonthWise.getAmount());
                                    break;
                                case "August":
                                    memberShareDetailModel.setAugustValue(msdmonthWise.getAmount());
                                    break;
                                case "September":
                                    memberShareDetailModel.setSeptValue(msdmonthWise.getAmount());
                                    break;
                                case "October":
                                    memberShareDetailModel.setOctValue(msdmonthWise.getAmount());
                                    break;
                                case "November":
                                    memberShareDetailModel.setNovValue(msdmonthWise.getAmount());
                                    break;
                                case "December":
                                    memberShareDetailModel.setDecValue(msdmonthWise.getAmount());
                                    break;
                            }
                        }

                    }
                    response.setStatus(HttpStatus.OK);
                    response.setMessage("Record found!");
                    response.setData(memberShareDetailModel);

                } else {
                    response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("Record not found!");
                    response.setData(null);
                }

            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("Member PNO Number didn't exist!");
                response.setData(null);
            }
        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when getting member Share Details");
            logger.info("Exception getting member Share Details:" + e);
        }
        return response;
    }

    /**
     * membershare request Section for how mutch SRD will be deducted in next
     * month He can 0 deduction in upcomming month.
     */
    @Override
    public UpcidResponse savemembershareRequest(MemberShareRequest membersharerequest) {
        UpcidResponse<MemberShareRequest> response = new UpcidResponse();
        try {
            DateTime date = new DateTime();
            date = date.plusMonths(1);
            String monthname = date.monthOfYear().getAsText();
            MemberShareRequest memsrdreqst = null;
            memsrdreqst = membersharerequestdao.getmemberRequestListBymemberId(membersharerequest.getMemberId(), monthname);
            if (memsrdreqst != null && memsrdreqst.getId() != null && memsrdreqst.getId() > 0) {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("Sorry! Record already exist");
                response.setData(memsrdreqst);
                return response;
            }
            memsrdreqst = new MemberShareRequest();
            memsrdreqst.setMonth(membersharerequest.getMonth());
            memsrdreqst.setAmount(membersharerequest.getAmount());
            memsrdreqst.setMemberId(membersharerequest.getMemberId());
            memsrdreqst.setDate(new Date());
            MemberShareRequest rs = membersharerequestdao.save(memsrdreqst);
            if (rs != null && rs.getId() != null && rs.getId() > 0) {
                response.setStatus(HttpStatus.OK);
                response.setMessage("Record Saved!");
                response.setData(rs);
            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("Record not saved!");
                response.setData(rs);
            }
        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when getting member Share Details");
            logger.info("Exception getting member Share Details:" + e);
        }
        return response;
    }

}
