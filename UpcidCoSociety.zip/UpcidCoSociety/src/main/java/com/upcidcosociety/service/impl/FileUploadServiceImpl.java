/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service.impl;

import com.upcidcosociety.service.FileUploadService;
import com.upcidcosociety.util.UpcidResponse;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

/**
 *
 * @author m.salman
 */
@Service
public class FileUploadServiceImpl implements FileUploadService{

    @Override
    public UpcidResponse UploadFile(MultipartFile files, File location,String fileName) throws  IOException
    {
        UpcidResponse response=new UpcidResponse();
              BufferedOutputStream outputStream = new BufferedOutputStream(new FileOutputStream(location+File.separator+fileName));
              outputStream.write(files.getBytes());
              outputStream.flush();
              outputStream.close();
               response.setStatus(HttpStatus.OK);
               response.setMessage("uploaded");
               response.setData(null);
              return response;

    }  
}
