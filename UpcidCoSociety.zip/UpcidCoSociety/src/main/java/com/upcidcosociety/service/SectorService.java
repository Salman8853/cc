/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service;

import com.upcidcosociety.dtob.Sector;
import com.upcidcosociety.util.UpcidResponse;

/**
 *
 * @author m.salman
 */
public interface SectorService {
  public UpcidResponse addSector(Sector sector,String remoteaddress,String username);

  public UpcidResponse updateSector(Sector sector,String remoteaddress,String username); 
  
  public UpcidResponse geSectorById(Integer id,String userName);
  
  public UpcidResponse getAllSector(String userName);
  
  public UpcidResponse getAllSectorforMember(String userName);
  
  public UpcidResponse deleteSectorById(Integer id,String userName);
}
