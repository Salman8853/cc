/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service.impl;

import com.upcidcosociety.service.EmailService;
import com.upcidcosociety.util.MailBodyContentUtil;
import com.upcidcosociety.util.MailUtil;
import com.upcidcosociety.util.UpcidResponse;
import javax.mail.MessagingException;
import javax.mail.SendFailedException;
import javax.mail.internet.MimeMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

/**
 *
 * @author m.salman
 */
@Service
public class EmailServiceImpl implements EmailService{
   private static final Logger logger = LoggerFactory.getLogger(EmailServiceImpl.class);
  @Autowired
 private MailUtil mailUtil;
  @Override
   public UpcidResponse sendMailToMemeberForAccountOpenning( String logopath,String loginlink,String memeberName,String memberEmail, String PNONumber,String password) throws MailException {
        UpcidResponse res = new UpcidResponse();
        try {
            JavaMailSender javaMailSender = mailUtil.getJavaMailSender();
                                 
                MimeMessage message = javaMailSender.createMimeMessage();
//                String bodyContent = "Hi " + memeberName + ",<br>"
//                        +"you are succefully registerd with U.P C.I.D  credit Cooperative Society Limited."
//                        + " Your account detail is:<br/><b>Username:</b> "+PNONumber+"<br/>"
//                        + "<b>Password:</b> " + password+"<br/>"
//                        + "please login click here: ";
                MimeMessageHelper helper = new MimeMessageHelper(message, true);
                helper.setFrom(mailUtil.getFromAddr());
                helper.setTo(memberEmail);
                helper.setSubject("Regarding member account");
//                helper.setCc(password);
                helper.setText(MailBodyContentUtil.mailBodyformemberAccountCreation(logopath, loginlink, memeberName, PNONumber, password), true);
                javaMailSender.send(message);

                res.setMessage("Memeber account is created and mail sent successfully");
                res.setStatus(HttpStatus.OK);

        } catch (SendFailedException | MailException e) {
            res.setMessage("Memeber account is created and mail not sent successfully");
            res.setStatus(HttpStatus.EXPECTATION_FAILED);
            logger.error("Authenication failed Exception Message:", e);
        } catch (MessagingException ex) {
            res.setMessage("Memeber account is created and mail not sent successfully");
            res.setStatus(HttpStatus.EXPECTATION_FAILED);
           logger.error("Sending an email failed:", ex);
        }
        return res;
    }
   
  @Override
   public UpcidResponse sendMailToMemeberForAccountOpenningFromMemberSide( String logopath,String memeberName,String memberEmail) throws MailException {
        UpcidResponse res = new UpcidResponse();
        try {
            JavaMailSender javaMailSender = mailUtil.getJavaMailSender();                
                MimeMessage message = javaMailSender.createMimeMessage();
                MimeMessageHelper helper = new MimeMessageHelper(message, true);
                helper.setFrom(mailUtil.getFromAddr());
                helper.setTo(memberEmail);
                helper.setSubject("Regarding member account");
//                helper.setCc(password);
                helper.setText(MailBodyContentUtil.mailBodyformemberAccountCreationfromMemberSide(logopath, memeberName), true);
                javaMailSender.send(message);

                res.setMessage("Memeber account is created and mail sent successfully");
                res.setStatus(HttpStatus.OK);

        } catch (SendFailedException | MailException e) {
            res.setMessage("Memeber account is created and mail not sent successfully");
            res.setStatus(HttpStatus.EXPECTATION_FAILED);
            logger.error("Authenication failed Exception Message:", e);
        } catch (MessagingException ex) {
            res.setMessage("Memeber account is created and mail not sent successfully");
            res.setStatus(HttpStatus.EXPECTATION_FAILED);
           logger.error("Sending an email failed:", ex);
        }
        return res;
    }
   
   
   
   @Override
   public UpcidResponse sendMailToMemeberForComplaint(String logopath,String memberName,String memberEmail,String remark,String remarkAnswer){
     UpcidResponse res = new UpcidResponse();
        try {
            JavaMailSender javaMailSender = mailUtil.getJavaMailSender();
                                 
                MimeMessage message = javaMailSender.createMimeMessage();
               
//                String bodyContent = "Hi " + memberName + ",<br>"
//                        +"You logged a complaints againts U.P C.I.D credit Cooperative Society Limited. <br/>"
//                        + "<b>Your complaint is:</b><br/>"
//                        + ""+remark+".<br/>"
//                        + "<b>Answer to your complaint is:</b> " + remarkAnswer+"<br/>";
                MimeMessageHelper helper = new MimeMessageHelper(message, true);
                helper.setFrom(mailUtil.getFromAddr());
                helper.setTo(memberEmail);
                helper.setSubject("response against to member complaint");
//                helper.setCc(password);
                helper.setText( MailBodyContentUtil.mailbodyformemberComplaint(logopath, memberName, remark, remarkAnswer), true);
                javaMailSender.send(message);

                res.setMessage("response sent through mail successfully");
                res.setStatus(HttpStatus.OK);

        } catch (SendFailedException | MailException e) {
            res.setMessage("mail sending failed");
            res.setStatus(HttpStatus.EXPECTATION_FAILED);
            logger.error("Authenication failed Exception Message:", e);
        } catch (MessagingException ex) {
            res.setMessage("mail sending failed");
            res.setStatus(HttpStatus.EXPECTATION_FAILED);
           logger.error("Sending an email failed:", ex);
        }
        return res;
   }
    
}
