/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service.impl;

import com.upcidcosociety.dao.MemberDetailDao;
import com.upcidcosociety.dao.RdDetailMonthWiseHistoryDao;
import com.upcidcosociety.dao.RdDetailsDao;
import com.upcidcosociety.dao.RdEntryDetailMonthWiseDao;
import com.upcidcosociety.dao.RdRequestEntrymonthwiseDao;
import com.upcidcosociety.dao.RdentryDetailDao;
import com.upcidcosociety.dtob.MemberDetail;
import com.upcidcosociety.dtob.RdDetailMonthWiseHistory;
import com.upcidcosociety.dtob.RdDetails;
import com.upcidcosociety.dtob.RdEntryDetailMonthWise;
import com.upcidcosociety.dtob.RdRequestEntrymonthwise;
import com.upcidcosociety.dtob.RdentryDetail;
import com.upcidcosociety.model.MemberRdCuttingModel;
import com.upcidcosociety.model.PassBookModel;
import com.upcidcosociety.model.RDGeneraterPassBookModel;
import com.upcidcosociety.model.RdDetailResponseModel;
import com.upcidcosociety.model.RdDetailsRequestModel;
import com.upcidcosociety.service.RdService;
import com.upcidcosociety.util.UpcidResponse;
import com.upcidcosociety.util.UtilDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author m.salman
 */
@Service
@Transactional
public class RdServiceImpl implements RdService {

    private static final Logger logger = LoggerFactory.getLogger(RdServiceImpl.class);

    @Autowired
    private MemberDetailDao memberDetailDao;
    @Autowired
    private RdDetailsDao rdDetailsDao;
    @Autowired
    private RdentryDetailDao rdentryDetailDao;
    @Autowired
    private RdEntryDetailMonthWiseDao rdEntryDetailMonthWiseDao;

    @Autowired
    private RdRequestEntrymonthwiseDao rdrequestentrymonthwisedao;

    @Autowired
    private RdDetailMonthWiseHistoryDao rddetailmonthwisehistorydao;

    @Override
    public UpcidResponse saveNewRd(RdDetailsRequestModel rdDetailsRequestModel, String username) {
        UpcidResponse<RdentryDetail> response = new UpcidResponse();
        try {
            MemberDetail memberDetail = null;
            RdentryDetail rdentryDtls = null;
            RdDetails rdDtls = null;
            RdEntryDetailMonthWise rdentryDtlsMonthWise = null;
            memberDetail = memberDetailDao.getmemberDetailByPnoNumber(rdDetailsRequestModel.getPnoNumber());
            rdDtls = rdDetailsDao.getRdDetailsBymemberId(memberDetail.getMemberId());
            if (rdDtls == null) {
                RdDetails rdDetails = new RdDetails();
                rdDetails.setActive(Boolean.TRUE);
                rdDetails.setCeratedDate(new Date());
                rdDetails.setMemberDetail(memberDetail);
                rdDtls = rdDetailsDao.saveNewRdDetails(rdDetails);
            }
            RdentryDetail rdentryDetail = new RdentryDetail();
            rdentryDetail.setPmd(rdDetailsRequestModel.getPmd());
            rdentryDetail.setPod(rdDetailsRequestModel.getPod());
            rdentryDetail.setRdOpenningDate(UtilDate.convertStringToDate(rdDetailsRequestModel.getRdOpenningDate()));
            rdentryDetail.setRdDreakingDate(UtilDate.convertStringToDate(rdDetailsRequestModel.getRdDreakingDate()));

            rdentryDetail.setOldAmt(rdDetailsRequestModel.getOldAmt());
            Date openningdate = UtilDate.convertStringToDate(rdDetailsRequestModel.getRdOpenningDate());
            Calendar calendor = Calendar.getInstance();
            calendor.setTime(openningdate);
            int finyear = calendor.get(Calendar.YEAR);
            rdentryDetail.setFinYear(finyear + "");
            rdentryDetail.setIntdue(rdDetailsRequestModel.getIntdue());
            rdentryDetail.setIntPaid(rdDetailsRequestModel.getIntPaid());
            rdentryDetail.setIntBal(rdDetailsRequestModel.getIntBal());
            rdentryDetail.setStatus("Open");
            if (rdDtls != null) {
                rdentryDetail.setRdDetails(rdDtls);
            }

            rdentryDtls = rdentryDetailDao.saveNewRdentryDetails(rdentryDetail);
            //save first installment as a pmd
            rdentryDtlsMonthWise = new RdEntryDetailMonthWise();
            DateTime date = new DateTime();
            String month = date.monthOfYear().getAsText();
            rdentryDtlsMonthWise.setMonth(month);
            rdentryDtlsMonthWise.setAmount(rdDetailsRequestModel.getPmd());
            rdentryDtlsMonthWise.setRdEntryDetail(rdentryDtls);
            rdentryDtlsMonthWise.setEntryDate(new Date());
            rdEntryDetailMonthWiseDao.saveRdEntryDetailMonthWise(rdentryDtlsMonthWise);
            if (rdentryDtls != null && rdentryDtls.getRdSerialNo() != null && rdentryDtls.getRdSerialNo() > 0) {

                response.setStatus(HttpStatus.OK);
                response.setMessage("Record saved!");
                response.setData(rdentryDtls);
            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("Record  does not saved!");
                response.setData(rdentryDtls);
            }
        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured while saving new rd:");
            logger.info("Exception while saving new rd:" + e);
        }
        return response;
    }

    @Override
    public UpcidResponse updateRd(RdDetailsRequestModel rddetailsrequestmodel, String username) {
        UpcidResponse<RdentryDetail> response = new UpcidResponse();
        try {
            RdentryDetail rdentrydetail = null;
            rdentrydetail = rdentryDetailDao.getRdentryDetailsByrdSerialNo(rddetailsrequestmodel.getRdSerialNo());
            if (rdentrydetail != null && rdentrydetail.getRdSerialNo() != null && rdentrydetail.getRdSerialNo() > 0) {
                rdentrydetail.setPmd(rddetailsrequestmodel.getPmd());
                rdentrydetail.setPod(rddetailsrequestmodel.getPod());
                rdentrydetail.setOldAmt(rddetailsrequestmodel.getOldAmt());

//             rdentrydetail.setIntdue(rddetailsrequestmodel.getIntdue());
//             rdentrydetail.setIntBal(rddetailsrequestmodel.getIntBal()); 
//             rdentrydetail.setIntPaid(rddetailsrequestmodel.getIntPaid());
                RdentryDetail rdentrydtls = rdentryDetailDao.updatenewrdentrydetails(rdentrydetail);
                if (rdentrydtls != null && rdentrydtls.getRdSerialNo() != null && rdentrydtls.getRdSerialNo() > 0) {

                    response.setStatus(HttpStatus.OK);
                    response.setMessage("Record update!");
                    response.setData(rdentrydtls);

                } else {
                    response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("Record not update!");
                    response.setData(rdentrydtls);

                }
            }

        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured while saving update rd:");
            logger.info("Exception while update  rd:" + e);

        }
        return response;
    }

    @Override
    public UpcidResponse updatememberRdmonthwiseListByrdaccountNo(MemberRdCuttingModel memberrdcuttingmodel, String username) {
        UpcidResponse<Object> response = new UpcidResponse();
        try {
            RdRequestEntrymonthwise rdrequestentrymonthwise = null;
            List<RdEntryDetailMonthWise> rdmonthtlst = null;
            List<RdRequestEntrymonthwise> rdrequestlst = null;
            List<String> monthNamelst = new ArrayList<>();
            List<String> rdmonthNamelst = new ArrayList<>();
            if (memberrdcuttingmodel != null && memberrdcuttingmodel.getMemberId() != null && memberrdcuttingmodel.getMemberId() > 0 && memberrdcuttingmodel.getMemberRdAccountNo() != null && memberrdcuttingmodel.getMemberRdAccountNo() > 0 && memberrdcuttingmodel.getSerialNo() != null && memberrdcuttingmodel.getSerialNo() > 0) {
                DateTime date = new DateTime();
                String month = date.monthOfYear().getAsText();
                DateTime nextmontDate = date.plusMonths(1);
                String nextmonth = nextmontDate.monthOfYear().getAsText();
                if (!(memberrdcuttingmodel.getMonthName().equalsIgnoreCase(month)) && (!memberrdcuttingmodel.getMonthName().equalsIgnoreCase(nextmonth))) {
                    response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("Cutting allowed for Current month or next month only");
                    response.setData(null);
                    return response;
                }
                rdrequestlst = rdrequestentrymonthwisedao.getAllRdRequestEntrymonthwiseByrdAccountNumberandSerialNumber(memberrdcuttingmodel.getMemberRdAccountNo(), memberrdcuttingmodel.getSerialNo());
                if (rdrequestlst != null && rdrequestlst.size() > 0) {
                    for (RdRequestEntrymonthwise rdrequestmonthwise : rdrequestlst) {
                        monthNamelst.add(rdrequestmonthwise.getMonthName());
                    }
                }
                if ((!monthNamelst.isEmpty()) && monthNamelst.contains(memberrdcuttingmodel.getMonthName())) {
                    response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("Sorry! record already exist");
                    response.setData(null);
                    return response;
                }

                rdmonthtlst = rdEntryDetailMonthWiseDao.getAllRdEntryDetailMonthWiseByRdSerialNo(memberrdcuttingmodel.getSerialNo());
                if (rdmonthtlst != null && rdmonthtlst.size() > 0) {
                    for (RdEntryDetailMonthWise rdentrydetailmonthwise : rdmonthtlst) {
                        rdmonthNamelst.add(rdentrydetailmonthwise.getMonth());
                    }
                }

                if ((!rdmonthNamelst.isEmpty()) && rdmonthNamelst.contains(memberrdcuttingmodel.getMonthName())) {
                    response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("Sorry! record already exist");
                    response.setData(null);
                    return response;
                }

                //check for first month  cutting in monthwise table entry here remainning hai abhi
                rdrequestentrymonthwise = new RdRequestEntrymonthwise();
                rdrequestentrymonthwise.setMemberId(memberrdcuttingmodel.getMemberId());
                rdrequestentrymonthwise.setRdaccountno(memberrdcuttingmodel.getMemberRdAccountNo());
                rdrequestentrymonthwise.setRdserialno(memberrdcuttingmodel.getSerialNo());
                rdrequestentrymonthwise.setMonthName(memberrdcuttingmodel.getMonthName());
                rdrequestentrymonthwise.setAmount(memberrdcuttingmodel.getAmount());
                rdrequestentrymonthwise.setRequestBy(username);
                rdrequestentrymonthwise.setStatus(Boolean.TRUE);
                rdrequestentrymonthwise.setCreatedDate(UtilDate.formattedDate(new Date()));
                RdRequestEntrymonthwise redrequest = rdrequestentrymonthwisedao.savenewRdRequestEntrymonthwise(rdrequestentrymonthwise);
                if (redrequest != null && redrequest.getRdrequestId() != null && redrequest.getRdrequestId() > 0) {
                    response.setStatus(HttpStatus.OK);
                    response.setMessage("Record saved!");
                    response.setData(null);
                } else {
                    response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("Record not saved!");
                    response.setData(null);

                }

            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("plaes fill all mendatory fields!");
                response.setData(null);
            }

        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured while saving new rd monthwise record:");
            logger.info("Exception while saving new rd monthwise record:" + e);
        }
        return response;
    }

    @Override
    public UpcidResponse getmemberRdByrdSerialNo(String pnoNumber, Integer rdSerialNo, String username) {
        UpcidResponse<RdDetailsRequestModel> response = new UpcidResponse();
        try {
            RdentryDetail rdentrydetail = null;
            RdDetailsRequestModel rddetailsrequestmodel = null;
            rdentrydetail = rdentryDetailDao.getRdentryDetailsByrdSerialNo(rdSerialNo);
            if (rdentrydetail != null && rdentrydetail.getRdSerialNo() != null && rdentrydetail.getRdSerialNo() > 0) {
                rddetailsrequestmodel = new RdDetailsRequestModel();

                rddetailsrequestmodel.setPnoNumber(pnoNumber);
                rddetailsrequestmodel.setRdSerialNo(rdentrydetail.getRdSerialNo());
                rddetailsrequestmodel.setPmd(rdentrydetail.getPmd());
                rddetailsrequestmodel.setPod(rdentrydetail.getPod());
                rddetailsrequestmodel.setRdOpenningDate(UtilDate.formatetdateToString_dd_MM_yyyy(rdentrydetail.getRdOpenningDate()));
                rddetailsrequestmodel.setRdDreakingDate(UtilDate.formatetdateToString_dd_MM_yyyy(rdentrydetail.getRdDreakingDate()));
                rddetailsrequestmodel.setIntdue(rdentrydetail.getIntdue());
                rddetailsrequestmodel.setIntPaid(rdentrydetail.getIntPaid());
                rddetailsrequestmodel.setIntBal(rdentrydetail.getIntBal());
                rddetailsrequestmodel.setTotalPayment(rdentrydetail.getTotalPayment());
                List<RdEntryDetailMonthWise> rdentrydetailmonthwiselist = rdentrydetail.getRdEntryDetailMonthWiseList();
                if (rdentrydetailmonthwiselist != null && rdentrydetailmonthwiselist.size() > 0) {
                    for (RdEntryDetailMonthWise rdentrydetailmonthwise : rdentrydetailmonthwiselist) {
                        String monthName = rdentrydetailmonthwise.getMonth();
                        switch (monthName) {
                            case "January":
                                rddetailsrequestmodel.setJanValue(rdentrydetailmonthwise.getAmount());
                                break;
                            case "February":
                                rddetailsrequestmodel.setFebValue(rdentrydetailmonthwise.getAmount());
                                break;
                            case "March":
                                rddetailsrequestmodel.setMarchValue(rdentrydetailmonthwise.getAmount());

                                break;
                            case "April":
                                rddetailsrequestmodel.setAprilValue(rdentrydetailmonthwise.getAmount());

                                break;
                            case "May":
                                rddetailsrequestmodel.setMayValue(rdentrydetailmonthwise.getAmount());

                                break;
                            case "June":
                                rddetailsrequestmodel.setJuneValue(rdentrydetailmonthwise.getAmount());
                                break;
                            case "July":
                                rddetailsrequestmodel.setJulyValue(rdentrydetailmonthwise.getAmount());

                                break;
                            case "August":
                                rddetailsrequestmodel.setAugustValue(rdentrydetailmonthwise.getAmount());

                                break;
                            case "September":
                                rddetailsrequestmodel.setSeptValue(rdentrydetailmonthwise.getAmount());

                                break;
                            case "October":
                                rddetailsrequestmodel.setOctValue(rdentrydetailmonthwise.getAmount());
                                break;
                            case "November":
                                rddetailsrequestmodel.setNovValue(rdentrydetailmonthwise.getAmount());

                                break;
                            case "December":
                                rddetailsrequestmodel.setDecValue(rdentrydetailmonthwise.getAmount());
                                break;
                        }
                    }
                    response.setStatus(HttpStatus.OK);
                    response.setMessage("Record found!");
                    response.setData(rddetailsrequestmodel);
                } else {
                    response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("Record not found!");
                    response.setData(rddetailsrequestmodel);
                }
            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("Record not found!");
                response.setData(rddetailsrequestmodel);
            }

        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured while saving new rd:");
            logger.info("Exception while saving new rd:" + e);

        }
        return response;
    }

    @Override
    public UpcidResponse getAllmemberRdListById(String pnoNumber, String username) {
        UpcidResponse< List<RdDetailResponseModel>> response = new UpcidResponse();
        try {
            RdDetailResponseModel rdDetailResponseModel = null;
            RdDetails rdDetails = null;
            List<RdDetailResponseModel> rdDetailResponseModelList = new ArrayList<>();
            MemberDetail memberDetail = memberDetailDao.getmemberDetailByPnoNumber(pnoNumber);
            if (memberDetail != null && memberDetail.getMemberId() != null && memberDetail.getMemberId() > 0) {
                rdDetails = rdDetailsDao.getRdDetailsBymemberId(memberDetail.getMemberId());
                if (rdDetails != null && rdDetails.getRdAccNo() != null && rdDetails.getRdAccNo() > 0) {
                    List<RdentryDetail> rdentryList = rdentryDetailDao.getAllRdentryDetailsofMember(rdDetails.getRdAccNo());
                    if (rdentryList != null && rdentryList.size() > 0) {
                        for (RdentryDetail rdentryDetail : rdentryList) {
                            rdDetailResponseModel = new RdDetailResponseModel();
                            rdDetailResponseModel.setRdSerialNo(rdentryDetail.getRdSerialNo());
                            rdDetailResponseModel.setPmd(rdentryDetail.getPmd());
                            rdDetailResponseModel.setPod(rdentryDetail.getPod());
                            rdDetailResponseModel.setRdOpenningDate(UtilDate.formatetdateToString_dd_MM_yyyy(rdentryDetail.getRdOpenningDate()));
                            rdDetailResponseModel.setRdBreakingDate(UtilDate.formatetdateToString_dd_MM_yyyy(rdentryDetail.getRdDreakingDate()));
                            rdDetailResponseModelList.add(rdDetailResponseModel);
                        }
                        response.setStatus(HttpStatus.OK);
                        response.setMessage("Record found!");
                        response.setData(rdDetailResponseModelList);
                    } else {
                        response.setStatus(HttpStatus.NOT_FOUND);
                        response.setMessage("Record  not found!");
                        response.setData(rdDetailResponseModelList);

                    }

                } else {
                    response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("Record  not found!");
                    response.setData(null);
                }

            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("Record  not found!");
                response.setData(null);
            }

        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured while saving new rd:");
            logger.info("Exception while saving new rd:" + e);
        }
        return response;
    }

    @Override
    public UpcidResponse getrddetailforPassbook(String pnoNumber, Integer rdaccno, Integer rdserialNo, String username) {
        UpcidResponse<RDGeneraterPassBookModel> response = new UpcidResponse();
        try {
            RdentryDetail rdentrydetail = null;
            List<RdEntryDetailMonthWise> rdmonthtlst = null;
            List<PassBookModel> passbooklst = new ArrayList<>();
            RDGeneraterPassBookModel rdgeneraterpassbookmodel = new RDGeneraterPassBookModel();
            MemberDetail memberdetail = memberDetailDao.getmemberDetailByPnoNumber(pnoNumber);
            if (memberdetail != null && memberdetail.getMemberId() != null && memberdetail.getMemberId() > 0) {
                rdgeneraterpassbookmodel.setMemberName(memberdetail.getMemberName());
                rdgeneraterpassbookmodel.setFatherName(memberdetail.getFatherName());
                rdgeneraterpassbookmodel.setPaymentMode(memberdetail.getMemberAccount().getPaymentmode().getPaymentType());
            }
            
            //check first in history table
            Double total = 0.0;
            List<RdDetailMonthWiseHistory> historylst = rddetailmonthwisehistorydao.getRddetailhistorybyrdaccnoAndrdserialno(rdaccno, rdserialNo);
            if (historylst != null && historylst.size() > 0) {
                for (RdDetailMonthWiseHistory rddetailmonthwisehistory : historylst) {
                    PassBookModel passbookmodel = new PassBookModel();
                    passbookmodel.setPremiumedepositeDate(rddetailmonthwisehistory.getEntryDate());
                    passbookmodel.setAmount(rddetailmonthwisehistory.getAmount());
                    total = total + rddetailmonthwisehistory.getAmount();
                    passbookmodel.setTotal(total);
                    passbooklst.add(passbookmodel);
                }

            }
            rdentrydetail = rdentryDetailDao.getRdentryDetailByrdaccnoAndrdserialno(rdaccno, rdserialNo);
            if (rdentrydetail != null && rdentrydetail.getRdSerialNo() != null && rdentrydetail.getRdSerialNo() > 0) {
                rdgeneraterpassbookmodel.setRdaccNo(rdaccno);
                rdgeneraterpassbookmodel.setRdSerialNo(rdentrydetail.getRdSerialNo());
                rdgeneraterpassbookmodel.setPod(rdentrydetail.getPod());
                rdmonthtlst = rdentrydetail.getRdEntryDetailMonthWiseList();
                if (rdmonthtlst != null && rdmonthtlst.size() > 0) {
                    for (RdEntryDetailMonthWise rdentrydetailmonthwise : rdmonthtlst) {
                        PassBookModel passbookmodel = new PassBookModel();
                        passbookmodel.setPremiumedepositeDate(rdentrydetailmonthwise.getEntryDate());
                        passbookmodel.setAmount(rdentrydetailmonthwise.getAmount());
                        total = total + rdentrydetailmonthwise.getAmount();
                        passbookmodel.setTotal(total);
                        passbooklst.add(passbookmodel);
                    }
                }
            }
            if (rdgeneraterpassbookmodel != null) {
                Comparator<PassBookModel> cm1=Comparator.comparing(PassBookModel::getPremiumedepositeDate);  
                 Collections.sort(passbooklst,cm1);  
//                 Collections.reverse(passbooklst);  
              rdgeneraterpassbookmodel.setPbmodelList(passbooklst);
                response.setStatus(HttpStatus.OK);
                response.setMessage("Record found!");
                response.setData(rdgeneraterpassbookmodel);
            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("Record not found!");
                response.setData(rdgeneraterpassbookmodel);
            }
        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when getting data for PassBook generation:");
            logger.info("Exception when getting data for PassBook generation:" + e);
        }
        return response;
    }
}
