/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service;

import com.upcidcosociety.model.MemberRdCuttingModel;
import com.upcidcosociety.model.RdDetailsRequestModel;
import com.upcidcosociety.util.UpcidResponse;

/**
 *
 * @author m.salman
 */
public interface RdService {
    

  public UpcidResponse saveNewRd(RdDetailsRequestModel rdDetailsRequestModel,String username);
  
  public UpcidResponse updatememberRdmonthwiseListByrdaccountNo(MemberRdCuttingModel memberrdcuttingmodel,String username);
  
  public UpcidResponse updateRd(RdDetailsRequestModel rddetailsrequestmodel,String username);
  
  public UpcidResponse getmemberRdByrdSerialNo(String pnoNumber,Integer rdSerialNo,String username);
    
  public UpcidResponse getAllmemberRdListById(String pnoNumber,String username);
  
  public UpcidResponse getrddetailforPassbook( String pnoNumber,Integer rdaccno,Integer rdserialNo,String username);
}
