 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service.impl;

import com.upcidcosociety.dao.SoftwareSetingsDao;
import com.upcidcosociety.dao.SwMonthlyCalDao;
import com.upcidcosociety.dao.SwRateSettingDao;
import com.upcidcosociety.dtob.SoftwareSetings;
import com.upcidcosociety.dtob.SwMonthlyCal;
import com.upcidcosociety.dtob.SwRateSetting;
import com.upcidcosociety.service.SoftwareSetingsService;
import com.upcidcosociety.util.UpcidResponse;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author m.salman
 */
@Service
@Transactional
public class SoftwareSetingsServiceImpl implements SoftwareSetingsService{
    private static final Logger logger = LoggerFactory.getLogger(SoftwareSetingsServiceImpl.class); 
    @Autowired
    private SoftwareSetingsDao softwareSetingsDao;

    @Autowired
    private SwRateSettingDao swRateSettingDao;

    @Autowired
    private SwMonthlyCalDao swMonthlyCalDao;
     
   @Override
   public UpcidResponse saveSoftwareSetings(SoftwareSetings softwareSetingsReq,String userName){
       UpcidResponse response=new UpcidResponse();       
       SoftwareSetings softwareSetings=null;
       SwRateSetting  swRateSetting=null;
       SwMonthlyCal swMonthlyCal=null;
       try {
          //Check setting exist or not into db
          if(softwareSetingsReq!=null){
          softwareSetings=new SoftwareSetings();
          softwareSetings.setBasicPayMultiplier(softwareSetingsReq.getBasicPayMultiplier());
          softwareSetings.setDividendDay(softwareSetingsReq.getDividendDay());
          softwareSetings.setDividendMonth(softwareSetingsReq.getDividendMonth());
          softwareSetings.setDividentrate(softwareSetingsReq.getDividentrate());
          softwareSetings.setLoanRate(softwareSetingsReq.getLoanRate());
          softwareSetings.setMonthAdjDone(softwareSetingsReq.getMonthAdjDone());
          softwareSetings.setPkyEnabled(softwareSetingsReq.getPkyEnabled());
          softwareSetings.setSharePayMultiplier(softwareSetingsReq.getSharePayMultiplier());
          softwareSetings.setSharePayMultiplier(softwareSetingsReq.getSharePayMultiplier());
          softwareSetings.setSharePayMultiplier(softwareSetingsReq.getSharePayMultiplier());
          
          SoftwareSetings SwS= softwareSetingsDao.saveSoftwareSetings(softwareSetings);
           if(SwS!=null && SwS.getId()!=null){ 
               
          List<SwRateSetting> swRateSettingeqList = softwareSetingsReq.getSwRtsettingList();
          if(swRateSettingeqList!=null && swRateSettingeqList.size()>0){
                int j=1;
                for (SwRateSetting swRateSettingeq : swRateSettingeqList) {
                  swRateSetting = new SwRateSetting();
                  swRateSetting.setGenFdMatRate(swRateSettingeq.getGenFdMatRate());
                  swRateSetting.setGenFdPreMatRate(swRateSettingeq.getGenFdPreMatRate());
                  swRateSetting.setRdFullRate(swRateSettingeq.getRdFullRate());
                  swRateSetting.setRdPartRate(swRateSettingeq.getRdPartRate());
                  swRateSetting.setScFdMatMate(swRateSettingeq.getScFdMatMate());
                  swRateSetting.setScPreMatRate(swRateSettingeq.getScPreMatRate());
                  
                  swRateSetting.setYear(j);
                  swRateSetting.setSsid(SwS);
                  swRateSettingDao.saveSwRateSetting(swRateSetting);
                 j=j+2;
              } 
                   response.setStatus(HttpStatus.OK);
                   response.setMessage("satting saved");
                   response.setData(null);

            }else{
                   response.setStatus(HttpStatus.NOT_FOUND);
                   response.setMessage("please fill all mendatory fields");
                   response.setData(null);
          
               }
        }else{
               response.setStatus(HttpStatus.NOT_FOUND);
               response.setMessage("Setting not saved");
               response.setData(null);
           }
   }else{
       response.setStatus(HttpStatus.NOT_FOUND);
       response.setMessage("please fill all mendatory fields");
       response.setData(null);
          
    }
          
       } catch (Exception e) {
       
             response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when saving new setting");
            logger.info("Exception occured when saving new setting:" + e);
             e.printStackTrace();
       }
       return response;
     }

}
