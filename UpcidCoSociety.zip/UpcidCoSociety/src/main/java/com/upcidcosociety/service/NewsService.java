/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service;

import com.upcidcosociety.dtob.News;
import com.upcidcosociety.util.UpcidResponse;

/**
 *
 * @author m.salman
 */
public interface NewsService {
    
    public UpcidResponse saveNews(News news, String username);
      
     public UpcidResponse getNewsByTitle(String newsTitle);
     
     public UpcidResponse getNewsById(Integer id);
     
     public UpcidResponse getAllNews();
}
