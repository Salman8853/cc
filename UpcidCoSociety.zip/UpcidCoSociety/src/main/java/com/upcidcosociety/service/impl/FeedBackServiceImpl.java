/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service.impl;

import com.upcidcosociety.dao.FeedBackDao;
import com.upcidcosociety.dtob.FeedBack;
import com.upcidcosociety.service.FeedBackService;
import com.upcidcosociety.util.UpcidResponse;
import com.upcidcosociety.util.UtilDate;
import java.util.Date;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author m.salman
 */
@Service
@Transactional
public class FeedBackServiceImpl implements FeedBackService{
    
  private static final Logger logger = LoggerFactory.getLogger(FeedBackServiceImpl.class);
  
    @Autowired
    private FeedBackDao feedBackDao;
    
    
    @Override
    public UpcidResponse addFeedBack(FeedBack feedBack) {
        UpcidResponse response = new UpcidResponse();
        try {
            FeedBack fb = null;
            if (feedBack != null && feedBack.getName()!= null && feedBack.getName().trim().length() > 0 && feedBack.getEmailId()!=null && feedBack.getName().trim().length()>0) {
               
                fb = new FeedBack();
                fb.setName(feedBack.getName());
                fb.setEmailId(feedBack.getEmailId());
                fb.setAddress(feedBack.getAddress());
                fb.setContactNumber(feedBack.getContactNumber());
                fb.setCity(feedBack.getCity());
                fb.setState(feedBack.getState());
                fb.setQueryDetail(feedBack.getQueryDetail());
                fb.setCreatedDate(UtilDate.convertDatetoTimestamp(new Date()));
                FeedBack Feedback =feedBackDao.saveFeedBack(feedBack);
                if (Feedback != null && Feedback.getCompId() != null && Feedback.getCompId() > 0) {
                    response.setStatus(HttpStatus.OK);
                    response.setMessage("Your feedback has been  saved successfully!");
                    response.setData(Feedback);
                } else {
                    response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("Your feedback not saved!");
                    response.setData(Feedback);
                }
            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("Plaese enter mandatory fields!");
                response.setData(null);
            }
        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured while saving feedback");
            logger.info("Exception while saving feedback:" + e);
        }
        return response;
    }
    
    @Override
    public UpcidResponse getAllFeedBack(String username){
     UpcidResponse<List<FeedBack>> response = new UpcidResponse();
        try {
           
            List<FeedBack>cpmlist= feedBackDao.getAllFeedBack();
        if(cpmlist!=null && cpmlist.size()>0){
                    response.setStatus(HttpStatus.OK);
                    response.setMessage("Ok");
                    response.setData(cpmlist);
        
         }else{
                    response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("Record not found!");
                    response.setData(cpmlist);
        
          }
        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured while getting all feedback");
            logger.info("Exception while getting all feedback:" + e);
        }
        return response;
    
    }
    
    @Override
    public UpcidResponse getFeedBackById(Integer feedbackId,String username){
      UpcidResponse<FeedBack> response = new UpcidResponse();
        try {
           
           FeedBack cpmlist= feedBackDao.getFeedBackByid(feedbackId);
        if(cpmlist!=null && cpmlist.getCompId()>0){
                    response.setStatus(HttpStatus.OK);
                    response.setMessage("Ok");
                    response.setData(cpmlist);
        
         }else{
                    response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("Record not found!");
                    response.setData(cpmlist);
        
          }
        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured while getting feedback by id");
            logger.info("Exception while getting feedback by id:" + e);
        }
        return response;
    
    }
    
}
