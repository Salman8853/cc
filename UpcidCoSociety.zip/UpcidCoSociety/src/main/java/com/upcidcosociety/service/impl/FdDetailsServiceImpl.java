/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.upcidcosociety.dao.FdDetailsDao;
import com.upcidcosociety.dao.FdNomineeDao;
import com.upcidcosociety.dao.MemberDetailDao;
import com.upcidcosociety.dao.SoftwareSetingsDao;
import com.upcidcosociety.dtob.FdDetails;
import com.upcidcosociety.dtob.FdNominee;
import com.upcidcosociety.dtob.MemberDetail;
import com.upcidcosociety.dtob.SoftwareSetings;
import com.upcidcosociety.dtob.SwRateSetting;
import com.upcidcosociety.model.FdCertificateModel;
import com.upcidcosociety.model.FdDetailsResponseModel;
import com.upcidcosociety.model.FdNomineeModel;
import com.upcidcosociety.model.FdRenueModel;
import com.upcidcosociety.model.FdRequestModel;
import com.upcidcosociety.service.FdDetailsService;
import com.upcidcosociety.util.ConvertNumberToWord;
import com.upcidcosociety.util.UpcidResponse;
import com.upcidcosociety.util.UtilDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author m.salman
 */
@Service
@Transactional
public class FdDetailsServiceImpl implements FdDetailsService {

    private static final Logger logger = LoggerFactory.getLogger(FdDetailsServiceImpl.class);
    @Autowired
    private FdDetailsDao fddetailsdao;
    @Autowired
    private FdNomineeDao fdnomineedao;

    @Autowired
    private SoftwareSetingsDao softwaresetingsdao;

    @Autowired
    private MemberDetailDao memberdetaildao;

    @Override
    public UpcidResponse generateNewaccountNumberforNewFd(String pnoNumber,String username) {
        UpcidResponse<FdRequestModel> response = new UpcidResponse();
        try {
            FdRequestModel fdrequestmodel = new FdRequestModel();
            String res = "";
            FdDetails fddetails = null;
          
            fddetails = fddetailsdao.getlastRecordfromFdDetails();
            if (fddetails != null && fddetails.getFdAccNo() != null && fddetails.getFdAccNo().trim().length() > 0) {
                String fdacc = fddetails.getFdAccNo();
                String subacc = fdacc.substring(0, fdacc.indexOf('/'));
                int crntindex = Integer.parseInt(subacc);
                crntindex = crntindex + 1;
                int year = Calendar.getInstance().get(Calendar.YEAR);
                String crryear = year + "";
                res = crntindex + "/" + crryear.substring(2);
                List<FdNomineeModel> nominee = new ArrayList<>();
                FdNomineeModel nmodel = new FdNomineeModel();
                nmodel.setId(-1);
                nominee.add(nmodel);
                fdrequestmodel.setFdAccNo(res);
                fdrequestmodel.setFdStatus("open");
                fdrequestmodel.setFdcreateandorUpdateStatus("Create");
                fdrequestmodel.setNominee(nominee);
                response.setStatus(HttpStatus.OK);
                response.setMessage("Record found!");
                response.setData(fdrequestmodel);

            } else {
                int year = Calendar.getInstance().get(Calendar.YEAR);
                String crryear = year + "";
                res = 1 + "/" + crryear.substring(2);
                List<FdNomineeModel> nominee = new ArrayList<>();
                FdNomineeModel nmodel = new FdNomineeModel();
                nmodel.setId(-1);
                nominee.add(nmodel);
                fdrequestmodel.setFdAccNo(res);
                fdrequestmodel.setFdStatus("open");
                fdrequestmodel.setNominee(nominee);
                fdrequestmodel.setFdcreateandorUpdateStatus("Create");
                response.setStatus(HttpStatus.OK);
                response.setMessage("Record found!");
                response.setData(fdrequestmodel);

            }
            
        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured while saving category");
            logger.info("Exception while saving category:" + e);
        }
        return response;
    }

    @Override
    public UpcidResponse getfdmaturityvalueforajax(String pnoNumber,String openningdate, int fdPeriod, int oppeningfdamount, String username) {
        UpcidResponse<String> upcidresponse = new UpcidResponse();
        String res = "";
        try {
            SoftwareSetings softwaresetings = null;
              MemberDetail memberdetail = null;
            List<SwRateSetting> ratesettinglst = new ArrayList<>();
            if (pnoNumber!=null && pnoNumber!="" && fdPeriod>0 && oppeningfdamount > 0 && openningdate != null && openningdate != "" && openningdate.trim().length() > 0) {
                ConvertNumberToWord convertnumbertoword = null;
                String amountinword = "";
                int interest = 0;
                int maturityamount = 0;
                Double fdyrfullrateforGen = 0.0;
                Double fdyrpartialrateforGen = 0.0;

                Double fdyrfullrateforSc = 0.0;
                Double fdyrpartialrateforSc = 0.0;

                softwaresetings = softwaresetingsdao.getSoftwareSetings();

                if (softwaresetings != null && softwaresetings.getId() != null && softwaresetings.getId() > 0) {
                    ratesettinglst = softwaresetings.getSwRtsettingList();
                    if (ratesettinglst != null && ratesettinglst.size() > 0) {
                        for (SwRateSetting SwRateSetting : ratesettinglst) {
                            if (SwRateSetting.getYear() == fdPeriod) {
                                fdyrfullrateforGen = SwRateSetting.getGenFdMatRate();
                                fdyrpartialrateforGen = SwRateSetting.getGenFdPreMatRate();
                                fdyrfullrateforSc = SwRateSetting.getScFdMatMate();
                                fdyrpartialrateforSc = SwRateSetting.getScPreMatRate();
                                break;
                            }
                        }
                    }

                }
                Date dob=null;
                String agegroup="";
                String maturityDate="";
                memberdetail=memberdetaildao.getmemberDetailByPnoNumber(pnoNumber);
                if(memberdetail!=null && memberdetail.getMemberId()!=null && memberdetail.getMemberId()>0){
                  dob= memberdetail.getDateOfBirth();
                 }
                Calendar birthday = Calendar.getInstance();
                birthday.setTime(dob);
                Date today = new Date();
                Calendar crrdate = Calendar.getInstance();
                crrdate.setTime(today);

                int yearsInBetween = crrdate.get(Calendar.YEAR) - birthday.get(Calendar.YEAR);
                
                if (yearsInBetween<60) {

                    interest = (int) (interest + Math.round(oppeningfdamount * fdyrfullrateforGen * fdPeriod / 100));
                    maturityamount = interest + oppeningfdamount;
                    agegroup="GENERAL";
                } else {
                    interest = (int) (interest + Math.round(oppeningfdamount * fdyrfullrateforSc * fdPeriod / 100));
                    maturityamount = interest + oppeningfdamount;
                    agegroup="SR.CITIZEN";
                }
                Date date=UtilDate.convertStringToDate(openningdate);
                Calendar cal = Calendar.getInstance();
                cal.setTime(date);
                cal.add(Calendar.YEAR,fdPeriod); // to get previous year add -1
               
                maturityDate = UtilDate.formatetdateToString_dd_MM_yyyy(cal.getTime());
                convertnumbertoword = new ConvertNumberToWord();
                amountinword = convertnumbertoword.convertNumberToWords(oppeningfdamount);

                Map<String, String> jsonmap = new HashMap<>();
                jsonmap.put("fddeposite", oppeningfdamount + "");
                jsonmap.put("fddepositeinword", amountinword);
                jsonmap.put("maturityamount", maturityamount + "");
                jsonmap.put("maturitydate",maturityDate);
                jsonmap.put("agegroup",agegroup);
                jsonmap.put("intdue", interest + "");
                jsonmap.put("intpaid", "0");
                jsonmap.put("intbal", interest + "");
                jsonmap.put("fdpaid", "0");
                ObjectMapper mapperObj = new ObjectMapper();
                String Detail = mapperObj.writeValueAsString(jsonmap);
                upcidresponse.setStatus(HttpStatus.OK);
                upcidresponse.setMessage("Record found!");
                upcidresponse.setData(Detail);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return upcidresponse;
    }

    @Override
    public UpcidResponse createnewfd(FdRequestModel fdrequestmodel, String username) {
        UpcidResponse<FdDetails> response = new UpcidResponse();
        try {
            FdDetails fddtls = null;
            FdNominee fdnominee = null;
            MemberDetail memberdetail = null;
            SoftwareSetings softwaresetings = null;
            List<SwRateSetting> ratesettinglst = new ArrayList<>();
            Double fdyrfullrateforGen = 0.0;
            Double fdyrpartialrateforGen = 0.0;

            Double fdyrfullrateforSc = 0.0;
            Double fdyrpartialrateforSc = 0.0;

            if (fdrequestmodel!=null && fdrequestmodel.getFdAccNo()!=null && fdrequestmodel.getAgeGroup()!=null && fdrequestmodel.getAgeGroup().trim().length()>0 && fdrequestmodel.getOpenningDeposite()!=null && fdrequestmodel.getOpenningDeposite()>0) {

                softwaresetings = softwaresetingsdao.getSoftwareSetings();
                if (softwaresetings != null && softwaresetings.getId() != null && softwaresetings.getId() > 0) {
                    ratesettinglst = softwaresetings.getSwRtsettingList();
                    if (ratesettinglst != null && ratesettinglst.size() > 0) {
                        for (SwRateSetting SwRateSetting : ratesettinglst) {
                            if (SwRateSetting.getYear() == fdrequestmodel.getFdPeriod()) {
                                fdyrfullrateforGen = SwRateSetting.getGenFdMatRate();
                                fdyrpartialrateforGen = SwRateSetting.getGenFdPreMatRate();
                                fdyrfullrateforSc = SwRateSetting.getScFdMatMate();
                                fdyrpartialrateforSc = SwRateSetting.getScPreMatRate();
                                break;
                            }
                        }
                    }
                }
                FdDetails fddetails = new FdDetails();
                fddetails.setFdAccNo(fdrequestmodel.getFdAccNo());
                fddetails.setAgeGroup(fdrequestmodel.getAgeGroup());
                fddetails.setFdStatus(fdrequestmodel.getFdStatus());
                fddetails.setFdPeriod(fdrequestmodel.getFdPeriod());
                fddetails.setRecieptNo(fdrequestmodel.getRecieptNo());
                fddetails.setOpenningDeposite(fdrequestmodel.getOpenningDeposite());
                fddetails.setOpenningAmtinWords(fdrequestmodel.getOpenningAmtinWords());
                fddetails.setOpenningDate(UtilDate.convertStringToDate(fdrequestmodel.getOpenningDate()));
                fddetails.setFdPaid(fdrequestmodel.getFdPaid());

                fddetails.setInterestdue(fdrequestmodel.getInterestdue());
                fddetails.setInterestPaid(fdrequestmodel.getInterestPaid());
                fddetails.setInterestBal(fdrequestmodel.getInterestBal());
                
                if (fdrequestmodel.getAgeGroup().equalsIgnoreCase("GENERAL")) {

                    fddetails.setFullinterestrate(fdyrfullrateforGen);
                    fddetails.setParinterestrate(fdyrpartialrateforGen);
                } else {
                    fddetails.setFullinterestrate(fdyrfullrateforSc);
                    fddetails.setParinterestrate(fdyrpartialrateforSc);
                }
              
//                Calendar cal = Calendar.getInstance();
                   int year = 0;
                  DateTime datetime= new DateTime();
                 String crntmonth= datetime.monthOfYear().getAsText();
                 if(crntmonth.equalsIgnoreCase("January")||crntmonth.equalsIgnoreCase("February")||crntmonth.equalsIgnoreCase("March")){
                      year=datetime.getYear()-1;
                  }else{
                      year=datetime.getYear();
                   }

                fddetails.setMaturityAmount(fdrequestmodel.getMaturityAmount());
                fddetails.setMaturityDate(UtilDate.convertStringToDate(fdrequestmodel.getMaturityDate()));
                fddetails.setFinYear(year+"");
                memberdetail = memberdetaildao.getmemberDetailByPnoNumber(fdrequestmodel.getPnoNumber());
                if (memberdetail != null && memberdetail.getMemberId() != null && memberdetail.getMemberId() > 0) {
                    fddetails.setMemberDetail(memberdetail);
                    fddtls = fddetailsdao.savenewfd(fddetails);
                }
                if (fddtls != null && fddtls.getFdAccNo().equalsIgnoreCase(fdrequestmodel.getFdAccNo())) {
                    if (fdrequestmodel.getNominee() != null && fdrequestmodel.getNominee().size() > 0) {
                        for (FdNomineeModel fdnomineemodel : fdrequestmodel.getNominee()) {
                            fdnominee = new FdNominee();
                            fdnominee.setNomineeName(fdnomineemodel.getNomineeName());
                            fdnominee.setAddress(fdnomineemodel.getAddress());
                            fdnominee.setRelation(fdnomineemodel.getRelation());
                            fdnominee.setShare(fdnomineemodel.getShare());
                            fdnominee.setFddetails(fddtls);
                            fdnomineedao.savefdnominee(fdnominee);
                        }
                    }
                    response.setStatus(HttpStatus.OK);
                    response.setMessage("Record saved!");
                    response.setData(fddtls);
                }
            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("Please fill all mendatory fields!");
                response.setData(null);

            }

        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when saving  new FD");
            logger.info("Exception when saving  new FD:" + e);
        }
        return response;
    }

    @Override
    public UpcidResponse getfddetailsByfpnoNumber(String pnonumber, String username) {
        UpcidResponse<List<FdDetailsResponseModel>> response = new UpcidResponse();
        try {
            MemberDetail memberdetail = null;
            FdDetailsResponseModel fddetailsresponsemodel = null;
            List<FdDetailsResponseModel> fdresponselst = new ArrayList<>();
            if (pnonumber != null && pnonumber.trim().length() > 0) {
                memberdetail = memberdetaildao.getmemberDetailByPnoNumber(pnonumber);
                if (memberdetail != null && memberdetail.getMemberId() != null && memberdetail.getMemberId() > 0) {
                    List<FdDetails> fdDetailsList = fddetailsdao.getfddetailsBymemberId(memberdetail.getMemberId());
                    if (fdDetailsList != null && fdDetailsList.size() > 0) {
                        for (FdDetails fddetails : fdDetailsList) {
                            fddetailsresponsemodel = new FdDetailsResponseModel();
                            fddetailsresponsemodel.setPnoNumber(pnonumber);
                            fddetailsresponsemodel.setFdAccNo(fddetails.getFdAccNo());
                            fddetailsresponsemodel.setFdPeriod(fddetails.getFdPeriod());
                            fddetailsresponsemodel.setOpenningDate(UtilDate.formatetdateToString_dd_MM_yyyy(fddetails.getOpenningDate()));
                            fddetailsresponsemodel.setOpenningDeposite(fddetails.getOpenningDeposite());
                            fddetailsresponsemodel.setFdStatus(fddetails.getFdStatus());
                            fdresponselst.add(fddetailsresponsemodel);
                        }
                        response.setStatus(HttpStatus.OK);
                        response.setMessage("Record saved!");
                        response.setData(fdresponselst);

                    } else {

                        response.setStatus(HttpStatus.NOT_FOUND);
                        response.setMessage("Record not found!");
                        response.setData(null);

                    }
                } else {
                    response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("Record not found!");
                    response.setData(null);

                }
            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("Pno number does not exist!");
                response.setData(null);
            }

        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured getting all fd of a member");
            logger.info("Exception when getting all fd of a member:" + e);

        }
        return response;
    }

    @Override
    public UpcidResponse getfddetailsByfdaccountNumber(String pnonumber, String fdaccountnumber, String username) {
        UpcidResponse<FdRequestModel> response = new UpcidResponse();
        try {
            FdDetails fddetails = null;
            FdRequestModel fdrequestmodel = null;
            List<FdNomineeModel> nominee = new ArrayList<>();
            FdNomineeModel fdnomineemodel = null;
            SoftwareSetings softwaresetings = null;
            List<SwRateSetting> ratesettinglst = new ArrayList<>();
            double fdyrpartialrateforGen = 0.0;
            double fdyrpartialrateforSc = 0.0;
            double crrpartrate = 0.0;

            if (fdaccountnumber != null && fdaccountnumber != "") {
                fddetails = fddetailsdao.getfddetailsByfdaccountnumber(fdaccountnumber);
                softwaresetings = softwaresetingsdao.getSoftwareSetings();
                if (softwaresetings != null && softwaresetings.getId() != null && softwaresetings.getId() > 0) {
                    ratesettinglst = softwaresetings.getSwRtsettingList();
                    if (ratesettinglst != null && ratesettinglst.size() > 0) {
                        for (SwRateSetting SwRateSetting : ratesettinglst) {
                            if (SwRateSetting.getYear() == fddetails.getFdPeriod()) {
                                fdyrpartialrateforGen = SwRateSetting.getGenFdPreMatRate();
                                fdyrpartialrateforSc = SwRateSetting.getScPreMatRate();
                                break;
                            }
                        }
                    }
                }
                if (fddetails != null && fddetails.getFdAccNo() != null && fddetails.getFdAccNo().trim().length() > 0) {
                    if (fddetails.getAgeGroup().equalsIgnoreCase("GENERAL")) {
                        crrpartrate = fdyrpartialrateforGen;
                    } else {
                        crrpartrate = fdyrpartialrateforSc;
                    }
                    double result = FdDetailsServiceImpl.fdforoneyear(fddetails.getOpenningDeposite(), fddetails.getFullinterestrate(), fddetails.getParinterestrate(), crrpartrate, fddetails.getFdPeriod(), fddetails.getOpenningDate(), new Date());
                    fdrequestmodel = new FdRequestModel();
                    fdrequestmodel.setPnoNumber(pnonumber);
                    fdrequestmodel.setFdStatus(fddetails.getFdStatus());
                    fdrequestmodel.setFdAccNo(fddetails.getFdAccNo());
                    fdrequestmodel.setFdAccNo(fddetails.getFdAccNo());

                    fdrequestmodel.setAgeGroup(fddetails.getAgeGroup());
                    fdrequestmodel.setFdPeriod(fddetails.getFdPeriod());
                    fdrequestmodel.setOpenningDeposite(fddetails.getOpenningDeposite());

                    fdrequestmodel.setRecieptNo(fddetails.getRecieptNo());
                    fdrequestmodel.setOpenningDate(UtilDate.formatetdateToString_dd_MM_yyyy(fddetails.getOpenningDate()));
                    fdrequestmodel.setMaturityDate(UtilDate.formatetdateToString_dd_MM_yyyy(fddetails.getMaturityDate()));

                    fdrequestmodel.setFdPaid(fddetails.getFdPaid());
                    fdrequestmodel.setInterestPaid(fddetails.getInterestPaid());

                    fdrequestmodel.setInterestdue(fddetails.getInterestdue());
                    fdrequestmodel.setInterestBal(fddetails.getInterestBal());

                    fdrequestmodel.setMaturityAmount(fddetails.getMaturityAmount());

                    fdrequestmodel.setOpenningAmtinWords(fddetails.getOpenningAmtinWords());

                    fdrequestmodel.setPartialmaturityAmount(result + fddetails.getOpenningDeposite());
                    fdrequestmodel.setPartialinterestBal(0.0);
                    fdrequestmodel.setPartialinterestdue(result);
                    fdrequestmodel.setFdcreateandorUpdateStatus("Update");
                    List<FdNominee> fdnomineelst = fdnomineedao.getfdnomineelist(fdaccountnumber);
                    if (fdnomineelst != null && fdnomineelst.size() > 0) {
                        for (FdNominee fdnominee : fdnomineelst) {
                            fdnomineemodel = new FdNomineeModel();
                            fdnomineemodel.setId(fdnominee.getId());
                            fdnomineemodel.setNomineeName(fdnominee.getNomineeName());
                            fdnomineemodel.setAddress(fdnominee.getAddress());
                            fdnomineemodel.setRelation(fdnominee.getRelation());
                            fdnomineemodel.setShare(fdnominee.getShare());
                            nominee.add(fdnomineemodel);
                        }
                    }
                    fdrequestmodel.setNominee(nominee);
                    response.setStatus(HttpStatus.OK);
                    response.setMessage("Record found!");
                    response.setData(fdrequestmodel);
                } else {
                    response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("Record not found!");
                    response.setData(null);
                }
            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("fdaccount number not found!");
                response.setData(null);
            }

        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured getting fd details of a member");
            logger.info("Exception when getting  fd details of a member:" + e);
        }
        return response;
    }

    @Override
    public UpcidResponse generatecertificate(String pnonumber, String fdaccountnumber, String username) {
        UpcidResponse<FdCertificateModel> response = new UpcidResponse();
        try {
            MemberDetail memberdetail = null;
            FdDetails fddetails = null;
            FdCertificateModel fdcertificatemodel = null;
            memberdetail = memberdetaildao.getmemberDetailByPnoNumber(pnonumber);
            if (memberdetail != null && memberdetail.getMemberId() != null && memberdetail.getMemberId() > 0) {
                fddetails = fddetailsdao.getfddetailsBypnonumberAmdfdaccountnumber(memberdetail.getMemberId(), fdaccountnumber);
                if (fddetails != null && fddetails.getFdAccNo() != null && fddetails.getFdAccNo().trim().length() > 0) {
                    fdcertificatemodel = new FdCertificateModel();

                    fdcertificatemodel.setMemberName(memberdetail.getMemberName());
                    fdcertificatemodel.setRankName(memberdetail.getMemberAccount().getRank().getRank());

                    fdcertificatemodel.setMaturityAmount(fddetails.getMaturityAmount());
                    fdcertificatemodel.setDateOfOpenning(UtilDate.formatetdateToString_dd_MM_yyyy(fddetails.getOpenningDate()));
                    fdcertificatemodel.setDateOfMaturity(UtilDate.formatetdateToString_dd_MM_yyyy(fddetails.getMaturityDate()));
                    fdcertificatemodel.setDepositeAmount(fddetails.getOpenningDeposite());
                    fdcertificatemodel.setDepositeAmountinWord(fddetails.getOpenningAmtinWords());
                    fdcertificatemodel.setRecieptNo(fddetails.getRecieptNo());
                    fdcertificatemodel.setFdCertificateNo(fddetails.getCertificateNo());
                    fdcertificatemodel.setFdLedgerNo(fddetails.getFdAccNo());
                    fdcertificatemodel.setPeriod(fddetails.getFdPeriod());
                    fdcertificatemodel.setFdrate(fddetails.getFullinterestrate());

                    response.setStatus(HttpStatus.OK);
                    response.setMessage("Record found!");
                    response.setData(fdcertificatemodel);
                } else {
                    response.setStatus(HttpStatus.NOT_FOUND);
                    response.setMessage("Record not found!");
                    response.setData(fdcertificatemodel);
                }

            } else {
                response.setStatus(HttpStatus.NOT_FOUND);
                response.setMessage("Record not found!");
                response.setData(fdcertificatemodel);
            }
        } catch (Exception e) {
            response = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when getting  fd details of member for certificate");
            logger.info("Exception occured when getting  fd details of member for certificate:" + e);
        }
        return response;
    }

    @Override
    public UpcidResponse getresponseforfdRenueal(String pnonumber, String fdaccountnumber, Integer period, Double amount, String renuedate, String username) {
        UpcidResponse<String> upcidresponse = new UpcidResponse();
        String res = "";
        try {
            MemberDetail memberdetail = null;
            FdDetails fddetails = null;
            FdCertificateModel fdcertificatemodel = null;
            SoftwareSetings softwaresetings = null;
            List<SwRateSetting> ratesettinglst = new ArrayList<>();
            double fdfullrate = 0.0;
            double fdpartial = 0.0;
            double interest = 0.0;
            String ageGroup = "";
            double maturityamount = 0.0;
            Map<String, String> responsemap = null;
            memberdetail = memberdetaildao.getmemberDetailByPnoNumber(pnonumber);
            if (memberdetail != null && memberdetail.getMemberId() != null && memberdetail.getMemberId() > 0) {
                Date dob = memberdetail.getDateOfBirth();
                Date today = new Date();
                Calendar birthday = Calendar.getInstance();
                birthday.setTime(dob);
                Calendar crrdate = Calendar.getInstance();
                crrdate.setTime(today);

                int yearsInBetween = crrdate.get(Calendar.YEAR) - birthday.get(Calendar.YEAR);
                if (yearsInBetween < 60) {
//                take Generat rate of interest  from current setting
                    ageGroup = "GENERAL";
                    softwaresetings = softwaresetingsdao.getSoftwareSetings();
                    if (softwaresetings != null && softwaresetings.getId() != null && softwaresetings.getId() > 0) {
                        ratesettinglst = softwaresetings.getSwRtsettingList();

                        if (ratesettinglst != null && ratesettinglst.size() > 0) {
                            for (SwRateSetting SwRateSetting : ratesettinglst) {
                                if (SwRateSetting.getYear() == period) {
                                    fdfullrate = SwRateSetting.getGenFdMatRate();
                                    fdpartial = SwRateSetting.getGenFdPreMatRate();
                                    break;
                                }
                            }
                        }
                    }
                } else {
//                take partial rate of interest  from current setting
                    ageGroup = "SR.CITIZEN";
                    softwaresetings = softwaresetingsdao.getSoftwareSetings();
                    if (softwaresetings != null && softwaresetings.getId() != null && softwaresetings.getId() > 0) {
                        ratesettinglst = softwaresetings.getSwRtsettingList();
                        if (ratesettinglst != null && ratesettinglst.size() > 0) {
                            for (SwRateSetting SwRateSetting : ratesettinglst) {
                                if (SwRateSetting.getYear() == period) {
                                    fdfullrate = SwRateSetting.getScFdMatMate();
                                    fdpartial = SwRateSetting.getScPreMatRate();
                                    break;
                                }
                            }
                        }
                    }
                }
                fddetails = fddetailsdao.getfddetailsBypnonumberAmdfdaccountnumber(memberdetail.getMemberId(), fdaccountnumber);
                if (fddetails != null && fddetails.getFdAccNo() != null && fddetails.getFdAccNo().trim().length() > 0) {
                    interest = (interest + Math.round(amount * fdfullrate * period / 100));
                    maturityamount = interest + amount;
                    Date renueDate = UtilDate.convertStringToDate(renuedate);
                    Calendar cal = Calendar.getInstance();
                    cal.setTime(renueDate);
                    cal.add(Calendar.YEAR, period);
                    String maturityDate = UtilDate.formatetdateToString_dd_MM_yyyy(cal.getTime());
                    responsemap = new HashMap<String, String>();
//                    responsemap.put("pnonumber",pnonumber);
//                    responsemap.put("fdaccno",fddetails.getFdAccNo());

                    responsemap.put("agegroup", ageGroup);
                    responsemap.put("fdfullrate", fdfullrate + "");
                    responsemap.put("fdpartrate", fdpartial + "");
                    responsemap.put("maturitydate", maturityDate);
                    responsemap.put("maturityamount", maturityamount + "");
                    responsemap.put("pnonumber", pnonumber);
                    responsemap.put("fdaccno", fddetails.getFdAccNo());
                    ObjectMapper mapperObj = new ObjectMapper();
                    String Detail = mapperObj.writeValueAsString(responsemap);
                    upcidresponse.setStatus(HttpStatus.OK);
                    upcidresponse.setMessage("Record found!");
                    upcidresponse.setData(Detail);

                } else {
                    upcidresponse.setStatus(HttpStatus.NOT_FOUND);
                    upcidresponse.setMessage("Record not found!");
                    upcidresponse.setData(null);
                }

            } else {
                upcidresponse.setStatus(HttpStatus.NOT_FOUND);
                upcidresponse.setMessage("Record not found!");
                upcidresponse.setData(null);
            }

        } catch (Exception e) {
            upcidresponse = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when getting  fd details of member for rd renueal");
            logger.info("Exception occured when getting  fd details of member rd renueal:" + e);
        }
        return upcidresponse;
    }

    @Override
    public UpcidResponse updateFDforRenueal(FdRenueModel fdrenuemodel, String username) {
        UpcidResponse<FdDetails> upcidresponse = new UpcidResponse();
        try {
            FdDetails fddetails = null;
            ConvertNumberToWord convertnumbertoword = null;
            String amountinword = "";
            if (fdrenuemodel != null && fdrenuemodel.getFdaccno() != null && fdrenuemodel.getFdaccno().trim().length() > 0
                    && fdrenuemodel.getRenueableAmount() != null && fdrenuemodel.getRenueableAmount() > 0
                    && fdrenuemodel.getMaturityamountr() != null && fdrenuemodel.getMaturityamountr() > 0) {
                fddetails = fddetailsdao.getfddetailsByfdaccountnumber(fdrenuemodel.getFdaccno());
                if (fddetails != null && fddetails.getFdAccNo() != null && fddetails.getFdAccNo().trim().length() > 0) {
                    convertnumbertoword = new ConvertNumberToWord();
                    int i = (int) fdrenuemodel.getRenueableAmount().doubleValue();
                    amountinword=convertnumbertoword.convertNumberToWords(i);
                    fddetails.setOpenningDeposite(fdrenuemodel.getRenueableAmount());
                    fddetails.setOpenningAmtinWords(amountinword);
                    fddetails.setAgeGroup(fdrenuemodel.getAgegroup());
                    fddetails.setOpenningDate(UtilDate.convertStringToDate(fdrenuemodel.getStartdate()));
                    fddetails.setFdPeriod(fdrenuemodel.getPeriod());
                    fddetails.setFullinterestrate(fdrenuemodel.getFdfullrate());
                    fddetails.setParinterestrate(fdrenuemodel.getFdpartrate());
                    fddetails.setMaturityDate(UtilDate.convertStringToDate(fdrenuemodel.getMaturitydate()));
                    fddetails.setMaturityAmount(fdrenuemodel.getMaturityamountr());
                    fddetails.setInterestdue(fdrenuemodel.getMaturityamountr() - fdrenuemodel.getRenueableAmount());
                    fddetails.setInterestBal(fdrenuemodel.getMaturityamountr() - fdrenuemodel.getRenueableAmount());
                    fddetails.setFdStatus("Open");
                    Calendar cal = Calendar.getInstance();
                    int year = cal.get(Calendar.YEAR);
                    fddetails.setFinYear(year + "");
                    FdDetails fddtls = fddetailsdao.updatefddetail(fddetails);
                    if (fddtls != null && fddtls.getFdAccNo() != null && fddtls.getFdAccNo().trim().length() > 0) {
                        upcidresponse.setStatus(HttpStatus.OK);
                        upcidresponse.setMessage("Record updated!");
                        upcidresponse.setData(fddtls);
                    }
                } else {
                    upcidresponse.setStatus(HttpStatus.NOT_FOUND);
                    upcidresponse.setMessage("Record not found!");
                    upcidresponse.setData(null);
                }

            } else {
                upcidresponse.setStatus(HttpStatus.NOT_FOUND);
                upcidresponse.setMessage("Record  not found!");
                upcidresponse.setData(null);

            }

        } catch (Exception e) {
            upcidresponse = new UpcidResponse(HttpStatus.EXPECTATION_FAILED, "Exception occured when updating fd details of member for renueal");
            logger.info("Exception occured when updating fd details of member for renueal:" + e);
        }
        return upcidresponse;
    }

    public static Double fdforoneyear(double opdeposit, double intrate, double partrate, double currentpartrate, int periodfd, Date openningdate, Date cruntDate) {
        int diff1 = 0, diff2 = 0, dff3 = 0, diff = 0, rem = 0, multiplier = 0;
        double intdue = 0.0, temp = 0.0, extraint = 0.0, intdue1 = 0.0;
        Calendar cd1 = Calendar.getInstance();
        Calendar cd2 = Calendar.getInstance();
        cd1.setTime(openningdate);
        cd2.setTime(cruntDate);
        diff1 = (cd2.get(Calendar.YEAR) - cd1.get(Calendar.YEAR)) * 12;
        diff2 = (cd2.get(Calendar.MONTH) - cd1.get(Calendar.MONTH)) - 1;
        dff3 = (cd2.get(Calendar.DAY_OF_MONTH) - cd1.get(Calendar.DAY_OF_MONTH));
        if (dff3 >= -1) {
            diff2 = diff2 + 1;
        }
        diff = diff1 + diff2;
        if (periodfd == 1) {
            if (diff >= 12) {
                intdue = ((opdeposit * intrate) / (12 * 100));
                intdue1 = Math.round(intdue * 12);
                if (diff > 12) {
                    diff = diff - 12;
                    rem = diff % 12;
                    multiplier = diff / 12;
                    if (diff >= 12) {
                        temp = (opdeposit * intrate) / (12 * 100);
                        temp = temp * 12 * multiplier;
                    }
                    extraint = (opdeposit * currentpartrate) / (12 * 100);
                    extraint = Math.round(extraint * rem);

                }
                intdue1 = intdue1 + temp + extraint;

            } else {
                intdue = ((opdeposit * partrate) / (12 * 100));
                intdue1 = Math.round(intdue * diff);
            }
        } else if (periodfd == 3) {
            if (diff > 24) {
                intdue = (opdeposit * intrate) / (12 * 100);

                if (diff >= 36) {
                    intdue1 = Math.round(intdue * 36);
                    if (diff > 36) {
                        diff = diff - 36;
                        multiplier = diff / 12;
                        rem = diff % 12;
                        if (diff >= 12) {
                            temp = (opdeposit * intrate) / (12 * 100);
                            temp = temp * 12 * multiplier;
                        }
                        extraint = (opdeposit * currentpartrate) / (12 * 100);
                        extraint = extraint * rem;
                    }

                    intdue1 = intdue1 + extraint + temp;
                } else {
                    intdue1 = Math.round(intdue * diff);
                }
            } else {
                intdue = (opdeposit * partrate) / (12 * 100);
                intdue1 = Math.round(intdue * diff);
            }
        } else if (periodfd == 5) {
            if (diff > 48) {
                intdue = (opdeposit * intrate) / (12 * 100);
                if (diff >= 60) {
                    intdue1 = Math.round(intdue * 60);
                    if (diff > 60) {
                        diff = diff - 60;
                        multiplier = diff / 12;
                        rem = diff % 12;
                        if (diff >= 12) {
                            temp = (opdeposit * intrate) / (12 * 100);
                            temp = temp * 12 * multiplier;
                        }
                        extraint = (opdeposit * currentpartrate) / (12 * 100);
                        extraint = extraint * rem;
                    }
                    intdue1 = intdue1 + extraint + temp;
                } else {
                    intdue1 = Math.round(intdue * diff);
                }
            } else {
                intdue = (opdeposit * partrate) / (12 * 100);
                intdue1 = Math.round(intdue * diff);
            }
        }

        return intdue1;
    }
}
