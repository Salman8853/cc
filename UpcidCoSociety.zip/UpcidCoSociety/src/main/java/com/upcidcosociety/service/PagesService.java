/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.service;

import com.upcidcosociety.dtob.Pages;
import com.upcidcosociety.model.PageModel;
import com.upcidcosociety.util.UpcidResponse;

/**
 *
 * @author m.salman
 */
public interface PagesService {
    public UpcidResponse addPages(PageModel pages, String remoteaddress, String username);
    
    public UpcidResponse updatePages(PageModel pages,String remoteaddress,String username);

    public UpcidResponse getpageBypid(Integer pid, String username);

    public UpcidResponse getAllPages(String username);
    
    public UpcidResponse deletePageById(Integer pid,String username);
}
