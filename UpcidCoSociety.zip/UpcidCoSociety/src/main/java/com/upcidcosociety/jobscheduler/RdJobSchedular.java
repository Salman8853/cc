/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.jobscheduler;

import com.upcidcosociety.service.MemberShareJobService;
import com.upcidcosociety.service.RdJobSchedularService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import com.upcidcosociety.service.RdYearlyJobSchedular;
import org.springframework.stereotype.Component;

/**
 *
 * @author m.salman
 */
@Component
public class RdJobSchedular {
   @Autowired
   private RdJobSchedularService rdjobschedularservice;
   
   @Autowired
   private RdYearlyJobSchedular rdyearlyjobschedularsrvs;
   
   @Autowired
   private MemberShareJobService membersharejobservice;
   
     @Scheduled(cron = "0 23 20 * * ?")
     public void monthWiseJobformemberRd(){   
         rdjobschedularservice.rdMonthWiseJob();
    
    }
//     Fire every 5 minutes every day
     @Scheduled(cron = " 0 23 09 * * ?") 
     public void yearwiseJobformemberRd() {    
         rdyearlyjobschedularsrvs.yearyjobforrd();
    }
//    Job for Member Share detail
     @Scheduled(cron = " 0 16 12 * * ?") 
     public void membersharejobmonthwise() {    
         membersharejobservice.memberShareJobmonthWise();
    }
    
}
