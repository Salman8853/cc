/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao.impl;

import com.upcidcosociety.dao.FeedBackDao;
import com.upcidcosociety.dtob.FeedBack;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author m.salman
 */
@Repository
public class FeedBackDaoImpl implements FeedBackDao{
    
  @Autowired
  private SessionFactory sessionFactory;
  
  
     @Override
     public FeedBack saveFeedBack(FeedBack feedBack){ 
        Session session=sessionFactory.getCurrentSession();
        session.save(feedBack);
        session.flush();
        return feedBack;
     }
     
     
     @Override
      public List<FeedBack> getAllFeedBack(){
         List<FeedBack> list = sessionFactory.getCurrentSession()
                .createCriteria(FeedBack.class)
                .list();
        if (!list.isEmpty()) {
            return list;
        }
        return null;
      
      }
      
    @Override  
    public FeedBack getFeedBackByid(Integer feedbackId){
      try {
         Session session=sessionFactory.getCurrentSession();
         String hql = "FROM FeedBack fb WHERE  fb.compId=:feedbackId";
          Query query = session.createQuery(hql);
         query.setParameter("feedbackId",feedbackId);
         List<FeedBack> results =query.list();
         if(results!=null && results.size()>0){
           return results.get(0);
         }else{
         return null;
          }
         } catch (Exception e) {
             e.printStackTrace();
             return null;  
         }
    
    }
}
