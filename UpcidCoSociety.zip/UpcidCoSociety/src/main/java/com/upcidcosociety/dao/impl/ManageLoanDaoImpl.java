/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao.impl;

import com.upcidcosociety.dao.ManageLoanDao;
import com.upcidcosociety.dtob.LoanDetails;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author m.salman
 */
@Repository
public class ManageLoanDaoImpl implements ManageLoanDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public LoanDetails saveloandetails(LoanDetails loandetails) {
    
        Session session = sessionFactory.getCurrentSession();
        session.save(loandetails);
        session.flush();
        return loandetails;
    }
    
    @Override
    public LoanDetails getloandetailsBymemberId(Integer memberId){
     try {
         Session session=sessionFactory.getCurrentSession();
         String hql = "FROM LoanDetails ls WHERE ls.memberDetail.memberId=:memberId";
         Query query = session.createQuery(hql);
         query.setParameter("memberId",memberId);
         List<LoanDetails> results =query.list();
         if(results!=null && results.size()>0){
           return results.get(0);
         }else{
         return null;
          }
         } catch (Exception e) {
             e.printStackTrace();
             return null;  
         }
    
    }
    
    @Override
     public LoanDetails updateloandetail(LoanDetails loandetails){
     try {
           Session session=sessionFactory.getCurrentSession();
           session.update(loandetails);
           session.flush();
            return loandetails;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
     }
     
    @Override
     public LoanDetails getloandetailsByloanId(Integer loanId){
     try {
         Session session=sessionFactory.getCurrentSession();
         String hql = "FROM LoanDetails ld WHERE ld.loanId=:loanId";
         Query query = session.createQuery(hql);
         query.setParameter("loanId",loanId);
         List<LoanDetails> results =query.list();
         if(results!=null && results.size()>0){
           return results.get(0);
         }else{
         return null;
          }
         } catch (Exception e) {
             e.printStackTrace();
             return null;  
         }
     }
}
