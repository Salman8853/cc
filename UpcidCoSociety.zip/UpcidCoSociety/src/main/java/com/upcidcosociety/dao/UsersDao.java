/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao;

import com.upcidcosociety.dtob.Users;

/**
 *
 * @author m.salman
 */
public interface UsersDao {
    public Users SaveUsers(Users users);
    
    public Users updateUsers(Users users);
    
    public Users getUsersById(Integer userid);
    
    public Users getAdminByUserName(String adminPassword);
    
    
}
