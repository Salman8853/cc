/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao;

import com.upcidcosociety.dtob.RdDetails;
import java.util.List;

/**
 *
 * @author m.salman
 */
public interface RdDetailsDao {
    
  public RdDetails saveNewRdDetails(RdDetails rdDetails);
  
  public RdDetails getRdDetailsByrdAccNo(Integer rdAccNo);
  
  public RdDetails getRdDetailsBymemberId(Integer memberId);
  
  public List<RdDetails> getAllRdDetails();
}
