/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao.impl;

import com.upcidcosociety.dtob.LoanGivenMonthWise;
import com.upcidcosociety.dao.LoanGivenMonthWiseDao;
import com.upcidcosociety.dtob.Category;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author m.salman
 */
@Repository
public class LoanGivenMonthWiseDaoImpl implements LoanGivenMonthWiseDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public LoanGivenMonthWise save(LoanGivenMonthWise loangivenmonthwise) {
        Session session = sessionFactory.getCurrentSession();
        session.save(loangivenmonthwise);
        session.flush();
        return loangivenmonthwise;

    }

    @Override
    public List<LoanGivenMonthWise> getAll(Integer loanId,Integer finyear) {
        try {
            Session session = sessionFactory.getCurrentSession();
            String hql = "FROM LoanGivenMonthWise loangiven WHERE  loangiven.loandetails.loanId=:loanId AND loangiven.finyear=:finyear";
            Query query = session.createQuery(hql);
            query.setParameter("loanId", loanId);
            query.setParameter("finyear", finyear);
            List<LoanGivenMonthWise> results = query.list();
            if (results != null && results.size() > 0) {
                return results;
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
          return null;
        }

    }

}
