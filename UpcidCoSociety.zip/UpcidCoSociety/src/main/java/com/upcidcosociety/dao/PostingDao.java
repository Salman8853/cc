/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao;

import com.upcidcosociety.dtob.Posting;
import com.upcidcosociety.dtob.Rank;
import java.util.List;

/**
 *
 * @author m.salman
 */
public interface PostingDao {
    
    public Posting addPosting(Posting posting);
    
    public Posting checkPostingByName(String posting);

    public Posting updatePosting(Posting posting);
    
    public Posting checkPostingByidAndPostingName(Integer Id,String posting);

    public Posting getPostingByid(Integer Id);
    
    public List<Posting> getAllPosting();
}
