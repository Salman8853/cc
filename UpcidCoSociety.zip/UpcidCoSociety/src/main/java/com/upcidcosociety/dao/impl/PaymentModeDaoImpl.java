/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao.impl;

import com.upcidcosociety.dao.PaymentModeDao;
import com.upcidcosociety.dtob.PaymentMode;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author m.salman
 */
@Repository
public class PaymentModeDaoImpl implements PaymentModeDao{
  @Autowired
  private SessionFactory sessionFactory;  
    
    
   @Override
   public PaymentMode addPaymentmode(PaymentMode paymentMode){
      
   Session session=sessionFactory.getCurrentSession();
        session.save(paymentMode);
        session.flush();
        return paymentMode;
   } 
   
   @Override
   public PaymentMode getPaymentmodeById(Integer paymentmodeId){
      
    try {
         Session session=sessionFactory.getCurrentSession();
         String hql = "FROM PaymentMode pm WHERE pm.isDeleted!=TRUE AND pm.paymentId=:paymentmodeId";
         Query query = session.createQuery(hql);
         query.setParameter("paymentmodeId",paymentmodeId);
         List<PaymentMode> results =query.list();
         if(results!=null && results.size()>0){
           return results.get(0);
         }else{
         return null;
          }
         } catch (Exception e) {
             e.printStackTrace();
             return null;  
         }
   } 
   
    @Override
    public List<PaymentMode> getAllPaymentMode(){
     List<PaymentMode> list = sessionFactory.getCurrentSession()
                .createCriteria(PaymentMode.class)
                .add(Restrictions.eq("isDeleted", Boolean.FALSE))
                .list();
         if (!list.isEmpty()) {
            return list;
        }
        return null;
    }
}
