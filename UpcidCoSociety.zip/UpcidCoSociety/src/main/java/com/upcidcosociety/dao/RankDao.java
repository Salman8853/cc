/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao;

import com.upcidcosociety.dtob.Rank;
import java.util.List;

/**
 *
 * @author m.salman
 */
public interface RankDao {
    public Rank addRank(Rank rank);

    public Rank updateRank(Rank rank);

    public Rank getRankByid(Integer Id);

    public Rank checkRankByidAndRankname(Integer Id, String rankName);
    
    public Rank checkRankByRankname(String rankName);

    public List<Rank> getAllRank();
}
