/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao.impl;

import com.upcidcosociety.dao.FdDetailsDao;
import com.upcidcosociety.dtob.FdDetails;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author m.salman
 */
@Repository
public class FdDetailsDaoImpl implements FdDetailsDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public FdDetails getlastRecordfromFdDetails() {
        try {
            Session session = sessionFactory.getCurrentSession();
            String hql = "FROM FdDetails fd order by fdAccNo DESC ";
            Query query = session.createQuery(hql);
            query.setMaxResults(1);
            FdDetails fddetails = (FdDetails) query.uniqueResult();
            if (fddetails != null && fddetails.getFdAccNo() != null && fddetails.getFdAccNo().trim().length() > 0) {
                return fddetails;
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public FdDetails savenewfd(FdDetails fddetails) {
        Session session = sessionFactory.getCurrentSession();
        session.save(fddetails);
        session.flush();
        return fddetails;
    }

    @Override
    public List<FdDetails> getfddetailsBymemberId(Integer membetId) {
        try {
            Session session = sessionFactory.getCurrentSession();
            String hql = "FROM FdDetails fd WHERE fd.memberDetail.memberId=:membetId";
            Query query = session.createQuery(hql);
            query.setParameter("membetId", membetId);
            List<FdDetails> results = query.list();
            if (results != null && results.size() > 0) {
                return results;
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }
    
    @Override
    public FdDetails getfddetailsByfdaccountnumber(String accountnumber){
      try {
            Session session = sessionFactory.getCurrentSession();
            String hql = "FROM FdDetails fd WHERE fd.fdAccNo=:fdAccNo";
            Query query = session.createQuery(hql);
            query.setParameter("fdAccNo", accountnumber);
            List<FdDetails> results = query.list();
            if (results != null && results.size() > 0) {
                return results.get(0);
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    
     }
    
     @Override
     public FdDetails getfddetailsBypnonumberAmdfdaccountnumber(Integer memberId,String accountnumber){
         try {
            Session session = sessionFactory.getCurrentSession();
            String hql = "FROM FdDetails fd WHERE fd.fdAccNo=:fdAccNo AND fd.memberDetail.memberId=:memberId";
            Query query = session.createQuery(hql);
            query.setParameter("fdAccNo", accountnumber);
            query.setParameter("memberId", memberId);
            List<FdDetails> results = query.list();
            if (results != null && results.size() > 0) {
                return results.get(0);
            } else {
                return null;
            }  
             
         } catch (Exception e) {
             e.printStackTrace();
            return null;  
         }
     
      }
     
        @Override
        public FdDetails updatefddetail(FdDetails fddetails){
          try {
           Session session=sessionFactory.getCurrentSession();
           session.update(fddetails);
           session.flush();
            return fddetails;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        
        }
}
