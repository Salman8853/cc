/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao.impl;

import com.upcidcosociety.dao.ComplaintsDao;
import com.upcidcosociety.dtob.Complaints;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author m.salman
 */
@Repository
public class ComplaintsDaoImpl implements ComplaintsDao{
    
  @Autowired
  private SessionFactory sessionFactory;
  
   @Override 
   public Complaints saveComplaints(Complaints complaints){
      
        Session session=sessionFactory.getCurrentSession();
        session.save(complaints);
        session.flush();
        return complaints;
   }
   
   @Override
    public List<Complaints> getAllComplaints(){
      List<Complaints> list = sessionFactory.getCurrentSession()
                .createCriteria(Complaints.class)
                .list();
        if (!list.isEmpty()) {
            return list;
        }
        return null;
    
     }
    @Override
     public Complaints getComplaintbyId(Integer compId){
       try {
         Session session=sessionFactory.getCurrentSession();
//          return (Category)session.get(Category.class, catId);
            String hql = "FROM Complaints cpm WHERE cpm.isDeleted!=TRUE AND cpm.compId=:compId";
           Query query = session.createQuery(hql);
         query.setParameter("compId",compId);
         List<Complaints> results =query.list();
         if(results!=null && results.size()>0){
           return results.get(0);
         }else{
         return null;
          }
         } catch (Exception e) {
             e.printStackTrace();
             return null;  
         }
     
     }
    
}
