/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao;

import com.upcidcosociety.dtob.FdDetails;
import java.util.List;

/**
 *
 * @author m.salman
 */
public interface FdDetailsDao {
     public FdDetails getlastRecordfromFdDetails();
     
     public FdDetails savenewfd(FdDetails fddetails);
     
     public List<FdDetails> getfddetailsBymemberId(Integer membetId);
     
     public FdDetails getfddetailsByfdaccountnumber(String accountnumber);
    
     public FdDetails getfddetailsBypnonumberAmdfdaccountnumber(Integer memberId,String accountnumber);
   
     public FdDetails updatefddetail(FdDetails fddetails);
}
