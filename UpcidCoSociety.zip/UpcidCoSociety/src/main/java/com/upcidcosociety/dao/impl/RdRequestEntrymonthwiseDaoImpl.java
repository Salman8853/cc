/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao.impl;

import com.upcidcosociety.dao.RdRequestEntrymonthwiseDao;
import com.upcidcosociety.dtob.RdRequestEntrymonthwise;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author m.salman
 */
@Repository
public class RdRequestEntrymonthwiseDaoImpl implements RdRequestEntrymonthwiseDao{
   
   @Autowired
    private SessionFactory sessionfactory;
    
  @Override
  public List<RdRequestEntrymonthwise> getAllRdRequestEntrymonthwise(){
      try {
           Calendar cal = Calendar.getInstance();
           cal.setTime(new Date());
           cal.set(Calendar.HOUR, 0);
            cal.set(Calendar.MINUTE, 0);
            cal.set(Calendar.SECOND, 0);
           cal.set(Calendar.MILLISECOND, 0);
           cal.set(Calendar.HOUR_OF_DAY, 0);
          cal.set(Calendar.DAY_OF_MONTH, cal.getActualMinimum(Calendar.DAY_OF_MONTH));
          Date sdate= cal.getTime();
          cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
           Date edate= cal.getTime();
      List<RdRequestEntrymonthwise> list = sessionfactory.getCurrentSession()
                .createCriteria(RdRequestEntrymonthwise.class)
                .add(Restrictions.eq("status", Boolean.TRUE))
                .add(Restrictions.ge("createdDate", sdate))
                .add(Restrictions.le("createdDate", edate))
                .list();
        if (!list.isEmpty()) {
            return list;
        }
        return null;
       } catch (Exception e) {
          e.printStackTrace();
          return null;
      }
    }
  
  @Override
   public RdRequestEntrymonthwise savenewRdRequestEntrymonthwise(RdRequestEntrymonthwise rdrequestentrymonthwise){
      try {
        Session session=sessionfactory.getCurrentSession();
        session.save(rdrequestentrymonthwise);
        session.flush();
        return rdrequestentrymonthwise;         
          
      } catch (Exception e) {
          return null;
      }
   
    }
   @Override
    public List<RdRequestEntrymonthwise> getAllRdRequestEntrymonthwiseByrdAccountNumberandSerialNumber(Integer rdAccountNumber,Integer serialNumber){
      try {
         Session session=sessionfactory.getCurrentSession();
         String hql = "FROM RdRequestEntrymonthwise rdmw WHERE  rdmw.rdaccountno=:rdAccountNumber AND rdmw.rdserialno=:serialNumber";
         Query query = session.createQuery(hql);
         query.setParameter("rdAccountNumber",rdAccountNumber);
         query.setParameter("serialNumber",serialNumber);
         List<RdRequestEntrymonthwise> results =query.list();
         if(results!=null && results.size()>0){
           return results;
         }else{
         return null;
          }
         } catch (Exception e) {
             e.printStackTrace();
             return null;  
       } 
     }
}
