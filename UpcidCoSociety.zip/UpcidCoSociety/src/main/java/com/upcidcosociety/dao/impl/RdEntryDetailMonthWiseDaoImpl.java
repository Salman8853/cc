/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao.impl;

import com.upcidcosociety.dao.RdEntryDetailMonthWiseDao;
import com.upcidcosociety.dtob.RdEntryDetailMonthWise;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author m.salman
 */
@Repository
public class RdEntryDetailMonthWiseDaoImpl implements RdEntryDetailMonthWiseDao{
   @Autowired
    private SessionFactory sessionFactory;
 
    @Override
    public RdEntryDetailMonthWise saveRdEntryDetailMonthWise(RdEntryDetailMonthWise rdentryDetailMonthWise){
     Session session = sessionFactory.getCurrentSession();
        session.save(rdentryDetailMonthWise);
        session.flush();
        return rdentryDetailMonthWise;
    }
    
    @Override
     public List<RdEntryDetailMonthWise> getAllRdEntryDetailMonthWiseByRdSerialNo(Integer rdSerialNo){
        try {
         Session session=sessionFactory.getCurrentSession();
//          return (Category)session.get(Category.class, catId);
         String hql = "FROM RdEntryDetailMonthWise rdedmontgwise WHERE rdedmontgwise.rdEntryDetail.rdSerialNo=:rdSerialNo";
         Query query = session.createQuery(hql);
         query.setParameter("rdSerialNo",rdSerialNo);
         List<RdEntryDetailMonthWise> results =query.list();
         if(results!=null && results.size()>0){
           return results;
         }else{
           return null;
         }
         } catch (Exception e) {
             e.printStackTrace();
             return null;  
         }
     
      }
     
    @Override
     public int deleteRdEntryDetailMonthWise(Integer rdemwId){
          try {
               Session session=sessionFactory.getCurrentSession();  
               String hql = "delete from  RdEntryDetailMonthWise rdedmontgwise WHERE rdedmontgwise.rdemwId=:rdemwId";
               Query query = session.createQuery(hql);
               query.setParameter("rdemwId",rdemwId);
               int index = query.executeUpdate();
               return index;
             } catch (Exception e) {
                e.printStackTrace();
                return 0; 
           }
     
     }

}
