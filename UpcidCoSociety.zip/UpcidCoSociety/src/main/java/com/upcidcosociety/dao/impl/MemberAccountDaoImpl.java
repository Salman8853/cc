/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao.impl;

import com.upcidcosociety.dao.MemberAccountDao;
import com.upcidcosociety.dtob.Category;
import com.upcidcosociety.dtob.MemberAccount;
import com.upcidcosociety.dtob.MemberDetail;
import com.upcidcosociety.dtob.Posting;
import com.upcidcosociety.dtob.Rank;
import com.upcidcosociety.dtob.Sector;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author m.salman
 */
@Repository
public class MemberAccountDaoImpl implements MemberAccountDao{
  @Autowired
  private SessionFactory sessionFactory;
    
    @Override
    public MemberAccount saveMemberAccount(MemberAccount memberAccount){
        Session session=sessionFactory.getCurrentSession();
        session.save(memberAccount);
        session.flush();
        return memberAccount;
    }
    
    @Override
    public MemberAccount getMemberAccountByid(Integer accId){
        try {
            Session session = sessionFactory.getCurrentSession();
            String hql = "FROM MemberAccount ma WHERE  ma.accId=:accId";
            Query query = session.createQuery(hql);
            query.setParameter("accId", accId);
            List<MemberAccount> results = query.list();
            if (results != null && results.size() > 0) {
                return results.get(0);
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }  
        @Override
        public MemberAccount updateMemberAccount(MemberAccount memberAccount){
        
          try {
            Session session = sessionFactory.getCurrentSession();
            session.update(memberAccount);
            session.flush();
            return memberAccount;
          } catch (Exception e) {
            e.printStackTrace();
            return null;
          }
        
        }
         
        @Override
         public MemberAccount checkMemberAccountByaccIdAndBankAccountNumber(Integer accId,String bankAccountNumber){
           try {
             Session session = sessionFactory.getCurrentSession();
             String hql = "FROM MemberAccount ma AND ma.accId!=:accId AND ma.bankAccountNumber=:bankAccountNumber";
             Query query = session.createQuery(hql);
             query.setParameter("accId", accId);
             query.setParameter("bankAccountNumber", bankAccountNumber);
             List<MemberAccount> results = query.list();
             if (results != null && results.size() > 0) {
                 return results.get(0);
             } else {
                 return null;
             }
         } catch (Exception e) {
             e.printStackTrace();
             return null;
         }
         
     }
         
         
        @Override
       public  List<Category> getallDistinctCategoryListByCriteria(){
           try {
             Session session = sessionFactory.getCurrentSession();
             Criteria criteria=session.createCriteria(MemberDetail.class,"md")
                     .createAlias("md.memberAccount", "ma")
                     .add(Restrictions.ne("md.isDeleted", Boolean.TRUE));
             criteria.setProjection(Projections.distinct(Projections.property("ma.category")));
              List<Category>categoryIdlst=criteria.list();
              if(categoryIdlst!=null && categoryIdlst.size()>0){
               return categoryIdlst;
              }else{
               return null;
            }
         } catch (Exception e) {
             e.printStackTrace();
             return null;
         }
         
     } 
       
     
       
    @Override    
   public  List<Rank> getallDistinctRankListListByCriteria(){
          try{
             Session session = sessionFactory.getCurrentSession();
           Criteria criteria=session.createCriteria(MemberDetail.class,"md")
                     .createAlias("md.memberAccount", "ma")
                     .add(Restrictions.ne("md.isDeleted", Boolean.TRUE));
             criteria.setProjection(Projections.distinct(Projections.property("ma.rank")));
              List<Rank>ranklst=criteria.list();
              if(ranklst!=null && ranklst.size()>0){
               return ranklst;
              }else{
               return null;
            }
         } catch (Exception e) {
             e.printStackTrace();
             return null;
         }
       }
   
   @Override    
   public  List<Sector> getallDistinctSectorListByCriteria(){
          try{
             Session session = sessionFactory.getCurrentSession();
           Criteria criteria=session.createCriteria(MemberDetail.class,"md")
                     .createAlias("md.memberAccount", "ma")
                     .add(Restrictions.ne("md.isDeleted", Boolean.TRUE));
             criteria.setProjection(Projections.distinct(Projections.property("ma.sector")));
              List<Sector>sectorlst=criteria.list();
              if(sectorlst!=null && sectorlst.size()>0){
               return sectorlst;
              }else{
               return null;
            }
         } catch (Exception e) {
             e.printStackTrace();
             return null;
         }
       }
   
   @Override    
   public  List<Posting> getallDistinctPostingListByCriteria(){
          try{
             Session session = sessionFactory.getCurrentSession();
           Criteria criteria=session.createCriteria(MemberDetail.class,"md")
                     .createAlias("md.memberAccount", "ma")
                     .add(Restrictions.ne("md.isDeleted", Boolean.TRUE));
             criteria.setProjection(Projections.distinct(Projections.property("ma.posting")));
              List<Posting>Postinglst=criteria.list();
              if(Postinglst!=null && Postinglst.size()>0){
               return Postinglst;
              }else{
               return null;
            }
         } catch (Exception e) {
             e.printStackTrace();
             return null;
         }
       }

  }

