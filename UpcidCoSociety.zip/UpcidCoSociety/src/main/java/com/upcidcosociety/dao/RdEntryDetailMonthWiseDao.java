/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao;

import com.upcidcosociety.dtob.RdEntryDetailMonthWise;
import java.util.List;

/**
 *
 * @author m.salman
 */
public interface RdEntryDetailMonthWiseDao {
     public RdEntryDetailMonthWise saveRdEntryDetailMonthWise(RdEntryDetailMonthWise rdentryDetailMonthWise);
     
     public List<RdEntryDetailMonthWise> getAllRdEntryDetailMonthWiseByRdSerialNo(Integer rdSerialNo);
     
     public int deleteRdEntryDetailMonthWise(Integer rdemwId);
 
}
