/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dao.impl;

import com.upcidcosociety.dao.NewsDao;
import com.upcidcosociety.dtob.News;
import java.util.Date;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author m.salman
 */
@Repository
public class NewsDaoImpl implements NewsDao {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public News saveNews(News news) {
        Session session = sessionFactory.getCurrentSession();
        session.save(news);
        session.flush();
        return news;
    }

    @Override
    public News getNewsByTitle(String newsTitle) {
        try {
            Session session = sessionFactory.getCurrentSession();
            String hql = "FROM News nws WHERE nws.newsTitle=:newsTitle";
            Query query = session.createQuery(hql);
            query.setParameter("newsTitle", newsTitle);
            List<News> results = query.list();
            if (results != null && results.size() > 0) {
                return results.get(0);
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
   @Override
    public News getNewsById(Integer id){
    try {
            Session session = sessionFactory.getCurrentSession();
            String hql = "FROM News nws WHERE nws.id=:id";
            Query query = session.createQuery(hql);
            query.setParameter("id", id);
            List<News> results = query.list();
            if (results != null && results.size() > 0) {
                return results.get(0);
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    
    @Override
    public List<News> getAllNews(Date startdate,Date endDate){
        List<News> list = sessionFactory.getCurrentSession()
                .createCriteria(News.class)
                .add(Restrictions.between("createdDate", startdate, endDate))
                .list();
        if (!list.isEmpty()) {
            return list;
        }
        return null;
    }
}
