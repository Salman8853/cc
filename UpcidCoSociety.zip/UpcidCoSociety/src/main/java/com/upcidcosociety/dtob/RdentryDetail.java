/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dtob;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author m.salman
 */
@Entity
@Table(name = "rd_entry_details")
public class RdentryDetail {
    
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name = "rd_serial_no")
 private Integer rdSerialNo;
 
 @ManyToOne
 @JoinColumn(name = "rddetail_id", referencedColumnName = "rdacc_no")
 private RdDetails rdDetails;

 @Column(name="rd_openning_date",columnDefinition = "DATE")
 private Date rdOpenningDate; 
 
 @Column(name="rd_breaking_date",columnDefinition = "DATE")
 private Date rdDreakingDate; 
 
 @Column(name="pmd")
 private Double pmd;  
 
 @Column(name="pod")
 private Integer pod;  
 
 @Column(name="interest_due")
 private Double intdue; 
 
 @Column(name="interest_paid")
 private Double intPaid; 
 
 @Column(name="interest_bal")
 private Double intBal; 
 
 @Column(name="openning_balance")
 private Double openningBalance; 
 
 @Column(name="bal31_march")
 private Double bal31March;
 
 
 @Column(name="int_openning_bal")
 private Double intOpenningBal; 
 
 @Column(name="total_payment")
 private Double totalPayment; 
 
 @Column(name="fin_year")
 private String finYear; 
 
 @Column(name="installment_sum")
 private String installmentSum; 
 
 @Column(name="old_amt")
 private Double oldAmt; 

 @Column(name="result")
 private String result;  
 
 @Column(name="status")
 private String status;  
 
  @JsonIgnore
  @OneToMany(mappedBy = "rdEntryDetail", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
  private List<RdEntryDetailMonthWise> rdEntryDetailMonthWiseList;

    public RdentryDetail() {
        
    }

  
    public Integer getRdSerialNo() {
        return rdSerialNo;
    }

    public void setRdSerialNo(Integer rdSerialNo) {
        this.rdSerialNo = rdSerialNo;
    }

    public RdDetails getRdDetails() {
        return rdDetails;
    }

    public void setRdDetails(RdDetails rdDetails) {
        this.rdDetails = rdDetails;
    }

    public Date getRdOpenningDate() {
        return rdOpenningDate;
    }

    public void setRdOpenningDate(Date rdOpenningDate) {
        this.rdOpenningDate = rdOpenningDate;
    }

    public Date getRdDreakingDate() {
        return rdDreakingDate;
    }

    public void setRdDreakingDate(Date rdDreakingDate) {
        this.rdDreakingDate = rdDreakingDate;
    }

    public Double getPmd() {
        return pmd;
    }

    public void setPmd(Double pmd) {
        this.pmd = pmd;
    }

    public Integer getPod() {
        return pod;
    }

    public void setPod(Integer pod) {
        this.pod = pod;
    }

    public Double getIntdue() {
        return intdue;
    }

    public void setIntdue(Double intdue) {
        this.intdue = intdue;
    }

    public Double getIntPaid() {
        return intPaid;
    }

    public void setIntPaid(Double intPaid) {
        this.intPaid = intPaid;
    }

    public Double getIntBal() {
        return intBal;
    }

    public void setIntBal(Double intBal) {
        this.intBal = intBal;
    }

    public Double getOpenningBalance() {
        return openningBalance;
    }

    public void setOpenningBalance(Double openningBalance) {
        this.openningBalance = openningBalance;
    }

    public Double getBal31March() {
        return bal31March;
    }

    public void setBal31March(Double bal31March) {
        this.bal31March = bal31March;
    }

    public Double getIntOpenningBal() {
        return intOpenningBal;
    }

    public void setIntOpenningBal(Double intOpenningBal) {
        this.intOpenningBal = intOpenningBal;
    }

    public Double getTotalPayment() {
        return totalPayment;
    }

    public void setTotalPayment(Double totalPayment) {
        this.totalPayment = totalPayment;
    }

    public String getFinYear() {
        return finYear;
    }

    public void setFinYear(String finYear) {
        this.finYear = finYear;
    }

    public String getInstallmentSum() {
        return installmentSum;
    }

    public void setInstallmentSum(String installmentSum) {
        this.installmentSum = installmentSum;
    }

    public Double getOldAmt() {
        return oldAmt;
    }

    public void setOldAmt(Double oldAmt) {
        this.oldAmt = oldAmt;
    }

   

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public List<RdEntryDetailMonthWise> getRdEntryDetailMonthWiseList() {
        return rdEntryDetailMonthWiseList;
    }

    public void setRdEntryDetailMonthWiseList(List<RdEntryDetailMonthWise> rdEntryDetailMonthWiseList) {
        this.rdEntryDetailMonthWiseList = rdEntryDetailMonthWiseList;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
 
    
 
}
