/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dtob;

import com.upcidcosociety.util.CommonAttributes;
import java.io.Serializable;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 *
 * @author m.salman
 */
@Entity
@Table(name="software_rate_setings")
public class SwRateSetting {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private Integer id;
    
    @Column(name="year")
    private Integer year;
    
    @Column(name="gen_fd_mat_rate")
    private double genFdMatRate;
     
    @Column(name="gen_fd_pre_mat_rate")
    private double genFdPreMatRate;
    
    @Column(name="sc_fd_mat_rate")
    private double scFdMatMate;
    
    @Column(name="sc_pre_mat_rate")
    private double scPreMatRate;
    
    @Column(name="rd_full_rate")
    private double rdFullRate;
    
    @Column(name="rd_part_rate")
    private double rdPartRate;
    

    @ManyToOne(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
    @JoinColumn(name="ssid",referencedColumnName = "id")
    private SoftwareSetings ssid;

    public SwRateSetting() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public double getGenFdMatRate() {
        return genFdMatRate;
    }

    public void setGenFdMatRate(double genFdMatRate) {
        this.genFdMatRate = genFdMatRate;
    }

    public double getGenFdPreMatRate() {
        return genFdPreMatRate;
    }

    public void setGenFdPreMatRate(double genFdPreMatRate) {
        this.genFdPreMatRate = genFdPreMatRate;
    }

    public double getScFdMatMate() {
        return scFdMatMate;
    }

    public void setScFdMatMate(double scFdMatMate) {
        this.scFdMatMate = scFdMatMate;
    }

    public double getScPreMatRate() {
        return scPreMatRate;
    }

    public void setScPreMatRate(double scPreMatRate) {
        this.scPreMatRate = scPreMatRate;
    }

    public double getRdFullRate() {
        return rdFullRate;
    }

    public void setRdFullRate(double rdFullRate) {
        this.rdFullRate = rdFullRate;
    }

    public double getRdPartRate() {
        return rdPartRate;
    }

    public void setRdPartRate(double rdPartRate) {
        this.rdPartRate = rdPartRate;
    }

    public SoftwareSetings getSsid() {
        return ssid;
    }

    public void setSsid(SoftwareSetings ssid) {
        this.ssid = ssid;
    }


}
