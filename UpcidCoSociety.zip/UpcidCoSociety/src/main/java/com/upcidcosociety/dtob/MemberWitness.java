/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dtob;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 *
 * @author m.salman
 */
@Entity
@Table(name="member_witness")
public class MemberWitness {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "w_id")
    private Integer wId;

    @Column(name = "w_name")
    private String wName;
    
    @Column(name = "w_rank")
    private String wRank;
    
    @Column(name = "w_pno")
    private String wPno;
    
    
    @Column(name = "w_address")
    private String wAddress;
    
    @Column(name = "w_mobile_number")
    private String wmobilenumber;
    
    @Column(name = "w_sign_url")
    private String wSignUrl;

     @ManyToOne
     @JoinColumn(name = "member_id", referencedColumnName = "member_id")
     private MemberDetail memberDetail;
    
    public MemberWitness() {
        
    }

    public Integer getwId() {
        return wId;
    }

    public void setwId(Integer wId) {
        this.wId = wId;
    }

    public String getwName() {
        return wName;
    }

    public void setwName(String wName) {
        this.wName = wName;
    }

    public String getwRank() {
        return wRank;
    }

    public void setwRank(String wRank) {
        this.wRank = wRank;
    }

    public String getwPno() {
        return wPno;
    }

    public void setwPno(String wPno) {
        this.wPno = wPno;
    }

    public String getwAddress() {
        return wAddress;
    }

    public void setwAddress(String wAddress) {
        this.wAddress = wAddress;
    }

    public String getWmobilenumber() {
        return wmobilenumber;
    }

    public void setWmobilenumber(String wmobilenumber) {
        this.wmobilenumber = wmobilenumber;
    }

    public String getwSignUrl() {
        return wSignUrl;
    }

    public void setwSignUrl(String wSignUrl) {
        this.wSignUrl = wSignUrl;
    }

    public MemberDetail getMemberDetail() {
        return memberDetail;
    }

    public void setMemberDetail(MemberDetail memberDetail) {
        this.memberDetail = memberDetail;
    }
    

    
}
