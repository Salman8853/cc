/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dtob;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author m.salman
 */
@Entity
@Table(name="complaints_request_master")
public class ComplaintsRequestMaster {
   @Id
   @GeneratedValue(strategy=GenerationType.IDENTITY)
   @Column(name = "comp_request_id")
   private Integer compRequestId;
   
   @Column(name="comp_request_name")
   private String CompRequestName;

    public ComplaintsRequestMaster() {
        
    }
   
   

    public Integer getCompRequestId() {
        return compRequestId;
    }

    public void setCompRequestId(Integer compRequestId) {
        this.compRequestId = compRequestId;
    }

    public String getCompRequestName() {
        return CompRequestName;
    }

    public void setCompRequestName(String CompRequestName) {
        this.CompRequestName = CompRequestName;
    }

    @Override
    public String toString() {
        return "ComplaintsRequestMaster{" + "compRequestId=" + compRequestId + ", CompRequestName=" + CompRequestName + '}';
    }   
}
