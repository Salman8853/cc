/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dtob;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 *
 * @author m.salman
 */
@Entity
@Table(name = "member_share_detail_month_wise")
public class MemberShareDetailMonthWise {
    
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name = "id")
 private Integer id;
 
 @Column(name="month")
 private String month;
 
 @Column(name="amount")
 private Double amount;
 
 @Column(name="date",columnDefinition = "DATE")
 private Date date;
 
 @Column(name="finyear")
 private Integer finyear;
 

@ManyToOne
@JoinColumn(name = "msd",referencedColumnName ="msd_id" )
private MemberShareDetail memberShareDetail;

    public MemberShareDetailMonthWise() {
        
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Integer getFinyear() {
        return finyear;
    }

    public void setFinyear(Integer finyear) {
        this.finyear = finyear;
    }



    public MemberShareDetail getMemberShareDetail() {
        return memberShareDetail;
    }

    public void setMemberShareDetail(MemberShareDetail memberShareDetail) {
        this.memberShareDetail = memberShareDetail;
    }
  
}
