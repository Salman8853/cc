/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dtob;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 *
 * @author m.salman
 */
@Entity
@Table(name="member_account")
public class MemberAccount {
  @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name = "acc_id")
 private Integer accId; 
  
 @Column(name="bank_account_number")
 private String bankAccountNumber;


 @Column(name="basicPay")
 private Double basicPay; 
 
 @Column(name="bank_name")
 private String bankName; 
  

 @Column(name="srd_amount")
 private Double srdAmount;

 @Column(name="soceity_account_number")
 private String soceityAccountNumber; 
 
 @Column(name="share_opening_bal")
 private Double shareOpeningBal; 

 
 @Column(name="ledger_file_number")
 private String ledgerFileNumber;
 
 @Column(name="provident_fund_number")
 private String providentFundNumber;
 
    @ManyToOne
    @JoinColumn(name = "category_id", referencedColumnName = "cat_id")
    private Category category;

    @ManyToOne
    @JoinColumn(name = "rank_id", referencedColumnName = "id")
    private Rank rank;

    @ManyToOne
    @JoinColumn(name = "sector", referencedColumnName = "id")
    private Sector sector;

    @ManyToOne
    @JoinColumn(name = "posting_id", referencedColumnName = "id")
    private Posting posting;
    
    @ManyToOne
    @JoinColumn(name = "payment_id", referencedColumnName = "payment_id")
    private PaymentMode paymentmode;

    public Integer getAccId() {
        return accId;
    }

    public void setAccId(Integer accId) {
        this.accId = accId;
    }

    public String getBankAccountNumber() {
        return bankAccountNumber;
    }

    public void setBankAccountNumber(String bankAccountNumber) {
        this.bankAccountNumber = bankAccountNumber;
    }

    public Double getBasicPay() {
        return basicPay;
    }

    public void setBasicPay(Double basicPay) {
        this.basicPay = basicPay;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

 

    public Double getSrdAmount() {
        return srdAmount;
    }

    public void setSrdAmount(Double srdAmount) {
        this.srdAmount = srdAmount;
    }

    public String getSoceityAccountNumber() {
        return soceityAccountNumber;
    }

    public void setSoceityAccountNumber(String soceityAccountNumber) {
        this.soceityAccountNumber = soceityAccountNumber;
    }

    public Double getShareOpeningBal() {
        return shareOpeningBal;
    }

    public void setShareOpeningBal(Double shareOpeningBal) {
        this.shareOpeningBal = shareOpeningBal;
    }

    public String getLedgerFileNumber() {
        return ledgerFileNumber;
    }

    public void setLedgerFileNumber(String ledgerFileNumber) {
        this.ledgerFileNumber = ledgerFileNumber;
    }

    public String getProvidentFundNumber() {
        return providentFundNumber;
    }

    public void setProvidentFundNumber(String providentFundNumber) {
        this.providentFundNumber = providentFundNumber;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public Rank getRank() {
        return rank;
    }

    public void setRank(Rank rank) {
        this.rank = rank;
    }

    public Sector getSector() {
        return sector;
    }

    public void setSector(Sector sector) {
        this.sector = sector;
    }

    public Posting getPosting() {
        return posting;
    }

    public void setPosting(Posting posting) {
        this.posting = posting;
    }

    public PaymentMode getPaymentmode() {
        return paymentmode;
    }

    public void setPaymentmode(PaymentMode paymentmode) {
        this.paymentmode = paymentmode;
    }
 
    
    
    
}
