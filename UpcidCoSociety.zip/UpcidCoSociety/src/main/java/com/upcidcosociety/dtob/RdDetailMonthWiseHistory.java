/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dtob;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 *
 * @author m.salman
 */
@Entity
@Table(name = "rddetailmonthwise_history")
public class RdDetailMonthWiseHistory {
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name = "rdemw_id")
 private Integer rdemwId;
 
 @Column(name="month")
 private String month; 
 
 @Column(name="amount")
 private Double amount;  
 
 @Column(name="entry_date",columnDefinition = "DATE")
 private Date entryDate;
 
 @Column(name="finyear")
 private String finYear;  
 
//@ManyToOne
//@JoinColumn(name = "rdentryDetail_id",referencedColumnName ="rd_serial_no" )
 @Column(name="rdserialnumber")
 private Integer rdserialnumber;
 
 @Column(name="rdaccountnumber")
 private Integer rdaccountnumber;

    public RdDetailMonthWiseHistory() {
        
    }

   
    public Integer getRdemwId() {
        return rdemwId;
    }

    public void setRdemwId(Integer rdemwId) {
        this.rdemwId = rdemwId;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public Date getEntryDate() {
        return entryDate;
    }

    public void setEntryDate(Date entryDate) {
        this.entryDate = entryDate;
    }

    public Integer getRdserialnumber() {
        return rdserialnumber;
    }

    public void setRdserialnumber(Integer rdserialnumber) {
        this.rdserialnumber = rdserialnumber;
    }

    public Integer getRdaccountnumber() {
        return rdaccountnumber;
    }

    public void setRdaccountnumber(Integer rdaccountnumber) {
        this.rdaccountnumber = rdaccountnumber;
    }


    public String getFinYear() {
        return finYear;
    }

    public void setFinYear(String finYear) {
        this.finYear = finYear;
    }
 
}
