/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dtob;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 *
 * @author m.salman
 */
@Entity
@Table(name="fd_nominee")
public class FdNominee {
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name = "id")
 private Integer id;
 
 @Column(name="nominee_name")
 private String nomineeName; 
 
 @Column(name="relation")
 private String relation;
 
 @Column(name="address")
 private String address;
    
 
 @Column(name="share")
 private String share;
 
 @ManyToOne
 @JoinColumn(name = "fdaccno", referencedColumnName = "fdacc_no")
 private FdDetails fddetails;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNomineeName() {
        return nomineeName;
    }

    public void setNomineeName(String nomineeName) {
        this.nomineeName = nomineeName;
    }

    public String getRelation() {
        return relation;
    }

    public void setRelation(String relation) {
        this.relation = relation;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getShare() {
        return share;
    }

    public void setShare(String share) {
        this.share = share;
    }

    public FdDetails getFddetails() {
        return fddetails;
    }

    public void setFddetails(FdDetails fddetails) {
        this.fddetails = fddetails;
    }
 
 
 
    
}
