/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.upcidcosociety.dtob;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 *
 * @author m.salman
 */
@Entity
@Table(name = "fd_details")
public class FdDetails {

    @Id
    @Column(name = "fdacc_no")
    private String fdAccNo;

    @Column(name = "openning_date", columnDefinition = "DATE")
    private Date openningDate;

    @Column(name = "partial_date", columnDefinition = "DATE")
    private Date partialDate;

//    @Column(name = "close_date", columnDefinition = "DATE")
////    private Date closeDate;
    
    @Column(name = "maturity_date", columnDefinition = "DATE")
    private Date maturityDate;;

    @Column(name = "fd_period")
    private Integer fdPeriod;

    @Column(name = "openning_deposite")
    private Double openningDeposite;

    @Column(name = "openning_amt_inwords")
    private String openningAmtinWords;

    @Column(name = "openning_balance")
    private String openningBalance;

    @Column(name = "certificate_no")
    private String certificateNo;

    @Column(name = "reciept_no")
    private String recieptNo;

    @Column(name = "maturity_amount")
    private Double maturityAmount;

    @Column(name = "interest_due")
    private Double interestdue;

    @Column(name = "interest_paid")
    private Double interestPaid;

    @Column(name = "interest_bal")
    private Double interestBal;

    @Column(name = "fd_paid")
    private Double fdPaid;

    @Column(name = "fd_bal")
    private Double fdBal;

    @Column(name = "old_amount")
    private Double oldAmount;

    @Column(name = "fd_status")
    private String fdStatus;

    @Column(name = "fin_year")
    private String finYear;

    @Column(name = "age_group")
    private String ageGroup;
    


    @Column(name = "full_interest_rate")
    private Double fullinterestrate;
    
    @Column(name = "par_interest_rate")
    private Double parinterestrate;
    
    



    @OneToOne
    @JoinColumn(name = "member_id", referencedColumnName = "member_id")
    private MemberDetail memberDetail;

    public FdDetails() {

    }

    public String getFdAccNo() {
        return fdAccNo;
    }

    public void setFdAccNo(String fdAccNo) {
        this.fdAccNo = fdAccNo;
    }

    public Date getOpenningDate() {
        return openningDate;
    }

    public void setOpenningDate(Date openningDate) {
        this.openningDate = openningDate;
    }

    public Date getPartialDate() {
        return partialDate;
    }

    public void setPartialDate(Date partialDate) {
        this.partialDate = partialDate;
    }

//    public Date getCloseDate() {
//        return closeDate;
//    }
//
//    public void setCloseDate(Date closeDate) {
//        this.closeDate = closeDate;
//    }

    public Integer getFdPeriod() {
        return fdPeriod;
    }

    public void setFdPeriod(Integer fdPeriod) {
        this.fdPeriod = fdPeriod;
    }

    public Double getOpenningDeposite() {
        return openningDeposite;
    }

    public void setOpenningDeposite(Double openningDeposite) {
        this.openningDeposite = openningDeposite;
    }

    public String getOpenningAmtinWords() {
        return openningAmtinWords;
    }

    public void setOpenningAmtinWords(String openningAmtinWords) {
        this.openningAmtinWords = openningAmtinWords;
    }

    public String getOpenningBalance() {
        return openningBalance;
    }

    public void setOpenningBalance(String openningBalance) {
        this.openningBalance = openningBalance;
    }

    public String getCertificateNo() {
        return certificateNo;
    }

    public void setCertificateNo(String certificateNo) {
        this.certificateNo = certificateNo;
    }

    public String getRecieptNo() {
        return recieptNo;
    }

    public void setRecieptNo(String recieptNo) {
        this.recieptNo = recieptNo;
    }

    public Double getMaturityAmount() {
        return maturityAmount;
    }

    public void setMaturityAmount(Double maturityAmount) {
        this.maturityAmount = maturityAmount;
    }

   

    public Double getInterestdue() {
        return interestdue;
    }

    public void setInterestdue(Double interestdue) {
        this.interestdue = interestdue;
    }

    public Double getInterestPaid() {
        return interestPaid;
    }

    public void setInterestPaid(Double interestPaid) {
        this.interestPaid = interestPaid;
    }

    public Double getInterestBal() {
        return interestBal;
    }

    public void setInterestBal(Double interestBal) {
        this.interestBal = interestBal;
    }

    public Double getFdPaid() {
        return fdPaid;
    }

    public void setFdPaid(Double fdPaid) {
        this.fdPaid = fdPaid;
    }

    public Double getFdBal() {
        return fdBal;
    }

    public void setFdBal(Double fdBal) {
        this.fdBal = fdBal;
    }

    public Double getOldAmount() {
        return oldAmount;
    }

    public void setOldAmount(Double oldAmount) {
        this.oldAmount = oldAmount;
    }

    public String getFdStatus() {
        return fdStatus;
    }

    public void setFdStatus(String fdStatus) {
        this.fdStatus = fdStatus;
    }

    public String getFinYear() {
        return finYear;
    }

    public void setFinYear(String finYear) {
        this.finYear = finYear;
    }

    public String getAgeGroup() {
        return ageGroup;
    }

    public void setAgeGroup(String ageGroup) {
        this.ageGroup = ageGroup;
    }

    public MemberDetail getMemberDetail() {
        return memberDetail;
    }

    public void setMemberDetail(MemberDetail memberDetail) {
        this.memberDetail = memberDetail;
    }

    public Double getFullinterestrate() {
        return fullinterestrate;
    }

    public void setFullinterestrate(Double fullinterestrate) {
        this.fullinterestrate = fullinterestrate;
    }

    public Double getParinterestrate() {
        return parinterestrate;
    }

    public void setParinterestrate(Double parinterestrate) {
        this.parinterestrate = parinterestrate;
    }

    public Date getMaturityDate() {
        return maturityDate;
    }

    public void setMaturityDate(Date maturityDate) {
        this.maturityDate = maturityDate;
    }

    
   

   

}
